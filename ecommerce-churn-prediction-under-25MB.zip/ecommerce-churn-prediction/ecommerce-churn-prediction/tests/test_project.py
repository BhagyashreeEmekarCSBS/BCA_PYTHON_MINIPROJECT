"""
Automated tests for the churn project.  Run with:   python -m pytest -v
Each test name starts with the test-case id used in docs/TESTING.md.
"""
import io

import numpy as np
import pandas as pd
import pytest

import config
from src import data_loader as dl
from src import eda, explainability as ex, predict as pr, preprocessing as pp
from src import recommendations as rc, reports, train_model as tm


# ------------------------------------------------------------------ fixtures
@pytest.fixture(scope="session")
def raw_df():
    return dl.load_sample()


@pytest.fixture(scope="session")
def clean_df(raw_df):
    return dl.clean_dataframe(raw_df, "Churn")[0]


@pytest.fixture(scope="session")
def bundle(clean_df):
    """Train once for the whole test session (about 30-60 seconds)."""
    return tm.train_and_compare(clean_df, "Churn")


# ------------------------------------------------------------ TC01 / TC02 upload
def test_tc01_valid_dataset_upload(raw_df):
    buf = io.StringIO(raw_df.to_csv(index=False))
    df = dl.load_csv(buf)
    check = dl.validate_dataframe(df, dl.detect_target_column(df))
    assert check["errors"] == []
    assert df.shape == raw_df.shape


@pytest.mark.parametrize("content", ["", "a\n", "a,b\n"])
def test_tc02_invalid_upload_rejected(content):
    with pytest.raises(dl.DatasetError):
        dl.load_csv(io.StringIO(content))


def test_tc02_missing_target_column_gives_clear_error(raw_df):
    df = raw_df.drop(columns=["Churn"])
    assert dl.detect_target_column(df) is None
    errors = dl.validate_dataframe(df, None)["errors"]
    assert any("Required column missing" in e for e in errors)


def test_tc02_target_with_three_classes_is_error():
    df = pd.DataFrame({"x": range(100), "Churn": ["a", "b", "c", "a"] * 25})
    assert any("exactly 2" in e for e in dl.validate_dataframe(df, "Churn")["errors"])


def test_tc02_file_not_found():
    with pytest.raises(dl.DatasetError):
        dl.load_csv("no_such_file.csv")


# --------------------------------------------------- TC03 / TC04 missing, duplicates
def test_tc03_missing_values_detected_and_handled(raw_df, bundle):
    assert dl.get_data_summary(raw_df)["missing_cells"] > 0
    row = raw_df.drop(columns=["Churn"]).head(1).copy()
    row["Age"] = np.nan
    row["Preferred_Payment"] = np.nan
    out, _ = pr.predict_dataframe(row, bundle)          # imputer fills the gaps
    assert 0 <= out.loc[0, "Churn_Probability"] <= 1


def test_tc04_duplicates_detected_and_removed(raw_df):
    assert dl.get_data_summary(raw_df)["duplicates"] == 25
    cleaned, rep = dl.clean_dataframe(raw_df, "Churn")
    assert rep["duplicates_removed"] == 25
    assert cleaned.duplicated().sum() == 0


# ------------------------------------------------------- preprocessing / leakage
def test_tc05_identifier_and_target_not_used_as_features(clean_df):
    X, y, info = pp.prepare_xy(clean_df, "Churn")
    assert "CustomerID" not in X.columns and "Churn" not in X.columns
    assert set(y.unique()) == {0, 1}
    assert info["positive_label"] == "Yes"


def test_tc05_split_is_reproducible_and_stratified(clean_df):
    X, y, _ = pp.prepare_xy(clean_df, "Churn")
    a = pp.split_data(X, y)
    b = pp.split_data(X, y)
    assert list(a[0].index) == list(b[0].index)
    assert abs(a[2].mean() - a[3].mean()) < 0.01


def test_tc05_no_data_leakage_scaler_fitted_on_train_only(bundle, clean_df):
    X, y, _ = pp.prepare_xy(clean_df, "Churn")
    X_train, _, _, _ = pp.split_data(X, y, bundle["test_size"], bundle["random_state"])
    scaler = bundle["pipeline"].named_steps["preprocessor"].named_transformers_["num"].named_steps["scaler"]
    col = bundle["numeric_cols"].index("Tenure_Months")
    assert scaler.mean_[col] == pytest.approx(X_train["Tenure_Months"].mean(), rel=1e-6)
    assert scaler.mean_[col] != pytest.approx(X["Tenure_Months"].mean(), rel=1e-9)


# ------------------------------------------------------------------ TC06 training
def test_tc06_model_training_and_selection(bundle):
    assert set(bundle["models"]) == {"Logistic Regression", "Decision Tree", "Random Forest"}
    comp = bundle["comparison"].set_index("Model")
    assert bundle["best_model_name"] == comp["CV F1"].idxmax()     # not chosen by accuracy
    for col in ["Test Accuracy", "Test Precision", "Test Recall", "Test F1", "Test ROC-AUC"]:
        assert comp[col].between(0, 1).all()
    assert (comp["Test ROC-AUC"] > 0.7).all()


# ------------------------------------------------------------- TC07 / TC08 predict
def test_tc07_single_customer_prediction(bundle, clean_df):
    rec = clean_df.drop(columns=["Churn"]).iloc[0].to_dict()
    res = pr.predict_single(rec, bundle)
    assert 0 <= res["probability"] <= 1
    assert res["risk_level"] in {"Low", "Medium", "High"}
    assert res["prediction"] in {"Yes", "No"}


def test_tc07_inactive_complaining_customer_riskier_than_loyal_one(bundle, clean_df):
    base = clean_df.drop(columns=["Churn"]).iloc[0].to_dict()
    bad = dict(base, Days_Since_Last_Purchase=250, Complaints=6, App_Sessions_Per_Month=1, Purchase_Frequency=0.1)
    good = dict(base, Days_Since_Last_Purchase=2, Complaints=0, App_Sessions_Per_Month=40, Purchase_Frequency=4)
    assert pr.predict_single(bad, bundle)["probability"] > pr.predict_single(good, bundle)["probability"] + 0.3


def test_tc07_risk_thresholds():
    assert pr.risk_level(0.10, 0.3, 0.6) == "Low"
    assert pr.risk_level(0.30, 0.3, 0.6) == "Medium"
    assert pr.risk_level(0.60, 0.3, 0.6) == "High"


def test_tc08_bulk_prediction_without_target_column(bundle, clean_df):
    batch = clean_df.drop(columns=["Churn"]).head(200)
    out, warns = pr.predict_dataframe(batch, bundle)
    assert len(out) == 200
    assert {"Churn_Probability", "Predicted_Churn", "Risk_Level"} <= set(out.columns)
    assert "CustomerID" in out.columns                       # identifiers are kept for the user


def test_tc08_bulk_prediction_ignores_extra_columns_and_bad_numbers(bundle, clean_df):
    batch = clean_df.drop(columns=["Churn"]).head(5).copy()
    batch["Notes"] = "x"
    batch["Age"] = batch["Age"].astype(object)
    batch.loc[0, "Age"] = "abc"
    out, warns = pr.predict_dataframe(batch, bundle)
    assert len(out) == 5 and any("non-numeric" in w for w in warns)


def test_tc09_missing_required_columns_raise_clear_error(bundle, clean_df):
    batch = clean_df.drop(columns=["Churn", "Complaints", "Age"]).head(5)
    with pytest.raises(pr.PredictionError) as err:
        pr.predict_dataframe(batch, bundle)
    assert "Complaints" in str(err.value) and "Age" in str(err.value)


def test_tc09_template_has_all_required_columns_and_scores(bundle):
    tpl = pr.template_dataframe(bundle)
    out, _ = pr.predict_dataframe(tpl, bundle)
    assert len(out) == 3


# --------------------------------------------------------------- TC10 CSV download
def test_tc10_csv_download_roundtrip(bundle, clean_df):
    out, _ = pr.predict_dataframe(clean_df.drop(columns=["Churn"]).head(50), bundle)
    data = out.to_csv(index=False).encode("utf-8-sig")
    back = pd.read_csv(io.BytesIO(data))
    assert list(back.columns) == list(out.columns) and len(back) == 50
    rep = reports.build_analysis_report(bundle, eda.add_churn_flag(clean_df, "Churn"), out)
    assert {"Section", "Item", "Value", "Notes"} == set(rep.columns) and len(rep) > 10


# ------------------------------------------------------------ TC11 persistence
def test_tc11_model_persistence_and_reload(bundle, clean_df, tmp_path):
    path = tm.save_bundle(bundle, tmp_path / "m.joblib")
    loaded = tm.load_bundle(path)
    batch = clean_df.drop(columns=["Churn"]).head(100)
    a, _ = pr.predict_dataframe(batch, bundle)
    b, _ = pr.predict_dataframe(batch, loaded)
    assert np.allclose(a["Churn_Probability"], b["Churn_Probability"])
    assert loaded["best_model_name"] == bundle["best_model_name"]


def test_tc11_missing_model_returns_none_and_corrupt_file_errors(tmp_path):
    assert tm.load_bundle(tmp_path / "nope.joblib") is None
    bad = tmp_path / "bad.joblib"
    bad.write_bytes(b"not a model")
    with pytest.raises(tm.ModelLoadError):
        tm.load_bundle(bad)


# ----------------------------------------------- TC12 confusion matrix and metrics
def test_tc12_confusion_matrix_and_metrics_consistent(bundle):
    for name, res in bundle["results"].items():
        t = res["test"]
        (tn, fp), (fn, tp) = t["confusion_matrix"]
        assert tn + fp + fn + tp == bundle["n_test"]
        assert t["accuracy"] == pytest.approx((tp + tn) / bundle["n_test"])
        assert t["precision"] == pytest.approx(tp / (tp + fp))
        assert t["recall"] == pytest.approx(tp / (tp + fn))
        assert t["f1"] == pytest.approx(2 * tp / (2 * tp + fp + fn))
        assert 0.5 < t["roc_auc"] <= 1
        assert "roc_curve" in t and "No" in t["report"] and "Yes" in t["report"]


# ------------------------------------------------- explainability / recommendations
def test_tc13_feature_importance_for_all_models(bundle):
    for name in bundle["models"]:
        out = ex.builtin_importance(bundle, name)
        assert out["kind"] in {"importance", "coefficients"} and len(out["table"]) > 3
    assert len(bundle["permutation_importance"]) == len(bundle["feature_columns"])


def test_tc13_individual_explanation(bundle, clean_df):
    rec = clean_df.drop(columns=["Churn"]).iloc[1].to_dict()
    tab = ex.explain_customer(rec, bundle, 5)
    assert len(tab) == 5 and {"Feature", "Risk Change (pts)", "Effect"} <= set(tab.columns)


def test_tc14_recommendations_linked_to_data_and_risk(bundle, clean_df):
    row = clean_df.drop(columns=["Churn"]).iloc[0].to_dict()
    row.update(Days_Since_Last_Purchase=300, Complaints=3, Total_Spending=1e6)
    segs = [r["Segment"] for r in rc.recommend_for_customer(row, "High", bundle)]
    assert {"Inactive customer", "Unresolved complaints", "High-value at risk"} <= set(segs)
    low = rc.recommend_for_customer(row, "Low", bundle)
    assert low[0]["Segment"] == "Low risk"


def test_tc14_works_for_custom_dataset_with_other_columns():
    """The pipeline must not depend on the sample dataset's column names."""
    rng = np.random.default_rng(1)
    n = 400
    df = pd.DataFrame({"cust_id": range(n), "orders": rng.poisson(5, n), "spend": rng.gamma(2, 100, n),
                       "plan": rng.choice(["a", "b"], n)})
    df["left"] = np.where(df["orders"] + rng.normal(0, 2, n) < 4, "yes", "no")
    b = tm.train_and_compare(df)
    assert b["target_col"] == "left" and "cust_id" not in b["feature_columns"]
    out, _ = pr.predict_dataframe(df.drop(columns=["left"]).head(10), b)
    assert len(out) == 10
    assert rc.recommend_for_customer(out.iloc[0], out.iloc[0]["Risk_Level"], b)   # no crash without known roles


def test_tc15_training_rejects_tiny_dataset():
    df = pd.DataFrame({"a": range(10), "churn": ["Yes", "No"] * 5})
    with pytest.raises(pp.PreprocessingError):
        tm.train_and_compare(df)


# ------------------------------------------------------------------- charts / UI
def test_tc16_eda_charts_build(clean_df):
    dfx = eda.add_churn_flag(clean_df, "Churn")
    num, cat = eda.feature_lists(dfx, "Churn")
    k = eda.compute_kpis(dfx)
    assert k["total"] == len(dfx) and k["churned"] + k["retained"] == k["total"]
    assert k["churn_rate"] == pytest.approx(dfx["_churn_flag"].mean() * 100)
    for fig in [eda.churn_bar(dfx), eda.churn_donut(dfx), eda.histogram(dfx, "Total_Spending"),
                eda.box_plot(dfx, "Tenure_Months"), eda.churn_rate_by_category(dfx, "Membership_Type"),
                eda.churn_rate_by_category(dfx, "Complaints"), eda.correlation_heatmap(dfx, num)]:
        assert fig is not None


def test_tc17_streamlit_app_all_pages_render_and_predict():
    st_testing = pytest.importorskip("streamlit.testing.v1")
    at = st_testing.AppTest.from_file(str(config.BASE_DIR / "app.py"), default_timeout=180).run()
    assert not at.exception
    pages = [r for r in at.sidebar.radio[0].options]
    assert len(pages) == 10
    for page in pages:
        at.session_state["nav"] = page
        at.run()
        assert not at.exception, f"{page}: {[e.value for e in at.exception]}"
    if config.MODEL_PATH.exists():                      # form submit + bulk demo only if a model is saved
        at.session_state["nav"] = pages[5]
        at.run()
        next(b for b in at.button if b.label == "Use the loaded dataset as a demo").click().run()
        assert not at.exception and not at.error
