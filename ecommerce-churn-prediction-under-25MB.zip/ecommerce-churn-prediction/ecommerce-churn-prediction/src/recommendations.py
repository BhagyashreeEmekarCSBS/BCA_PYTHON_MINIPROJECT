"""
recommendations.py - rule-based retention suggestions.

Rules use only columns that exist in the trained model and compare a customer
with the training data (quartiles). The app only SUGGESTS actions; it never
sends emails, discounts or notifications.
"""
from __future__ import annotations

import pandas as pd

from src import data_loader as dl

# keywords used to find the "role" of a column (works for custom datasets too)
ROLE_KEYWORDS = {
    "recency": ["days_since", "recency", "last_purchase", "days_inactive", "inactive"],
    "complaints": ["complaint"],
    "support": ["support", "ticket"],
    "engagement": ["session", "engagement", "visit", "login", "app_"],
    "frequency": ["purchase_freq", "orders_per", "frequency"],
    "spending": ["total_spend", "spending", "monetary", "revenue", "total_amount"],
}

RULE_TABLE = pd.DataFrame([
    ("Inactive customer", "Days since last purchase above the 75th percentile",
     "Personalised re-engagement campaign (reminder email/SMS with products they viewed)"),
    ("Falling purchase frequency", "Purchase frequency below the 25th percentile",
     "Targeted reminders and replenishment / 'back in stock' notifications"),
    ("Unresolved complaints", "One or more complaints",
     "Fast-track customer-support follow-up and issue resolution"),
    ("Heavy support usage", "Support interactions above the 75th percentile",
     "Proactive outreach by a support agent to fix recurring problems"),
    ("Low engagement", "App / website sessions below the 25th percentile",
     "Personalised product recommendations and win-back campaign"),
    ("High-value at risk", "Total spending above the 75th percentile AND Medium/High risk",
     "Personalised loyalty benefits or account-manager contact"),
    ("Low risk", "Churn risk is Low", "Keep standard communication; reward loyalty occasionally"),
], columns=["Segment", "Trigger (compared with training data)", "Suggested action"])


def map_roles(bundle: dict) -> dict:
    """Find which numeric feature plays which business role."""
    numeric = bundle["numeric_cols"]
    used, roles = set(), {}
    for role, keywords in ROLE_KEYWORDS.items():
        col = dl.find_column(numeric, keywords, exclude=used)
        if col:
            roles[role] = col
            used.add(col)
    return roles


def recommend_for_customer(row, risk: str, bundle: dict) -> list:
    """Return a list of dicts: Priority, Segment, Action, Reason (most important first)."""
    ref = bundle["reference"]["numeric"]
    roles = map_roles(bundle)
    recs = []

    def val(role):
        col = roles.get(role)
        if col is None or col not in row:
            return None, None
        v = pd.to_numeric(row[col], errors="coerce")
        return (None, col) if pd.isna(v) else (float(v), col)

    if risk == "Low":
        return [{"Priority": "Low", "Segment": "Low risk",
                 "Action": "Keep standard communication and reward loyalty occasionally.",
                 "Reason": "Predicted churn probability is below the low-risk threshold."}]

    v, col = val("spending")
    if v is not None and v > ref[col]["q75"]:
        recs.append(("High", "High-value at risk",
                     "Offer personalised loyalty benefits or a personal outreach from an account manager.",
                     f"{col} = {v:,.0f} is in the top quarter of customers and the churn risk is {risk}."))
    v, col = val("recency")
    if v is not None and v > ref[col]["q75"]:
        recs.append(("High", "Inactive customer",
                     "Send a personalised re-engagement campaign (reminder, curated products, limited-time offer).",
                     f"{col} = {v:,.0f} is higher than for 75% of customers."))
    v, col = val("complaints")
    if v is not None and v >= 1:
        recs.append(("High", "Unresolved complaints",
                     "Prioritise this customer for fast support follow-up and issue resolution.",
                     f"{col} = {v:,.0f}."))
    v, col = val("support")
    if v is not None and v > ref[col]["q75"]:
        recs.append(("Medium", "Heavy support usage",
                     "Contact the customer proactively to understand and fix recurring problems.",
                     f"{col} = {v:,.0f} is above the typical level."))
    v, col = val("frequency")
    if v is not None and v < ref[col]["q25"]:
        recs.append(("Medium", "Low purchase frequency",
                     "Send targeted purchase reminders and replenishment suggestions.",
                     f"{col} = {v:,.2f} is lower than for 75% of customers."))
    v, col = val("engagement")
    if v is not None and v < ref[col]["q25"]:
        recs.append(("Medium", "Low engagement",
                     "Run a win-back campaign with relevant product recommendations to bring them back to the app/site.",
                     f"{col} = {v:,.0f} is lower than for 75% of customers."))
    if not recs:
        recs.append(("Medium", "General retention",
                     "Review the customer's history and send a friendly check-in or feedback survey.",
                     f"Risk is {risk}, but no single behaviour stands out in the available data."))
    order = {"High": 0, "Medium": 1, "Low": 2}
    recs.sort(key=lambda r: order[r[0]])
    return [dict(zip(["Priority", "Segment", "Action", "Reason"], r)) for r in recs]


def add_recommendations(pred_df: pd.DataFrame, bundle: dict) -> pd.DataFrame:
    """Add 'Primary_Recommendation' (and a count) to a prediction table."""
    out = pred_df.copy()
    primary, count = [], []
    for _, row in out.iterrows():
        recs = recommend_for_customer(row, row["Risk_Level"], bundle)
        primary.append(recs[0]["Segment"] + ": " + recs[0]["Action"])
        count.append(len(recs))
    out["Primary_Recommendation"] = primary
    out["Recommendation_Count"] = count
    return out
