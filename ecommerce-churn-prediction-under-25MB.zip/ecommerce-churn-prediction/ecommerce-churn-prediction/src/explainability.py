"""
explainability.py - which factors are linked with churn?

IMPORTANT: importance scores and coefficients show ASSOCIATION, not CAUSATION.
A feature that predicts churn is not necessarily the reason customers leave.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import config
from src import eda
from src import predict as pr

CAUSATION_NOTE = ("Feature importance and coefficients describe how strongly a feature is **associated** "
                  "with churn in this dataset. They do **not** prove that the feature **causes** churn. "
                  "Always validate findings with business knowledge or controlled experiments.")


def _original_feature(transformed_name: str, categorical_cols) -> str:
    """Map a one-hot name such as 'cat__Membership_Type_Gold' back to 'Membership_Type'."""
    name = transformed_name.split("__", 1)[-1]
    for col in sorted(categorical_cols, key=len, reverse=True):
        if name.startswith(col + "_"):
            return col
    return name


def builtin_importance(bundle: dict, model_name: str) -> dict:
    """Model-specific importance.
    Tree models -> feature_importances_ (grouped by original column).
    Logistic Regression -> coefficients per encoded feature."""
    pipe = bundle["models"][model_name]
    pre, model = pipe.named_steps["preprocessor"], pipe.named_steps["model"]
    names = list(pre.get_feature_names_out())
    cats = bundle["categorical_cols"]
    if hasattr(model, "feature_importances_"):
        df = pd.DataFrame({"Feature": [_original_feature(n, cats) for n in names],
                           "Importance": model.feature_importances_})
        df = df.groupby("Feature", as_index=False)["Importance"].sum()
        return {"kind": "importance", "table": df.sort_values("Importance", ascending=False).reset_index(drop=True)}
    if hasattr(model, "coef_"):
        coef = model.coef_[0]
        df = pd.DataFrame({"Feature": [n.split("__", 1)[-1] for n in names], "Coefficient": coef})
        df["Odds Ratio"] = np.exp(df["Coefficient"])
        df["Effect"] = np.where(df["Coefficient"] > 0, "Raises churn risk", "Lowers churn risk")
        df = df.reindex(df["Coefficient"].abs().sort_values(ascending=False).index).reset_index(drop=True)
        return {"kind": "coefficients", "table": df}
    return {"kind": "none", "table": pd.DataFrame()}


def churn_group_comparison(dfx: pd.DataFrame, numeric_cols) -> pd.DataFrame:
    """Average of each numeric feature for churned vs retained customers (facts from the data)."""
    rows = []
    for col in numeric_cols:
        if col not in dfx.columns:
            continue
        c = dfx.loc[dfx[eda.FLAG] == 1, col].mean()
        r = dfx.loc[dfx[eda.FLAG] == 0, col].mean()
        diff = (c - r) / abs(r) * 100 if pd.notna(r) and r != 0 else np.nan
        rows.append({"Feature": col, "Churned Avg": round(c, 2), "Retained Avg": round(r, 2),
                     "Difference %": round(diff, 1) if pd.notna(diff) else np.nan})
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.reindex(out["Difference %"].abs().sort_values(ascending=False).index).reset_index(drop=True)
    return out


def plain_language_factors(importance_df: pd.DataFrame, comparison: pd.DataFrame, top_n=5) -> list:
    """Short, data-backed sentences describing the top factors."""
    lines = []
    for _, row in importance_df.head(top_n).iterrows():
        feat = row["Feature"]
        text = f"**{feat}** is among the most influential inputs for the selected model"
        if comparison is not None and not comparison.empty and feat in set(comparison["Feature"]):
            c = comparison[comparison["Feature"] == feat].iloc[0]
            text += (f" - churned customers average {c['Churned Avg']} versus "
                     f"{c['Retained Avg']} for retained customers in this dataset")
        lines.append(text + ".")
    return lines


def explain_customer(record: dict | pd.Series, bundle: dict, top_n=6) -> pd.DataFrame:
    """Local 'what-if' explanation for ONE customer.
    For each feature we replace the customer's value by a typical value (median / most common)
    and see how much the churn probability changes. Positive change = this value raises risk.
    Works for every model type and is only an association, not a cause."""
    pipe, ref = bundle["pipeline"], bundle["reference"]
    cols = bundle["feature_columns"]
    row = pd.DataFrame([dict(record)])
    X, _ = pr.prepare_input(row, bundle)
    base = float(pipe.predict_proba(X)[0, 1])

    variants = pd.concat([X] * len(cols), ignore_index=True)
    typical = {}
    for i, col in enumerate(cols):
        typical[col] = ref["numeric"][col]["median"] if col in ref["numeric"] else ref["categorical"][col]["mode"]
        variants.loc[i, col] = typical[col]
    alt = pipe.predict_proba(variants)[:, 1]

    rows = []
    for i, col in enumerate(cols):
        delta = base - float(alt[i])
        value = X.iloc[0][col]
        t = typical[col]
        rows.append({"Feature": col,
                     "Customer Value": round(value, 2) if isinstance(value, (int, float, np.number)) and pd.notna(value) else value,
                     "Typical Value": round(t, 2) if isinstance(t, (int, float, np.number)) else t,
                     "Risk Change (pts)": round(delta * 100, 1),
                     "Effect": "Raises risk" if delta > 0.005 else ("Lowers risk" if delta < -0.005 else "Little effect")})
    out = pd.DataFrame(rows)
    out["Customer Value"] = out["Customer Value"].astype(str)   # mixed numbers/text -> text for display
    out["Typical Value"] = out["Typical Value"].astype(str)
    out = out.reindex(out["Risk Change (pts)"].abs().sort_values(ascending=False).index).head(top_n)
    return out.reset_index(drop=True)
