"""
predict.py - single-customer and bulk predictions using the saved bundle.
The SAME pipeline used in training is applied, so preprocessing is identical.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import config
from src import preprocessing as pp


class PredictionError(Exception):
    """Raised when prediction input is invalid."""


def risk_level(probability: float, low=config.LOW_RISK_THRESHOLD, high=config.HIGH_RISK_THRESHOLD) -> str:
    """Convert a churn probability into Low / Medium / High risk."""
    if probability >= high:
        return "High"
    if probability >= low:
        return "Medium"
    return "Low"


def check_columns(df: pd.DataFrame, bundle: dict):
    """Return (missing_required_columns, ignored_extra_columns)."""
    required = bundle["feature_columns"]
    missing = [c for c in required if c not in df.columns]
    extra = [c for c in df.columns if c not in required]
    return missing, extra


def prepare_input(df: pd.DataFrame, bundle: dict):
    """Select the required columns and fix their types. Returns (X, warnings)."""
    missing, _ = check_columns(df, bundle)
    if missing:
        raise PredictionError("Missing required column(s): " + ", ".join(missing))
    X = df[bundle["feature_columns"]].copy()
    warnings = []
    for col in bundle["numeric_cols"]:
        before = X[col].notna().sum()
        X[col] = pd.to_numeric(X[col], errors="coerce")
        bad = int(before - X[col].notna().sum())
        if bad:
            warnings.append(f"{bad} non-numeric value(s) in '{col}' were treated as missing.")
    X = pp.coerce_feature_types(X, bundle["numeric_cols"], bundle["categorical_cols"])
    return X, warnings


def predict_dataframe(df: pd.DataFrame, bundle: dict, low=config.LOW_RISK_THRESHOLD,
                      high=config.HIGH_RISK_THRESHOLD):
    """Predict for many customers. The target column is NOT needed (and is ignored).
    Returns (results_dataframe, warnings)."""
    if df is None or df.empty:
        raise PredictionError("The prediction file contains no rows.")
    if low >= high:
        raise PredictionError("The low-risk threshold must be smaller than the high-risk threshold.")
    X, warnings = prepare_input(df, bundle)
    proba = bundle["pipeline"].predict_proba(X)[:, 1]
    out = df.copy().reset_index(drop=True)
    out["Churn_Probability"] = np.round(proba, 4)
    out["Predicted_Churn"] = np.where(proba >= 0.5, bundle["positive_label"], bundle["negative_label"])
    out["Risk_Level"] = [risk_level(p, low, high) for p in proba]
    return out, warnings


def predict_single(record: dict, bundle: dict, low=config.LOW_RISK_THRESHOLD, high=config.HIGH_RISK_THRESHOLD) -> dict:
    """Predict for one customer given as {column: value}."""
    result, _ = predict_dataframe(pd.DataFrame([record]), bundle, low, high)
    row = result.iloc[0]
    return {"probability": float(row["Churn_Probability"]), "prediction": row["Predicted_Churn"],
            "risk_level": row["Risk_Level"], "is_churn": float(row["Churn_Probability"]) >= 0.5}


def template_dataframe(bundle: dict, n_rows=3) -> pd.DataFrame:
    """Example CSV with the required columns (typical values) for users to fill in."""
    ref = bundle["reference"]
    data = {}
    for col in bundle["feature_columns"]:
        if col in ref["numeric"]:
            r = ref["numeric"][col]
            vals = [r["q25"], r["median"], r["q75"]][:n_rows]
            data[col] = [round(v) if r["is_integer"] else round(v, 2) for v in vals]
        else:
            vals = ref["categorical"][col]["values"]
            data[col] = [vals[i % len(vals)] for i in range(n_rows)]
    return pd.DataFrame(data)
