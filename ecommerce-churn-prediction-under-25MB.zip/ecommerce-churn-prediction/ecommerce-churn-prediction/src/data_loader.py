"""
data_loader.py - load, validate, clean and describe customer datasets.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import config


class DatasetError(Exception):
    """Raised when a dataset cannot be loaded or is not usable."""


# ------------------------------------------------------------------ loading
def load_csv(source) -> pd.DataFrame:
    """Read a CSV from a file path or an uploaded file object.
    Any problem is converted into a DatasetError with a friendly message."""
    try:
        try:
            df = pd.read_csv(source)
        except UnicodeDecodeError:
            # Some Excel files are not UTF-8; try again with a common alternative
            if hasattr(source, "seek"):
                source.seek(0)
            df = pd.read_csv(source, encoding="latin-1")
    except FileNotFoundError as exc:
        raise DatasetError(f"File not found: {source}") from exc
    except pd.errors.EmptyDataError as exc:
        raise DatasetError("The file is empty. Please upload a CSV that contains data.") from exc
    except pd.errors.ParserError as exc:
        raise DatasetError(f"The file is not a valid CSV file ({exc}).") from exc
    except Exception as exc:  # any other unexpected reading problem
        raise DatasetError(f"Could not read the file: {exc}") from exc

    df.columns = [str(c).strip() for c in df.columns]
    if df.empty or df.shape[1] < 2:
        raise DatasetError("The CSV must contain at least 2 columns and 1 row.")
    if df.columns.duplicated().any():
        raise DatasetError("The CSV contains duplicate column names. Please rename them.")
    return df


def load_sample() -> pd.DataFrame:
    """Load the included synthetic sample dataset."""
    if not config.SAMPLE_DATA_PATH.exists():
        raise DatasetError(
            f"Sample dataset not found at {config.SAMPLE_DATA_PATH}. "
            "Run:  python data/generate_sample_data.py")
    return load_csv(config.SAMPLE_DATA_PATH)


# ------------------------------------------------------------ small helpers
def find_column(columns, keywords, exclude=()):
    """Return the first column whose name contains one of the keywords."""
    for kw in keywords:
        for col in columns:
            if col not in exclude and kw in str(col).lower():
                return col
    return None


def detect_target_column(df: pd.DataFrame):
    """Guess which column holds the churn label (None if no good guess)."""
    lowered = {str(c).lower().replace(" ", "_"): c for c in df.columns}
    for cand in config.TARGET_CANDIDATES:
        if cand in lowered and df[lowered[cand]].dropna().nunique() == 2:
            return lowered[cand]
    for low, original in lowered.items():
        if "churn" in low and df[original].dropna().nunique() == 2:
            return original
    return None


# --------------------------------------------------------------- validation
def validate_dataframe(df: pd.DataFrame, target_col=None) -> dict:
    """Check a dataset and return {'errors': [...], 'warnings': [...]}.
    Errors stop training; warnings are only advice."""
    errors, warnings = [], []
    if df is None or df.empty:
        return {"errors": ["No data loaded."], "warnings": []}

    if len(df) < config.MIN_ROWS:
        errors.append(f"Dataset has only {len(df)} rows; at least {config.MIN_ROWS} are required.")

    if target_col is None:
        errors.append("Required column missing: no churn/target column was found. "
                      "Select it manually on the Preprocessing page.")
    elif target_col not in df.columns:
        errors.append(f"Required column missing: target column '{target_col}' is not in the data.")
    else:
        n_classes = df[target_col].dropna().nunique()
        if n_classes != 2:
            errors.append(f"Target column '{target_col}' must have exactly 2 values "
                          f"(e.g. Yes/No) but has {n_classes}.")
        else:
            rate = (df[target_col].value_counts(normalize=True).min()) * 100
            if rate < 10:
                warnings.append(f"Strong class imbalance: the minority class is only {rate:.1f}% of rows. "
                                "Class weights are used to compensate.")
        missing_target = int(df[target_col].isna().sum())
        if missing_target:
            warnings.append(f"{missing_target} rows have no target value and will be removed.")

    dup = int(df.duplicated().sum())
    if dup:
        warnings.append(f"{dup} duplicate rows detected (they are removed during cleaning).")

    heavy = [c for c in df.columns if df[c].isna().mean() > 0.30]
    if heavy:
        warnings.append("Columns with more than 30% missing values: " + ", ".join(map(str, heavy)))
    return {"errors": errors, "warnings": warnings}


def get_data_summary(df: pd.DataFrame) -> dict:
    """Numbers shown on the Dataset page."""
    missing = df.isna().sum()
    missing_df = pd.DataFrame({
        "Column": df.columns,
        "Data Type": df.dtypes.astype(str).values,
        "Missing Values": missing.values,
        "Missing %": (missing.values / max(len(df), 1) * 100).round(2),
        "Unique Values": [df[c].nunique() for c in df.columns],
    })
    return {"rows": len(df), "columns": df.shape[1],
            "duplicates": int(df.duplicated().sum()),
            "missing_cells": int(missing.sum()), "table": missing_df}


# ----------------------------------------------------------------- cleaning
def clean_dataframe(df: pd.DataFrame, target_col=None):
    """Light cleaning that is safe to do BEFORE the train/test split:
    trim text, treat blanks as missing, remove exact duplicates and rows with
    no target. Missing feature values are NOT filled here - they are filled
    later inside the ML pipeline using training data only (prevents leakage)."""
    out = df.copy()
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].map(lambda v: v.strip() if isinstance(v, str) else v)
            out[col] = out[col].replace("", np.nan)
    before = len(out)
    out = out.drop_duplicates()
    duplicates_removed = before - len(out)
    missing_target_removed = 0
    if target_col and target_col in out.columns:
        n = len(out)
        out = out.dropna(subset=[target_col])
        missing_target_removed = n - len(out)
    out = out.reset_index(drop=True)
    return out, {"duplicates_removed": duplicates_removed,
                 "missing_target_removed": missing_target_removed,
                 "rows_before": before, "rows_after": len(out)}


# ---------------------------------------------------------- data dictionary
def build_data_dictionary(df: pd.DataFrame, target_col=None) -> pd.DataFrame:
    """Table that explains each column (known descriptions for the sample data)."""
    rows = []
    for col in df.columns:
        desc = config.DATA_DESCRIPTIONS.get(col)
        if desc is None:
            desc = "Target (churn) column." if col == target_col else "No description available (custom dataset)."
        example = df[col].dropna().iloc[0] if df[col].notna().any() else ""
        rows.append({"Column": col, "Type": str(df[col].dtype), "Description": desc,
                     "Example": str(example), "Missing %": round(df[col].isna().mean() * 100, 2)})
    return pd.DataFrame(rows)
