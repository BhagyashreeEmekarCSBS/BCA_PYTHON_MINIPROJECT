"""
eda.py - Exploratory Data Analysis helpers (charts + KPIs + insights).
Every function works only with columns that exist in the supplied dataset.
"""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")                      # draw charts without a pop-up window
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import seaborn as sns

import config
from src import data_loader as dl
from src import preprocessing as pp

FLAG = "_churn_flag"          # 1 = churned, 0 = retained
STATUS = "Customer Status"    # "Churned" / "Retained"
COLOR_MAP = {"Retained": config.COLORS["retained"], "Churned": config.COLORS["churned"]}


# ------------------------------------------------------------------ helpers
def add_churn_flag(df: pd.DataFrame, target_col: str, positive_label=None) -> pd.DataFrame:
    """Return a copy with a numeric churn flag and a readable status column."""
    y, _, _ = pp.to_binary_target(df[target_col], positive_label)
    out = df.copy()
    out[FLAG] = y
    out = out.dropna(subset=[FLAG])
    out[FLAG] = out[FLAG].astype(int)
    out[STATUS] = out[FLAG].map({1: "Churned", 0: "Retained"})
    return out.reset_index(drop=True)


def _style(fig, title=None, height=380):
    fig.update_layout(
        template="plotly_white", height=height, margin=dict(l=20, r=20, t=55, b=20),
        title=dict(text=title, x=0.01, font=dict(size=16, color=config.COLORS["navy"])) if title else None,
        font=dict(family="Segoe UI, Inter, sans-serif", color=config.COLORS["navy"]),
        legend_title_text="", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
    return fig


def feature_lists(dfx: pd.DataFrame, target_col=None):
    """Numeric and categorical feature columns of a flagged dataframe (IDs removed)."""
    base = dfx.drop(columns=[FLAG, STATUS], errors="ignore")
    cols = pp.get_feature_columns(base, target_col)
    return cols["numeric"], cols["categorical"]


def compute_kpis(dfx: pd.DataFrame) -> dict:
    total = len(dfx)
    churned = int(dfx[FLAG].sum())
    aov_col = dl.find_column(dfx.columns, ["avg_order", "average_order", "aov", "order_value",
                                           "avg_purchase", "average_purchase"])
    aov = float(pd.to_numeric(dfx[aov_col], errors="coerce").mean()) if aov_col else None
    return {"total": total, "churned": churned, "retained": total - churned,
            "churn_rate": churned / total * 100 if total else 0,
            "retention_rate": (total - churned) / total * 100 if total else 0,
            "avg_purchase_value": aov, "aov_col": aov_col}


# ------------------------------------------------------------------- charts
def churn_bar(dfx):
    counts = dfx[STATUS].value_counts().reindex(["Retained", "Churned"]).reset_index()
    counts.columns = [STATUS, "Customers"]
    fig = px.bar(counts, x=STATUS, y="Customers", color=STATUS, color_discrete_map=COLOR_MAP, text="Customers")
    fig.update_traces(textposition="outside")
    return _style(fig, "Retained vs churned customers").update_layout(showlegend=False)


def churn_donut(dfx):
    fig = px.pie(dfx, names=STATUS, hole=0.55, color=STATUS, color_discrete_map=COLOR_MAP)
    fig.update_traces(textinfo="percent+label")
    return _style(fig, "Churn distribution").update_layout(showlegend=False)


def histogram(dfx, col, nbins=40):
    fig = px.histogram(dfx, x=col, color=STATUS, nbins=nbins, barmode="overlay", opacity=0.7,
                       color_discrete_map=COLOR_MAP, marginal="box")
    return _style(fig, f"Distribution of {col}", 420)


def box_plot(dfx, col):
    fig = px.box(dfx, x=STATUS, y=col, color=STATUS, color_discrete_map=COLOR_MAP,
                 category_orders={STATUS: ["Retained", "Churned"]})
    return _style(fig, f"{col} by customer status").update_layout(showlegend=False)


def churn_rate_by_category(dfx, col):
    """Bar chart of churn % for each value of a categorical (or low-count numeric) column."""
    g = dfx.groupby(col)[FLAG].agg(["mean", "count"]).reset_index()
    g["Churn %"] = (g["mean"] * 100).round(1)
    g[col] = g[col].astype(str) if not pd.api.types.is_numeric_dtype(dfx[col]) else g[col]
    g = g.sort_values(col if pd.api.types.is_numeric_dtype(dfx[col]) else "Churn %",
                      ascending=pd.api.types.is_numeric_dtype(dfx[col]))
    fig = px.bar(g, x=col, y="Churn %", text="Churn %", hover_data={"count": True},
                 color="Churn %", color_continuous_scale=["#99E2DD", config.COLORS["churned"]])
    overall = dfx[FLAG].mean() * 100
    fig.add_hline(y=overall, line_dash="dash", line_color=config.COLORS["navy"],
                  annotation_text=f"Overall {overall:.1f}%")
    fig.update_traces(textposition="outside")
    if pd.api.types.is_numeric_dtype(dfx[col]):
        fig.update_xaxes(type="category")
    return _style(fig, f"Churn rate by {col}").update_layout(coloraxis_showscale=False)


def churn_rate_by_bins(dfx, col, bins=8):
    """Churn % across equal-sized groups of a continuous column."""
    try:
        groups = pd.qcut(dfx[col], q=bins, duplicates="drop")
    except ValueError:
        return None
    g = dfx.groupby(groups, observed=True)[FLAG].mean().reset_index()
    g[col] = g[col].astype(str)
    g["Churn %"] = (g[FLAG] * 100).round(1)
    fig = px.line(g, x=col, y="Churn %", markers=True)
    fig.update_traces(line_color=config.COLORS["churned"])
    return _style(fig, f"Churn rate across {col} groups")


def correlation_heatmap(dfx, numeric_cols):
    """Seaborn heatmap of correlations (includes the churn flag)."""
    data = dfx[numeric_cols].apply(pd.to_numeric, errors="coerce").copy()
    data["Churn (1/0)"] = dfx[FLAG]
    corr = data.corr()
    size = max(6, min(14, 0.6 * len(corr) + 3))
    fig, ax = plt.subplots(figsize=(size, size * 0.75))
    sns.heatmap(corr, annot=len(corr) <= 14, fmt=".2f", cmap="RdBu_r", center=0,
                linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax, annot_kws={"size": 8})
    ax.set_title("Correlation heatmap", fontsize=13, color=config.COLORS["navy"], loc="left")
    plt.xticks(rotation=45, ha="right")
    fig.tight_layout()
    return fig


def confusion_matrix_fig(cm, labels):
    z = np.array(cm)
    fig = go.Figure(go.Heatmap(z=z, x=[f"Predicted {l}" for l in labels], y=[f"Actual {l}" for l in labels],
                               text=z, texttemplate="%{text}", colorscale=[[0, "#E6F7F6"], [1, config.COLORS["teal"]]],
                               showscale=False, textfont=dict(size=20)))
    fig.update_yaxes(autorange="reversed")
    return _style(fig, "Confusion matrix (test set)", 360)


def roc_fig(results: dict):
    fig = go.Figure()
    palette = [config.COLORS["teal"], config.COLORS["blue"], config.COLORS["churned"]]
    for i, (name, res) in enumerate(results.items()):
        rc = res["test"].get("roc_curve")
        if rc:
            fig.add_trace(go.Scatter(x=rc["fpr"], y=rc["tpr"], mode="lines", name=f"{name} (AUC {res['test']['roc_auc']:.3f})",
                                     line=dict(color=palette[i % 3], width=3)))
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Random guess",
                             line=dict(color=config.COLORS["grey"], dash="dash")))
    fig.update_xaxes(title="False positive rate")
    fig.update_yaxes(title="True positive rate")
    return _style(fig, "ROC curves (test set)", 420)


# ---------------------------------------------------------------- insights
def generate_insights(dfx: pd.DataFrame, numeric_cols, categorical_cols, max_items=5) -> list:
    """Plain-English findings calculated from the data (nothing hard-coded)."""
    insights = []
    overall = dfx[FLAG].mean() * 100
    stats = []
    for col in numeric_cols:
        c = pd.to_numeric(dfx.loc[dfx[FLAG] == 1, col], errors="coerce")
        r = pd.to_numeric(dfx.loc[dfx[FLAG] == 0, col], errors="coerce")
        sd = pd.to_numeric(dfx[col], errors="coerce").std()
        if sd and not np.isnan(sd) and c.notna().any() and r.notna().any():
            stats.append((abs(c.mean() - r.mean()) / sd, col, c.mean(), r.mean()))
    for _, col, mc, mr in sorted(stats, reverse=True)[:3]:
        insights.append(f"Churned customers average **{mc:,.1f}** for *{col}* compared with **{mr:,.1f}** for retained customers.")
    best = None
    for col in categorical_cols:
        if dfx[col].nunique() > 12:
            continue
        g = dfx.groupby(col)[FLAG].agg(["mean", "count"])
        g = g[g["count"] >= 30]
        if g.empty:
            continue
        top = g["mean"].idxmax()
        gap = g.loc[top, "mean"] * 100 - overall
        if best is None or gap > best[0]:
            best = (gap, col, top, g.loc[top, "mean"] * 100)
    if best and best[0] > 1:
        insights.append(f"Customers with *{best[1]}* = **{best[2]}** churn at **{best[3]:.1f}%**, above the overall rate of {overall:.1f}%.")
    return insights[:max_items]
