"""
preprocessing.py - turn a customer table into model-ready data.

Key ideas (good for viva):
* Identifier columns (e.g. CustomerID) are removed - they carry no behaviour.
* Missing values, scaling and encoding live INSIDE a scikit-learn Pipeline, so
  they are learned from the training set only. This prevents data leakage.
* Class imbalance is handled with class_weight='balanced' in the models.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

import config


class PreprocessingError(Exception):
    """Raised when the data cannot be prepared for modelling."""


# ------------------------------------------------------------ target handling
def guess_positive_label(uniques, series=None):
    """Decide which of the two target values means 'churned'."""
    for u in uniques:
        text = str(u).strip().lower()
        if text in config.POSITIVE_LABELS:
            return u
        try:
            if float(text) == 1.0:
                return u
        except ValueError:
            pass
    if series is not None:                      # fallback: the rarer class
        return series.value_counts().idxmin()
    return uniques[0]


def to_binary_target(series: pd.Series, positive_label=None):
    """Convert a 2-value column to 1 (churned) / 0 (retained).
    Returns (y, positive_label, negative_label)."""
    clean = series.dropna()
    uniques = list(pd.unique(clean))
    if len(uniques) != 2:
        raise PreprocessingError(
            f"The target column must contain exactly 2 different values, found {len(uniques)}.")
    if positive_label is None or positive_label not in uniques:
        positive_label = guess_positive_label(uniques, clean)
    negative_label = [u for u in uniques if u != positive_label][0]
    y = series.map({positive_label: 1, negative_label: 0})
    return y, positive_label, negative_label


# ----------------------------------------------------------- feature handling
def is_identifier(col: str, s: pd.Series) -> bool:
    """True if the column looks like an ID (name pattern or all-unique text)."""
    name = re.sub(r"[\s\-]+", "_", str(col).lower())
    if re.search(config.ID_PATTERN, name):
        return True
    n = max(len(s), 1)
    return s.dtype == object and s.nunique(dropna=True) / n > 0.98


def get_feature_columns(df: pd.DataFrame, target_col: str) -> dict:
    """Split columns into numeric / categorical and list what was dropped (and why)."""
    numeric, categorical, dropped = [], [], []
    for col in df.columns:
        if col == target_col:
            continue
        s = df[col]
        if is_identifier(col, s):
            dropped.append((col, "Identifier - not a behavioural feature"))
        elif "churn" in str(col).lower():
            dropped.append((col, "Name contains 'churn' - possible target leakage"))
        elif s.nunique(dropna=True) <= 1:
            dropped.append((col, "Constant column - no information"))
        elif pd.api.types.is_bool_dtype(s):
            categorical.append(col)
        elif pd.api.types.is_numeric_dtype(s):
            numeric.append(col)
        else:
            as_num = pd.to_numeric(s, errors="coerce")
            if s.notna().any() and as_num.notna().sum() >= 0.9 * s.notna().sum():
                numeric.append(col)             # numbers stored as text
            elif s.nunique(dropna=True) > config.MAX_CATEGORIES:
                dropped.append((col, f"More than {config.MAX_CATEGORIES} unique text values"))
            else:
                categorical.append(col)
    return {"numeric": numeric, "categorical": categorical, "dropped": dropped}


def coerce_feature_types(X: pd.DataFrame, numeric_cols, categorical_cols) -> pd.DataFrame:
    """Make column types consistent between training and prediction."""
    X = X.copy()
    for col in numeric_cols:
        X[col] = pd.to_numeric(X[col], errors="coerce")
    for col in categorical_cols:
        X[col] = X[col].map(lambda v: str(v).strip() if pd.notna(v) else np.nan).astype(object)
    return X


def build_preprocessor(numeric_cols, categorical_cols) -> ColumnTransformer:
    """Impute + scale numbers; impute + one-hot encode categories."""
    transformers = []
    if numeric_cols:
        transformers.append(("num", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]), list(numeric_cols)))
    if categorical_cols:
        transformers.append(("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]), list(categorical_cols)))
    return ColumnTransformer(transformers, remainder="drop")


# ------------------------------------------------------------------ X / y / split
def prepare_xy(df: pd.DataFrame, target_col: str, positive_label=None):
    """Return X (features), y (0/1 target) and an info dictionary."""
    if target_col not in df.columns:
        raise PreprocessingError(f"Target column '{target_col}' not found in the dataset.")
    data = df.dropna(subset=[target_col]).copy()
    y, pos, neg = to_binary_target(data[target_col], positive_label)

    cols = get_feature_columns(data, target_col)
    if not cols["numeric"] and not cols["categorical"]:
        raise PreprocessingError("No usable feature columns remain after removing identifiers.")
    X = coerce_feature_types(data[cols["numeric"] + cols["categorical"]],
                             cols["numeric"], cols["categorical"])

    notes = []
    for col in cols["numeric"]:                  # simple leakage warning
        if X[col].nunique() > 1 and abs(X[col].corr(y)) > 0.95:
            notes.append(f"'{col}' is almost perfectly correlated with the target - check for leakage.")

    counts = y.value_counts()
    info = {
        "target_col": target_col, "positive_label": pos, "negative_label": neg,
        "numeric_cols": cols["numeric"], "categorical_cols": cols["categorical"],
        "dropped_columns": cols["dropped"], "n_rows": len(data),
        "class_counts": {str(neg): int(counts.get(0, 0)), str(pos): int(counts.get(1, 0))},
        "churn_rate": float(y.mean()),
        "imbalance_ratio": float(counts.max() / max(counts.min(), 1)),
        "notes": notes,
    }
    return X, y.astype(int), info


def split_data(X, y, test_size=config.TEST_SIZE, random_state=config.RANDOM_STATE):
    """Reproducible stratified split (both sets keep the same churn ratio)."""
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)
