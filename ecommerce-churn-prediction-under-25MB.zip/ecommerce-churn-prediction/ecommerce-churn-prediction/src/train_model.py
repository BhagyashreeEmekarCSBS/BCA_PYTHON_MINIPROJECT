"""
train_model.py - train, compare, evaluate, save and load churn models.

Workflow
1. Clean data and split into train / test (test set is never used for choosing).
2. For every algorithm build ONE Pipeline = preprocessing + classifier.
3. 5-fold cross-validation on the TRAINING set -> validation scores.
4. Choose the best model by validation F1 (ties -> ROC-AUC), not by accuracy.
5. Evaluate once on the untouched TEST set and save everything with Joblib.
"""
from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier

import config
from src import data_loader as dl
from src import preprocessing as pp


class ModelLoadError(Exception):
    """Raised when a saved model file exists but cannot be loaded."""


def get_models(random_state=config.RANDOM_STATE) -> dict:
    """The three algorithms compared in this project."""
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced",
                                                  random_state=random_state),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, min_samples_leaf=25,
                                                class_weight="balanced", random_state=random_state),
        "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=10, min_samples_leaf=5,
                                                class_weight="balanced", random_state=random_state,
                                                n_jobs=-1),
    }


MODEL_EXPLANATIONS = {
    "Logistic Regression": "Logistic Regression draws a statistical 'score line' through the data. "
                           "Each feature gets a weight (coefficient): positive weights push towards churn, "
                           "negative weights push away. It is fast and very easy to interpret.",
    "Decision Tree": "A Decision Tree asks a chain of yes/no questions (for example 'Days since last purchase "
                     "> 45?') and ends in a churn / no-churn decision. It is easy to visualise but a single "
                     "tree can over-fit.",
    "Random Forest": "A Random Forest builds many different decision trees on random samples of the data and "
                     "lets them vote. Combining many trees is usually more accurate and stable than one tree.",
}


# --------------------------------------------------------------- evaluation
def evaluate_model(pipeline, X, y, positive_name="Churn", negative_name="Retained") -> dict:
    """Compute all required metrics for one fitted pipeline on (X, y)."""
    proba = pipeline.predict_proba(X)[:, 1]
    pred = (proba >= 0.5).astype(int)
    result = {
        "accuracy": float(accuracy_score(y, pred)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y, proba)) if y.nunique() == 2 else float("nan"),
        "confusion_matrix": confusion_matrix(y, pred, labels=[0, 1]).tolist(),
        "report": classification_report(y, pred, target_names=[str(negative_name), str(positive_name)],
                                        output_dict=True, zero_division=0),
    }
    if y.nunique() == 2:
        fpr, tpr, _ = roc_curve(y, proba)
        result["roc_curve"] = {"fpr": fpr.tolist(), "tpr": tpr.tolist()}
    return result


def _reference_stats(X_train: pd.DataFrame, numeric_cols, categorical_cols) -> dict:
    """Typical values from the training data (used for forms and explanations)."""
    ref = {"numeric": {}, "categorical": {}}
    for col in numeric_cols:
        s = X_train[col].dropna()
        ref["numeric"][col] = {
            "min": float(s.min()), "max": float(s.max()), "mean": float(s.mean()),
            "median": float(s.median()), "q25": float(s.quantile(0.25)),
            "q75": float(s.quantile(0.75)),
            "is_integer": bool(np.allclose(s, s.round())),
        }
    for col in categorical_cols:
        s = X_train[col].dropna()
        ref["categorical"][col] = {"mode": s.mode().iloc[0] if len(s) else "",
                                   "values": sorted(s.unique().tolist())}
    return ref


# ----------------------------------------------------------------- training
def train_and_compare(df: pd.DataFrame, target_col=None, positive_label=None,
                      test_size=config.TEST_SIZE, random_state=config.RANDOM_STATE,
                      progress_callback=None) -> dict:
    """Train all models, compare them and return one 'bundle' dictionary."""
    started = time.time()
    if target_col is None:
        target_col = dl.detect_target_column(df)
    if target_col is None:
        raise pp.PreprocessingError("No target column given and none could be detected automatically.")
    if len(df) < config.MIN_ROWS:
        raise pp.PreprocessingError(f"At least {config.MIN_ROWS} rows are needed to train a model.")

    clean, _ = dl.clean_dataframe(df, target_col)
    X, y, info = pp.prepare_xy(clean, target_col, positive_label)
    if y.value_counts().min() < 10:
        raise pp.PreprocessingError("Each class needs at least 10 customers to train a reliable model.")
    X_train, X_test, y_train, y_test = pp.split_data(X, y, test_size, random_state)
    num, cat = info["numeric_cols"], info["categorical_cols"]

    cv = StratifiedKFold(n_splits=config.CV_FOLDS, shuffle=True, random_state=random_state)
    scoring = {"f1": "f1", "roc_auc": "roc_auc", "precision": "precision", "recall": "recall"}
    pos_name, neg_name = info["positive_label"], info["negative_label"]

    fitted, results, rows = {}, {}, []
    models = get_models(random_state)
    for i, (name, estimator) in enumerate(models.items()):
        if progress_callback:
            progress_callback(i / len(models), f"Training {name}...")
        pipe = Pipeline([("preprocessor", pp.build_preprocessor(num, cat)), ("model", estimator)])
        # Cross-validation re-fits the whole pipeline inside each fold (no leakage)
        cv_scores = cross_validate(pipe, X_train, y_train, cv=cv, scoring=scoring, n_jobs=1)
        pipe.fit(X_train, y_train)
        test_res = evaluate_model(pipe, X_test, y_test, pos_name, neg_name)
        train_res = evaluate_model(pipe, X_train, y_train, pos_name, neg_name)
        fitted[name] = pipe
        results[name] = {"test": test_res, "train": train_res,
                         "cv_f1": float(cv_scores["test_f1"].mean()),
                         "cv_roc_auc": float(cv_scores["test_roc_auc"].mean())}
        rows.append({
            "Model": name,
            "CV F1": results[name]["cv_f1"], "CV ROC-AUC": results[name]["cv_roc_auc"],
            "Test Accuracy": test_res["accuracy"], "Test Precision": test_res["precision"],
            "Test Recall": test_res["recall"], "Test F1": test_res["f1"],
            "Test ROC-AUC": test_res["roc_auc"],
            "Train Accuracy": train_res["accuracy"], "Train F1": train_res["f1"],
        })

    comparison = pd.DataFrame(rows)
    best_name = comparison.sort_values(["CV F1", "CV ROC-AUC"], ascending=False).iloc[0]["Model"]
    best_pipe = fitted[best_name]

    if progress_callback:
        progress_callback(0.95, "Calculating feature importance...")
    perm = permutation_importance(best_pipe, X_test, y_test, scoring="roc_auc", n_repeats=5,
                                  random_state=random_state, n_jobs=1)
    perm_df = (pd.DataFrame({"Feature": X_test.columns, "Importance": perm.importances_mean,
                             "Std": perm.importances_std})
               .sort_values("Importance", ascending=False).reset_index(drop=True))

    bundle = {
        "version": 1, "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "sklearn_version": sklearn.__version__,
        "training_seconds": round(time.time() - started, 1),
        "target_col": target_col, "positive_label": pos_name, "negative_label": neg_name,
        "numeric_cols": num, "categorical_cols": cat,
        "feature_columns": num + cat, "dropped_columns": info["dropped_columns"],
        "models": fitted, "best_model_name": best_name, "pipeline": best_pipe,
        "comparison": comparison, "results": results,
        "permutation_importance": perm_df,
        "reference": _reference_stats(X_train, num, cat),
        "data_info": info, "n_train": len(X_train), "n_test": len(X_test),
        "test_size": test_size, "random_state": random_state,
        "selection_rule": "Highest cross-validated F1-score on the training set "
                          "(ties broken by ROC-AUC). Accuracy alone is not used.",
    }
    if progress_callback:
        progress_callback(1.0, "Done")
    return bundle


# -------------------------------------------------------------- persistence
def save_bundle(bundle: dict, path=config.MODEL_PATH):
    """Save the trained model + preprocessing pipeline to one Joblib file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, path, compress=3)
    return path


def load_bundle(path=config.MODEL_PATH):
    """Load a saved bundle. Returns None if no file exists yet."""
    path = Path(path)
    if not path.exists():
        return None
    try:
        bundle = joblib.load(path)
        if not isinstance(bundle, dict) or "pipeline" not in bundle:
            raise ValueError("file does not contain a churn model bundle")
        return bundle
    except Exception as exc:
        raise ModelLoadError(
            f"The saved model could not be loaded ({exc}). Please retrain the model.") from exc


def bundle_version_warning(bundle) -> str | None:
    """Warn when the model was saved with a different scikit-learn version."""
    saved = bundle.get("sklearn_version")
    if saved and saved != sklearn.__version__:
        return (f"Model was trained with scikit-learn {saved} but {sklearn.__version__} is installed. "
                "Retrain the model if you see unexpected errors.")
    return None


def metrics_table(bundle: dict) -> pd.DataFrame:
    """Flat table of every metric (for CSV export)."""
    rows = []
    for name, res in bundle["results"].items():
        for split in ("train", "test"):
            r = res[split]
            rows.append({"Model": name, "Dataset": split.title(), "Accuracy": r["accuracy"],
                         "Precision": r["precision"], "Recall": r["recall"], "F1-score": r["f1"],
                         "ROC-AUC": r["roc_auc"],
                         "CV F1 (train folds)": res["cv_f1"] if split == "train" else np.nan,
                         "Selected": name == bundle["best_model_name"]})
    return pd.DataFrame(rows)
