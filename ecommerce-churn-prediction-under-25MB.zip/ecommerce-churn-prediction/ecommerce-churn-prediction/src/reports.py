"""reports.py - builds the downloadable churn analysis report (one CSV table)."""
from __future__ import annotations

import pandas as pd

from src import eda, explainability as ex, recommendations as rc


def build_analysis_report(bundle: dict, dfx: pd.DataFrame | None = None, predictions: pd.DataFrame | None = None) -> pd.DataFrame:
    """Return a table with columns Section | Item | Value | Notes."""
    rows = []
    add = lambda s, i, v, n="": rows.append({"Section": s, "Item": i, "Value": v, "Notes": n})

    if dfx is not None:
        k = eda.compute_kpis(dfx)
        add("Dataset", "Total customers", k["total"])
        add("Dataset", "Churned customers", k["churned"])
        add("Dataset", "Churn rate (%)", round(k["churn_rate"], 2))
        add("Dataset", "Retention rate (%)", round(k["retention_rate"], 2))
        if k["avg_purchase_value"] is not None:
            add("Dataset", f"Average {k['aov_col']}", round(k["avg_purchase_value"], 2))

    if bundle:
        best = bundle["best_model_name"]
        add("Model", "Selected model", best, bundle["selection_rule"])
        add("Model", "Trained at", bundle["trained_at"])
        t = bundle["results"][best]["test"]
        for key, label in [("accuracy", "Accuracy"), ("precision", "Precision"), ("recall", "Recall"),
                           ("f1", "F1-score"), ("roc_auc", "ROC-AUC")]:
            add("Model (test set)", label, round(t[key], 4))
        imp = bundle["permutation_importance"].head(8)
        for _, r in imp.iterrows():
            add("Top churn factors", r["Feature"], round(r["Importance"], 4),
                "Permutation importance (drop in ROC-AUC). Association, not causation.")
        for _, r in rc.RULE_TABLE.iterrows():
            add("Retention rules", r["Segment"], r["Suggested action"], r["Trigger (compared with training data)"])

    if predictions is not None and "Risk_Level" in predictions:
        counts = predictions["Risk_Level"].value_counts()
        for level in ["High", "Medium", "Low"]:
            add("Predictions", f"{level} risk customers", int(counts.get(level, 0)))
    return pd.DataFrame(rows)
