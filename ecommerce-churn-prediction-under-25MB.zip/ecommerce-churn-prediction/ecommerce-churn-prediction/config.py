"""
config.py - central settings for the whole project.
Change values here instead of searching through many files.
All paths use pathlib, so they work on Windows, Linux and macOS.
"""
from pathlib import Path

# ---------- Folders and files ----------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
REPORTS_DIR = BASE_DIR / "reports"
ASSETS_DIR = BASE_DIR / "assets"
SAMPLE_DATA_PATH = DATA_DIR / "sample_customers.csv"
MODEL_PATH = MODELS_DIR / "churn_model.joblib"

# ---------- General ----------
APP_TITLE = "E-Commerce Customer Churn Prediction System"
RANDOM_STATE = 42          # fixed seed => same results every run
TEST_SIZE = 0.20           # 20% of customers are kept aside for testing
CV_FOLDS = 5               # cross-validation folds used to compare models
MAX_CATEGORIES = 50        # text columns with more unique values are ignored
MIN_ROWS = 50              # minimum rows needed to train a model

# ---------- Risk thresholds (probability of churn) ----------
LOW_RISK_THRESHOLD = 0.30   # below this  -> Low risk
HIGH_RISK_THRESHOLD = 0.60  # at/above this -> High risk (in between = Medium)

# ---------- Automatic column detection ----------
TARGET_CANDIDATES = ["churn", "churned", "is_churn", "is_churned", "exited",
                     "attrition", "left", "target"]
POSITIVE_LABELS = {"1", "yes", "y", "true", "t", "churn", "churned", "left",
                   "exited", "stopped", "lost"}
# Column names that look like identifiers (never used as features)
ID_PATTERN = r"(^|_)id$|^id(_|$)|customerid|userid|custid|clientid"

# ---------- Colours used in charts and CSS ----------
COLORS = {
    "navy": "#0B1F3A",
    "navy_light": "#13294B",
    "teal": "#0EA5A4",
    "blue": "#2563EB",
    "retained": "#14B8A6",
    "churned": "#F97066",
    "grey": "#64748B",
}

# ---------- Data dictionary for the included sample dataset ----------
DATA_DESCRIPTIONS = {
    "CustomerID": "Unique customer identifier (NOT used for prediction).",
    "Age": "Customer age in years.",
    "Gender": "Customer gender (Male / Female / Other).",
    "City_Tier": "City category: Tier 1 = metro, Tier 3 = smaller town.",
    "Membership_Type": "Loyalty programme level (Basic, Silver, Gold, Platinum).",
    "Tenure_Months": "Months since the customer registered.",
    "Preferred_Payment": "Most used payment method.",
    "Purchase_Frequency": "Average number of orders placed per month.",
    "Total_Orders": "Number of orders placed since registration.",
    "Avg_Order_Value": "Average value of one order (currency units).",
    "Total_Spending": "Total amount spent since registration (currency units).",
    "Days_Since_Last_Purchase": "Days since the customer's latest order (recency).",
    "Complaints": "Number of complaints raised in the last 12 months.",
    "Support_Tickets": "Number of customer-support interactions in the last 12 months.",
    "App_Sessions_Per_Month": "Average app/website visits per month (engagement).",
    "Coupon_Usage_Count": "Number of discount coupons used in the last 12 months.",
    "Churn": "TARGET - Yes if the customer stopped purchasing, No if retained.",
}
