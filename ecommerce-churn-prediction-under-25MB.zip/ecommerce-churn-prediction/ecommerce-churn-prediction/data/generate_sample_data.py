"""
generate_sample_data.py
Creates data/sample_customers.csv - a SYNTHETIC e-commerce customer dataset.

IMPORTANT: this data is artificial. It imitates realistic customer behaviour
(e.g. long inactivity and many complaints raise churn probability) but it is
NOT real company data, so results must not be presented as real-world findings.

Run:  python data/generate_sample_data.py
"""
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 42
N = 5000
OUT = Path(__file__).resolve().parent / "sample_customers.csv"


def z(x):
    """Standardise a numpy array (mean 0, std 1)."""
    return (x - x.mean()) / x.std()


def main():
    rng = np.random.default_rng(SEED)

    membership = rng.choice(["Basic", "Silver", "Gold", "Platinum"], size=N, p=[0.50, 0.30, 0.15, 0.05])
    tier_mult = pd.Series(membership).map({"Basic": 0.8, "Silver": 1.0, "Gold": 1.3, "Platinum": 1.6}).to_numpy()

    age = np.clip(rng.normal(35, 10, N), 18, 70).round().astype(int)
    gender = rng.choice(["Male", "Female", "Other"], size=N, p=[0.48, 0.50, 0.02])
    city_tier = rng.choice(["Tier 1", "Tier 2", "Tier 3"], size=N, p=[0.40, 0.35, 0.25])
    payment = rng.choice(["Credit Card", "Debit Card", "UPI", "Net Banking", "Cash on Delivery", "Wallet"],
                         size=N, p=[0.22, 0.20, 0.28, 0.08, 0.14, 0.08])

    tenure = np.clip(rng.gamma(2.0, 10.0, N), 1, 72).round().astype(int)
    frequency = np.clip(rng.gamma(2.0, 0.6, N) * tier_mult, 0.1, 8).round(2)
    total_orders = np.maximum(1, (frequency * tenure * rng.uniform(0.6, 1.0, N)).round()).astype(int)
    aov = (rng.lognormal(np.log(1200), 0.45, N) * (0.9 + 0.1 * tier_mult)).round(2)
    total_spending = (total_orders * aov * rng.uniform(0.9, 1.1, N)).round(2)

    days_since = np.clip(rng.exponential(30.0 / (frequency + 0.3), N) + rng.exponential(8, N), 0, 365).round().astype(int)
    complaints = rng.poisson(0.6, N)
    tickets = rng.poisson(1.0 + 0.5 * complaints)
    sessions = np.clip(rng.poisson(8 + 4 * frequency) + rng.normal(0, 3, N), 0, None).round().astype(int)
    coupons = rng.poisson(2.0, N)

    # Churn probability follows a logistic formula based on realistic behaviour
    member_effect = pd.Series(membership).map({"Basic": 0.35, "Silver": 0.0, "Gold": -0.30, "Platinum": -0.50}).to_numpy()
    logit = (-1.75 + 0.90 * z(days_since.astype(float)) + 0.55 * z(complaints.astype(float))
             - 0.60 * z(sessions.astype(float)) - 0.50 * z(frequency) - 0.50 * z(tenure.astype(float))
             + 0.25 * z(tickets.astype(float)) + member_effect + rng.normal(0, 0.5, N))
    churn = rng.random(N) < 1 / (1 + np.exp(-logit))

    df = pd.DataFrame({
        "CustomerID": [f"C{i:05d}" for i in range(1, N + 1)],
        "Age": age.astype(float), "Gender": gender, "City_Tier": city_tier,
        "Membership_Type": membership, "Tenure_Months": tenure,
        "Preferred_Payment": payment, "Purchase_Frequency": frequency,
        "Total_Orders": total_orders, "Avg_Order_Value": aov,
        "Total_Spending": total_spending, "Days_Since_Last_Purchase": days_since,
        "Complaints": complaints, "Support_Tickets": tickets,
        "App_Sessions_Per_Month": sessions.astype(float), "Coupon_Usage_Count": coupons,
        "Churn": np.where(churn, "Yes", "No"),
    })

    # Add a few realistic data problems so the cleaning features can be demonstrated
    for col, frac in [("Age", 0.02), ("Avg_Order_Value", 0.015),
                      ("App_Sessions_Per_Month", 0.02), ("Preferred_Payment", 0.01)]:
        idx = rng.choice(N, size=int(N * frac), replace=False)
        df.loc[idx, col] = np.nan
    df = pd.concat([df, df.sample(25, random_state=SEED)], ignore_index=True)  # 25 duplicate rows

    df.to_csv(OUT, index=False)
    print(f"Saved {len(df)} rows to {OUT}")
    print("Churn rate:", round((df['Churn'] == 'Yes').mean() * 100, 1), "%")


if __name__ == "__main__":
    main()
