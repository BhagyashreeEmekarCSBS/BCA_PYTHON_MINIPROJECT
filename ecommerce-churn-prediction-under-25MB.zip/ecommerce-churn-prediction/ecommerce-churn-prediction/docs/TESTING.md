# Testing Documentation

Run all tests: `python -m pytest -v` (about 15 seconds). **Result on delivery: 31 passed, 0 failed.**
Additionally the real Streamlit server was started and returned HTTP 200 on the health check and main page.

| ID | Test case | Input / action | Expected result | Automated test | Status |
|---|---|---|---|---|---|
| TC01 | Valid dataset upload | Sample CSV through `load_csv` | Loads 5,025×17; validation has no errors | `test_tc01_valid_dataset_upload` | Pass |
| TC02a | Invalid upload – empty / one column | Empty text, `a\n`, `a,b\n` | `DatasetError` with friendly message | `test_tc02_invalid_upload_rejected` | Pass |
| TC02b | Missing target column | CSV without `Churn` | "Required column missing" error | `test_tc02_missing_target_column_gives_clear_error` | Pass |
| TC02c | Target with 3 values | Column a/b/c | "exactly 2 values" error | `test_tc02_target_with_three_classes_is_error` | Pass |
| TC02d | File not found | Wrong path | `DatasetError` | `test_tc02_file_not_found` | Pass |
| TC03 | Missing values | Rows with NaN | Detected in summary; imputed; prediction works | `test_tc03_missing_values_detected_and_handled` | Pass |
| TC04 | Duplicate records | Sample has 25 duplicates | Detected and removed | `test_tc04_duplicates_detected_and_removed` | Pass |
| TC05a | ID / target excluded | `prepare_xy` | No CustomerID/Churn in features; y is 0/1 | `test_tc05_identifier_and_target_not_used_as_features` | Pass |
| TC05b | Reproducible stratified split | Split twice | Identical indices; equal churn ratio | `test_tc05_split_is_reproducible_and_stratified` | Pass |
| TC05c | No data leakage | Inspect fitted scaler | Mean equals TRAIN mean, not full-data mean | `test_tc05_no_data_leakage_scaler_fitted_on_train_only` | Pass |
| TC06 | Model training | `train_and_compare` | 3 models; best by CV F1; metrics in [0,1]; AUC>0.7 | `test_tc06_model_training_and_selection` | Pass |
| TC07a | Single prediction | One customer dict | Probability 0–1, risk level, class | `test_tc07_single_customer_prediction` | Pass |
| TC07b | Sensible behaviour | Inactive+complaining vs loyal customer | Risk differs by > 30 points | `test_tc07_inactive_complaining_customer_riskier_than_loyal_one` | Pass |
| TC07c | Risk thresholds | 0.10 / 0.30 / 0.60 | Low / Medium / High | `test_tc07_risk_thresholds` | Pass |
| TC08a | Bulk prediction | 200 rows, no target column | 200 results + probability, class, risk; ID kept | `test_tc08_bulk_prediction_without_target_column` | Pass |
| TC08b | Extra columns / bad numbers | Extra column, "abc" in Age | Extra ignored; warning shown | `test_tc08_bulk_prediction_ignores_extra_columns_and_bad_numbers` | Pass |
| TC09a | Missing required columns | Drop Complaints, Age | `PredictionError` naming both | `test_tc09_missing_required_columns_raise_clear_error` | Pass |
| TC09b | Template works | Generated template | Scores without error | `test_tc09_template_has_all_required_columns_and_scores` | Pass |
| TC10 | CSV download | Predictions → CSV bytes → read back | Same columns/rows; report has Section/Item/Value/Notes | `test_tc10_csv_download_roundtrip` | Pass |
| TC11a | Model persistence | Save, reload, predict | Identical probabilities | `test_tc11_model_persistence_and_reload` | Pass |
| TC11b | Missing / corrupt model | No file; garbage file | `None`; `ModelLoadError` | `test_tc11_missing_model_returns_none_and_corrupt_file_errors` | Pass |
| TC12 | Confusion matrix & metrics | All 3 models | TN+FP+FN+TP = test size; metrics recomputed from matrix match; ROC present | `test_tc12_confusion_matrix_and_metrics_consistent` | Pass |
| TC13a | Feature importance | All models | Importance or coefficient table; permutation importance for all features | `test_tc13_feature_importance_for_all_models` | Pass |
| TC13b | Individual explanation | One customer | Top-N table with risk change | `test_tc13_individual_explanation` | Pass |
| TC14a | Recommendations | Inactive, complaints, high value | Matching segments; "Low risk" only when Low | `test_tc14_recommendations_linked_to_data_and_risk` | Pass |
| TC14b | Custom dataset | Different column names (`left`, `cust_id`) | Target auto-detected; ID excluded; no crash | `test_tc14_works_for_custom_dataset_with_other_columns` | Pass |
| TC15 | Too little data | 10 rows | `PreprocessingError` | `test_tc15_training_rejects_tiny_dataset` | Pass |
| TC16 | EDA charts & KPIs | Sample data | KPIs equal data; all charts build | `test_tc16_eda_charts_build` | Pass |
| TC17 | Whole UI | Streamlit `AppTest`: open all 10 pages, click bulk demo | No exceptions or error boxes | `test_tc17_streamlit_app_all_pages_render_and_predict` | Pass |

## Issues found and fixed during testing
| Issue | Fix |
|---|---|
| Mixed text/number column made Streamlit's table conversion warn (customer explanation) | Values converted to text before display. |
| Streamlit warned that `use_container_width` is deprecated | Replaced by `width="stretch"`; requirement set to `streamlit>=1.49`. |
| Saved model depends on the scikit-learn version | App compares versions and shows a retrain hint; corrupt files raise a friendly `ModelLoadError`. |

## Manual test checklist (for the demo)
1. Open Home → KPIs show 5,000 customers and ≈25.9% churn. 2. Dataset → upload a text file renamed `.csv` → error shown.
3. Dataset → download cleaned CSV. 4. EDA → filter Membership_Type = Basic → charts update.
5. Prediction → set Days_Since_Last_Purchase=250, Complaints=5 → High risk. 6. Bulk → "Use the loaded dataset as a demo" → download.
7. Delete `models\churn_model.joblib`, restart → first-time notice → Train models → works.
