# E-Commerce Customer Churn Prediction System — Project Report

## 1. Abstract
Customer churn — customers who stop buying — directly reduces the revenue of e-commerce businesses, and keeping a
customer is usually cheaper than winning a new one. This project develops a Python web application (Streamlit) that
cleans customer data, explores behaviour with interactive charts, trains and compares three classification
algorithms (Logistic Regression, Decision Tree, Random Forest), predicts churn probability for single and bulk
customers, shows factors associated with churn and suggests retention actions. A synthetic dataset of 5,000
customers is used for demonstration; the best model was selected by cross-validated F1-score and reached a test
ROC-AUC of about 0.84. The system is modular, tested with 31 automated tests and runs on a normal Windows laptop.

## 2. Introduction
E-commerce platforms record purchases, support tickets and app usage for every customer. Machine learning can learn
patterns in this history — such as long inactivity or repeated complaints — and estimate the probability that a
customer will leave. The business can then contact high-risk customers before they are lost.

## 3. Problem Statement
Businesses hold large customer data but cannot manually identify who is about to leave or why. A system is needed
that (a) predicts churn, (b) explains the main associated factors and (c) suggests suitable retention actions,
with an interface usable by non-programmers.

## 4. Objectives
1. Load, validate and clean customer datasets (CSV).
2. Perform exploratory data analysis with interactive visualisations.
3. Build a leakage-free preprocessing pipeline.
4. Train, compare and evaluate three classifiers and save the best model.
5. Predict churn for one customer or many customers and categorise risk (Low/Medium/High).
6. Identify churn factors without claiming causation.
7. Generate practical, data-linked retention recommendations and downloadable reports.

## 5. Scope
**In scope:** structured CSV customer data, binary churn classification, dashboard, CSV exports, rule-based advice.
**Out of scope:** real-time data feeds, sending e-mails/offers, deep learning, time-series survival analysis,
multi-user login.

## 6. Hardware and Software Requirements
| Item | Requirement |
|---|---|
| Processor | Dual-core 2 GHz or better |
| RAM | 4 GB minimum (8 GB recommended) |
| Disk | 500 MB free |
| OS | Windows 10/11 (also runs on Linux/macOS) |
| Software | Python 3.10–3.12, VS Code, a web browser |
| Libraries | Streamlit, Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn, Plotly, Joblib, Pytest |

## 7. Literature / Background Overview
* **Churn prediction** is a standard binary-classification task in marketing analytics, telecom, banking and retail.
* **Logistic regression** (Cox, 1958) models the log-odds of an event as a linear combination of features and is the
  classic baseline because its coefficients are interpretable.
* **Decision trees** (Breiman et al., 1984, CART) split data with simple rules; they are intuitive but over-fit easily.
* **Random forests** (Breiman, 2001) average many randomised trees and usually give more stable accuracy.
* **RFM analysis** (Recency, Frequency, Monetary value) is a classic marketing method; the features *days since last
  purchase*, *purchase frequency* and *total spending* in this project follow the same idea.
* Because churners are usually a minority, accuracy can mislead; **precision, recall, F1 and ROC-AUC** are preferred.

## 8. System Architecture
```mermaid
flowchart LR
    U[User / Browser] --> UI[Streamlit UI - app.py]
    UI --> DL[data_loader.py<br/>load, validate, clean]
    UI --> EDA[eda.py<br/>charts, KPIs]
    UI --> TR[train_model.py<br/>train, compare, save]
    UI --> PR[predict.py<br/>single, bulk]
    UI --> EX[explainability.py]
    UI --> RC[recommendations.py]
    UI --> RP[reports.py]
    DL --> PP[preprocessing.py<br/>ColumnTransformer]
    TR --> PP
    CSV[(CSV data)] --> DL
    TR --> M[(models/churn_model.joblib)]
    M --> PR
    M --> EX
    PR --> OUT[(Downloadable CSV)]
    RP --> OUT
```

## 9. Data Flow Diagram
**Level 0 (context diagram)**
```mermaid
flowchart LR
    A[Business user] -- customer CSV, form inputs --> S((Churn Prediction System))
    S -- KPIs, charts, predictions, recommendations, CSV reports --> A
```
**Level 1**
```mermaid
flowchart TD
    U[User] -->|upload CSV| P1(1.0 Load and validate)
    P1 -->|valid data| D1[(Cleaned dataset)]
    D1 --> P2(2.0 Explore - EDA)
    P2 -->|charts, insights| U
    D1 --> P3(3.0 Preprocess and split)
    P3 -->|train/test sets| P4(4.0 Train and evaluate models)
    P4 -->|best pipeline + metrics| D2[(Model file .joblib)]
    U -->|customer details / bulk CSV| P5(5.0 Predict churn)
    D2 --> P5
    P5 -->|probability, risk level| P6(6.0 Explain and recommend)
    D2 --> P6
    P6 -->|factors, suggestions| U
    P5 --> P7(7.0 Reports and downloads)
    P7 -->|CSV files| U
```

## 10. Use Case Diagram
```mermaid
flowchart LR
    actor((Business Analyst / Student))
    subgraph System[Churn Prediction System]
        UC1([Upload / load dataset])
        UC2([View dashboard KPIs])
        UC3([Explore data - EDA])
        UC4([Select target column])
        UC5([Train and compare models])
        UC6([Predict single customer])
        UC7([Predict bulk customers])
        UC8([View churn factors])
        UC9([View retention recommendations])
        UC10([Download reports])
    end
    actor --- UC1 & UC2 & UC3 & UC4 & UC5 & UC6 & UC7 & UC8 & UC9 & UC10
    UC5 -. includes .-> UC4
    UC6 -. extends .-> UC9
    UC7 -. extends .-> UC10
```

## 11. Activity Diagram
```mermaid
flowchart TD
    A([Start]) --> B[Open application]
    B --> C{Saved model exists?}
    C -- Yes --> D[Load model with Joblib]
    C -- No --> E[Show first-time training notice]
    D --> F[Choose a page]
    E --> F
    F --> G[Upload CSV or load sample]
    G --> H{Validation passed?}
    H -- No --> I[Show clear error] --> G
    H -- Yes --> J[Clean data and confirm target column]
    J --> K{Train / retrain?}
    K -- Yes --> L[Cross-validate 3 models, pick best by F1, test, save]
    K -- No --> M[Use saved model]
    L --> N[Predict: single or bulk]
    M --> N
    N --> O[Show probability, risk level, factors, recommendations]
    O --> P[Download CSV results]
    P --> Q([End])
```

## 12. Methodology
1. **Data loading & validation** – checks file format, rows, columns, target with exactly two values, duplicates, missing values.
2. **Cleaning** – trims text, removes duplicate rows and rows without target.
3. **Feature selection** – identifier columns (e.g. `CustomerID`) and columns named *churn* are excluded.
4. **Split** – stratified 80/20 train/test split with fixed seed 42.
5. **Pipeline** – `ColumnTransformer`: numeric → median imputation + standardisation; categorical → most-frequent imputation + one-hot encoding. Learned **only on training data** (also inside each CV fold) → no leakage.
6. **Imbalance** – `class_weight='balanced'` in all models.
7. **Model comparison** – 5-fold stratified cross-validation on training data; selection by mean F1 (tie-break ROC-AUC), not accuracy.
8. **Final evaluation** – once on the untouched test set: accuracy, precision, recall, F1, ROC-AUC, confusion matrix, classification report, ROC curve. Train metrics are shown separately to detect over-fitting.
9. **Persistence** – the whole bundle (fitted pipelines, metrics, reference statistics) is saved with Joblib and reloaded on restart.
10. **Explainability** – permutation importance, tree importances, logistic coefficients and a per-customer "what-if" explanation.
11. **Recommendations** – rules comparing a customer with training-data quartiles.

## 13. Dataset Description
* **File:** `data/sample_customers.csv` — **synthetic**, generated by `data/generate_sample_data.py` (seed 42). Not real data.
* **Size:** 5,025 rows (5,000 unique customers + 25 deliberate duplicates), 17 columns; about 1.5–2% missing values injected in four columns to demonstrate cleaning.
* **Target:** `Churn` (Yes/No). Churn rate ≈ 25.9%.
* **Generation:** churn probability follows a logistic formula in which longer inactivity, more complaints/tickets, lower app engagement, lower purchase frequency, shorter tenure and Basic membership raise churn.

| Column | Meaning |
|---|---|
| CustomerID | Identifier (excluded from modelling) |
| Age, Gender, City_Tier | Demographics |
| Membership_Type | Basic / Silver / Gold / Platinum |
| Tenure_Months | Months since registration |
| Preferred_Payment | Most-used payment method |
| Purchase_Frequency | Orders per month |
| Total_Orders, Total_Spending, Avg_Order_Value | Purchase history |
| Days_Since_Last_Purchase | Recency |
| Complaints, Support_Tickets | Service interactions (12 months) |
| App_Sessions_Per_Month | Engagement |
| Coupon_Usage_Count | Discounts used |
| **Churn** | **Target** |

**Limitations:** synthetic; relationships are those that the generator built in, so real data will be noisier.
A real dataset (e.g. a public "E-commerce Customer Churn" CSV from Kaggle) can be uploaded without code changes.

## 14. Algorithm Explanations
* **Logistic Regression:** computes `p = 1 / (1 + e^-(b0 + b1x1 + … + bnxn))`. Positive coefficients raise churn probability. Fast, interpretable, needs scaled inputs.
* **Decision Tree:** repeatedly splits data on the feature/threshold that best separates churners (Gini impurity). Limited depth (5) and `min_samples_leaf=25` prevent memorisation.
* **Random Forest:** 200 trees, each trained on a bootstrap sample with random feature subsets; predictions are averaged. Reduces variance; less interpretable.
* **Metrics:** Precision = TP/(TP+FP); Recall = TP/(TP+FN); F1 = harmonic mean; ROC-AUC = probability that a random churner gets a higher score than a random non-churner.

## 15. Implementation Details
| File | Responsibility |
|---|---|
| `app.py` | Streamlit pages, CSS theme, session state, navigation |
| `config.py` | Paths, seed, thresholds, colours, data dictionary |
| `src/data_loader.py` | `load_csv`, `validate_dataframe`, `clean_dataframe`, `detect_target_column`, data dictionary |
| `src/preprocessing.py` | `prepare_xy`, `build_preprocessor`, `split_data`, ID/leakage handling |
| `src/eda.py` | Plotly/Seaborn charts, KPI calculation, data-driven insights |
| `src/train_model.py` | `train_and_compare`, `evaluate_model`, `save_bundle`, `load_bundle` |
| `src/predict.py` | `predict_single`, `predict_dataframe`, risk levels, CSV template |
| `src/explainability.py` | Importance tables, group comparison, `explain_customer` |
| `src/recommendations.py` | Role detection by column names, rule engine |
| `src/reports.py` | Analysis report CSV |

Design decisions: all file paths use `pathlib`; the UI never crashes on bad input (custom exceptions `DatasetError`,
`PreprocessingError`, `PredictionError`, `ModelLoadError` are caught and shown as messages); the model bundle stores
the column list so prediction files are validated automatically.

## 16. Results and Discussion
Hold-out test set of 1,000 customers (4,000 used for training); decision threshold 0.5.

| Model | CV F1 | CV AUC | Test Acc | Test Prec | Test Recall | Test F1 | Test AUC |
|---|---|---|---|---|---|---|---|
| **Logistic Regression (selected)** | **0.608** | 0.830 | 0.766 | 0.535 | 0.745 | 0.623 | 0.843 |
| Decision Tree | 0.558 | 0.781 | 0.736 | 0.494 | 0.780 | 0.605 | 0.808 |
| Random Forest | 0.592 | 0.815 | 0.786 | 0.570 | 0.710 | 0.632 | 0.845 |

Confusion matrix of the selected model on the test set (rows = actual, columns = predicted): No → [573, 168]; Yes → [66, 193].
So 193 of 259 churners (74.5%) were found, with 168 false alarms.

**Discussion**
* Logistic Regression was chosen on **validation** data (CV F1). Random Forest scored marginally higher on test F1 (0.632 vs 0.623) but the gap is tiny, and the forest shows a larger train–test gap (train F1 0.76 vs test 0.63), a sign of over-fitting. Selecting on the test set would leak information, so the rule is not changed afterwards.
* Logistic Regression performs well partly because the synthetic data was generated with a logistic relationship; on real data tree ensembles may win.
* Top associated factors (permutation importance, drop in ROC-AUC): Days_Since_Last_Purchase (0.092), App_Sessions_Per_Month (0.053), Complaints (0.037), Tenure_Months (0.037), Purchase_Frequency (0.027).
* These are **associations** in synthetic data, not proven causes and not real-world business findings.

## 17. Testing and Test Cases
See `docs/TESTING.md`. 31 automated tests (pytest) cover upload, invalid files, missing values, duplicates, training,
leakage, single/bulk prediction, missing columns, CSV export, model persistence, metrics consistency and rendering of every page.

## 18. Limitations
Synthetic demo data; single snapshot (no time dimension); default threshold 0.5 not tuned to business cost; rule-based
recommendations are not validated by experiments; only binary churn labels; no authentication.

## 19. Future Scope
Gradient boosting/XGBoost; SHAP explanations; threshold tuning by cost of false positives vs false negatives;
real e-commerce data and a database; scheduled e-mail campaigns; customer lifetime value; survival analysis; cloud deployment.

## 20. Conclusion
The project delivers a complete, tested churn prediction workflow — from data upload to explained predictions and
retention suggestions — in a professional dashboard that runs locally. It demonstrates correct ML practice
(no leakage, validation-based model selection, imbalance handling, honest train/test reporting).

## 21. References
1. Breiman, L. (2001). *Random Forests*. Machine Learning, 45, 5–32.
2. Breiman, L., Friedman, J., Olshen, R., Stone, C. (1984). *Classification and Regression Trees*. Wadsworth.
3. Hosmer, D., Lemeshow, S. (2013). *Applied Logistic Regression*. Wiley.
4. Pedregosa, F. et al. (2011). *Scikit-learn: Machine Learning in Python*. JMLR 12, 2825–2830.
5. Scikit-learn documentation – https://scikit-learn.org
6. Streamlit documentation – https://docs.streamlit.io
7. Plotly Python documentation – https://plotly.com/python/
8. Pandas documentation – https://pandas.pydata.org/docs/

## 22. User Manual
1. **Start** – run `streamlit run app.py`; the sample data loads automatically.
2. **Home** – view KPIs, insights and shortcuts to every module.
3. **Dataset** – upload a CSV or reload the sample; read validation messages; browse types/missing values/data dictionary; download the cleaned file.
4. **EDA** – open *Filters* to restrict customers; use the tabs for churn overview, distributions, segments, correlation and box plots.
5. **Preprocessing** – confirm the churn column and which value means churn; choose the test size; see features used/excluded.
6. **Model Training** – click *Train models* (first time) or *Retrain models*; compare models, confusion matrix, ROC curves, classification report.
7. **Prediction** – *Single customer*: fill the form → *Predict churn* → see gauge, risk badge, indicators, actions. *Bulk*: download the template, upload a CSV, filter results, download predictions. Adjust risk thresholds in *Risk thresholds*.
8. **Churn Factors** – read importance charts and plain-language notes; explain any row of the dataset.
9. **Recommendations** – see suggested actions per segment and the rule table.
10. **Reports** – download cleaned data, predictions, metrics and the analysis report.
