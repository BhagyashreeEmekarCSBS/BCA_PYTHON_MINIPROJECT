# Suggested Presentation Slides (about 15 minutes)

**Slide 1 – Title**
E-Commerce Customer Churn Prediction System · Your name, roll number, guide, college, year.

**Slide 2 – Problem**
Customers leave silently; acquiring new customers costs more than retaining. Question: *Who will churn, why, and what can we do?*

**Slide 3 – Objectives**
Predict churn · Explain factors · Recommend retention actions · Easy dashboard for non-programmers.

**Slide 4 – Technology stack**
Python · Streamlit · Pandas/NumPy · Scikit-learn · Plotly/Seaborn/Matplotlib · Joblib · VS Code on Windows.

**Slide 5 – Dataset**
Synthetic, 5,000 customers, 16 features + target `Churn` (≈26% churn). Why synthetic; how to upload real data. Key features: recency, frequency, spending, complaints, engagement, membership.

**Slide 6 – System architecture** (insert the architecture diagram from `docs/PROJECT_REPORT.md`)

**Slide 7 – ML pipeline**
Clean → remove IDs → stratified split → impute/scale/encode (train only) → 3 models → 5-fold CV → choose by F1 → test once → save with Joblib. Mention *no data leakage*.

**Slide 8 – Dashboard demo: Home, Dataset, EDA**
Show KPI cards, validation messages, filters, donut chart, churn by membership, correlation heatmap.

**Slide 9 – Model comparison**
Table of CV F1 and test metrics; selected model Logistic Regression; confusion matrix and ROC curves; train-vs-test gap for Random Forest.

**Slide 10 – Prediction demo**
Single customer: gauge + risk badge + indicators. Bulk: upload CSV, filter, download.

**Slide 11 – Churn factors**
Top factors: days since last purchase, app engagement, complaints, tenure, purchase frequency. *Association ≠ causation.*

**Slide 12 – Retention recommendations**
Rules table: inactive → re-engagement; complaints → fast support; high-value at risk → loyalty benefits; low engagement → win-back.

**Slide 13 – Testing**
31 automated tests, all passing; categories; manual checklist.

**Slide 14 – Limitations & future scope**
Synthetic data, no time dimension, rule-based advice · XGBoost, SHAP, real data, cost-based threshold, deployment.

**Slide 15 – Conclusion & Q&A**
Working end-to-end system with honest evaluation. Thank you / questions.

### Demo order tip
Home → Dataset (upload an invalid file, show the error) → EDA filter → Model Training results → Single prediction (High-risk example: Days_Since_Last_Purchase 250, Complaints 5, App sessions 2) → Bulk prediction + download → Churn Factors → Recommendations.
