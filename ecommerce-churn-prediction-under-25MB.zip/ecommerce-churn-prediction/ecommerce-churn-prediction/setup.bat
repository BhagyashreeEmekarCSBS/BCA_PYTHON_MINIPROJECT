@echo off
REM One-time setup for Windows: creates a virtual environment, installs packages and trains the model.
echo === Creating virtual environment ===
py -m venv venv || python -m venv venv
call venv\Scripts\activate.bat
echo === Installing packages ===
python -m pip install --upgrade pip
pip install -r requirements.txt
echo === Training the model (under a minute) ===
python train.py
echo.
echo Setup finished. Start the app with run_app.bat
pause
