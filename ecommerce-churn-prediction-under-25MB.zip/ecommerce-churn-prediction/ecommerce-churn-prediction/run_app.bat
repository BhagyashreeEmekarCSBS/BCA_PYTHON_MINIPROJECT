@echo off
REM Starts the dashboard (run setup.bat once before using this).
call venv\Scripts\activate.bat
streamlit run app.py
pause
