"""
train.py - train the models from the command line.

    python train.py                     (uses data/sample_customers.csv)
    python train.py --data my.csv --target Churn
"""
import argparse

import config
from src import data_loader as dl
from src import train_model as tm


def main():
    parser = argparse.ArgumentParser(description="Train churn prediction models")
    parser.add_argument("--data", default=str(config.SAMPLE_DATA_PATH), help="path to a CSV file")
    parser.add_argument("--target", default=None, help="name of the churn column (auto-detected if omitted)")
    args = parser.parse_args()

    df = dl.load_csv(args.data)
    bundle = tm.train_and_compare(df, args.target,
                                  progress_callback=lambda p, msg: print(f"[{int(p * 100):3d}%] {msg}"))
    path = tm.save_bundle(bundle)
    print("\nModel comparison (F1/AUC columns starting 'CV' are validation scores):")
    print(bundle["comparison"].round(3).to_string(index=False))
    print(f"\nSelected model: {bundle['best_model_name']}")
    print(f"Saved to: {path}")
    config.REPORTS_DIR.mkdir(exist_ok=True)
    out = config.REPORTS_DIR / "model_metrics.csv"
    tm.metrics_table(bundle).to_csv(out, index=False)
    print(f"Metrics exported to: {out}")


if __name__ == "__main__":
    main()
