// Reusable SVG chart primitives. No external chart library.
import { ReactNode } from 'react';

const AXIS = 'rgba(255,255,255,0.5)';
const GRID = 'rgba(255,255,255,0.07)';

interface Margin { top: number; right: number; bottom: number; left: number; }
const DEFAULT_MARGIN: Margin = { top: 16, right: 16, bottom: 36, left: 48 };

function scale(min: number, max: number, span: number) {
  const range = max - min || 1;
  return (v: number) => ((v - min) / range) * span;
}

export interface LineSeries {
  name: string;
  color: string;
  points: { x: number; y: number }[];
  dashed?: boolean;
}

export function LineChart({
  series, width = 760, height = 300, margin = DEFAULT_MARGIN,
  xLabel, yLabel, title, xTicks, yTicks,
}: {
  series: LineSeries[];
  width?: number; height?: number; margin?: Margin;
  xLabel?: string; yLabel?: string; title?: string;
  xTicks?: { value: number; label: string }[];
  yTicks?: { value: number; label: string }[];
}) {
  const allPts = series.flatMap((s) => s.points);
  if (allPts.length === 0) return <Empty />;
  const xMin = Math.min(...allPts.map((p) => p.x));
  const xMax = Math.max(...allPts.map((p) => p.x));
  const yMin = Math.min(0, Math.min(...allPts.map((p) => p.y)));
  const yMax = Math.max(...allPts.map((p) => p.y));
  const iw = width - margin.left - margin.right;
  const ih = height - margin.top - margin.bottom;
  const sx = scale(xMin, xMax, iw);
  const sy = scale(yMin, yMax, ih);
  const yt = yTicks ?? autoTicks(yMin, yMax, 5);
  const xt = xTicks ?? autoTicks(xMin, xMax, 6);

  return (
    <ChartFrame width={width} height={height} title={title}>
      <g transform={`translate(${margin.left},${margin.top})`}>
        {yt.map((t) => (
          <g key={t.value}>
            <line x1={0} y1={ih - sy(t.value)} x2={iw} y2={ih - sy(t.value)} stroke={GRID} />
            <text x={-8} y={ih - sy(t.value)} textAnchor="end" dominantBaseline="middle" fill={AXIS} fontSize={11}>{t.label}</text>
          </g>
        ))}
        {xt.map((t) => (
          <g key={t.value}>
            <line x1={sx(t.value)} y1={0} x2={sx(t.value)} y2={ih} stroke={GRID} />
            <text x={sx(t.value)} y={ih + 16} textAnchor="middle" fill={AXIS} fontSize={11}>{t.label}</text>
          </g>
        ))}
        {series.map((s) => {
          if (s.points.length < 2) return null;
          const d = s.points.map((p, i) => `${i === 0 ? 'M' : 'L'}${sx(p.x).toFixed(1)},${(ih - sy(p.y)).toFixed(1)}`).join(' ');
          return <path key={s.name} d={d} fill="none" stroke={s.color} strokeWidth={2} strokeDasharray={s.dashed ? '5,4' : undefined} />;
        })}
        {xLabel && <text x={iw / 2} y={ih + 32} textAnchor="middle" fill={AXIS} fontSize={12}>{xLabel}</text>}
        {yLabel && <text x={-ih / 2} y={-36} textAnchor="middle" transform="rotate(-90)" fill={AXIS} fontSize={12}>{yLabel}</text>}
        {series.length > 1 && (
          <g>
            {series.map((s, i) => (
              <g key={s.name} transform={`translate(${i * 130},0)`}>
                <line x1={0} y1={-4} x2={16} y2={-4} stroke={s.color} strokeWidth={2} />
                <text x={20} y={-2} fill={AXIS} fontSize={11}>{s.name}</text>
              </g>
            ))}
          </g>
        )}
      </g>
    </ChartFrame>
  );
}

export interface BarDatum { label: string; value: number; color?: string; }
export function BarChart({
  data, width = 760, height = 300, margin = DEFAULT_MARGIN, xLabel, yLabel, title, valueFmt, color = '#3b82f6',
}: {
  data: BarDatum[]; width?: number; height?: number; margin?: Margin;
  xLabel?: string; yLabel?: string; title?: string; valueFmt?: (n: number) => string; color?: string;
}) {
  if (data.length === 0) return <Empty />;
  const yMax = Math.max(...data.map((d) => d.value));
  const iw = width - margin.left - margin.right;
  const ih = height - margin.top - margin.bottom;
  const sy = scale(0, yMax, ih);
  const bw = iw / data.length;
  const yt = autoTicks(0, yMax, 5);

  return (
    <ChartFrame width={width} height={height} title={title}>
      <g transform={`translate(${margin.left},${margin.top})`}>
        {yt.map((t) => (
          <g key={t.value}>
            <line x1={0} y1={ih - sy(t.value)} x2={iw} y2={ih - sy(t.value)} stroke={GRID} />
            <text x={-8} y={ih - sy(t.value)} textAnchor="end" dominantBaseline="middle" fill={AXIS} fontSize={11}>{t.label}</text>
          </g>
        ))}
        {data.map((d, i) => {
          const h = sy(d.value);
          const x = i * bw + bw * 0.15;
          const w = bw * 0.7;
          return (
            <g key={d.label}>
              <rect x={x} y={ih - h} width={w} height={h} fill={d.color ?? color} rx={3}>
                <title>{`${d.label}: ${valueFmt ? valueFmt(d.value) : d.value}`}</title>
              </rect>
              <text x={x + w / 2} y={ih + 16} textAnchor="end" dominantBaseline="middle" fill={AXIS} fontSize={10} transform={`rotate(-30 ${x + w / 2},${ih + 16})`}>{d.label}</text>
            </g>
          );
        })}
        {xLabel && <text x={iw / 2} y={ih + 36} textAnchor="middle" fill={AXIS} fontSize={12}>{xLabel}</text>}
        {yLabel && <text x={-ih / 2} y={-36} textAnchor="middle" transform="rotate(-90)" fill={AXIS} fontSize={12}>{yLabel}</text>}
      </g>
    </ChartFrame>
  );
}

export function ScatterChart({
  points, width = 760, height = 320, margin = DEFAULT_MARGIN, xLabel, yLabel, title, color = '#3b82f6', alpha = 0.5,
}: {
  points: { x: number; y: number; color?: string }[];
  width?: number; height?: number; margin?: Margin;
  xLabel?: string; yLabel?: string; title?: string; color?: string; alpha?: number;
}) {
  if (points.length === 0) return <Empty />;
  const xMin = Math.min(...points.map((p) => p.x));
  const xMax = Math.max(...points.map((p) => p.x));
  const yMin = Math.min(0, Math.min(...points.map((p) => p.y)));
  const yMax = Math.max(...points.map((p) => p.y));
  const iw = width - margin.left - margin.right;
  const ih = height - margin.top - margin.bottom;
  const sx = scale(xMin, xMax, iw);
  const sy = scale(yMin, yMax, ih);
  const yt = autoTicks(yMin, yMax, 5);
  const xt = autoTicks(xMin, xMax, 6);

  return (
    <ChartFrame width={width} height={height} title={title}>
      <g transform={`translate(${margin.left},${margin.top})`}>
        {yt.map((t) => (
          <g key={t.value}>
            <line x1={0} y1={ih - sy(t.value)} x2={iw} y2={ih - sy(t.value)} stroke={GRID} />
            <text x={-8} y={ih - sy(t.value)} textAnchor="end" dominantBaseline="middle" fill={AXIS} fontSize={11}>{t.label}</text>
          </g>
        ))}
        {xt.map((t) => (
          <g key={t.value}>
            <line x1={sx(t.value)} y1={0} x2={sx(t.value)} y2={ih} stroke={GRID} />
            <text x={sx(t.value)} y={ih + 16} textAnchor="middle" fill={AXIS} fontSize={11}>{t.label}</text>
          </g>
        ))}
        {points.map((p, i) => (
          <circle key={i} cx={sx(p.x)} cy={ih - sy(p.y)} r={2.5} fill={p.color ?? color} opacity={alpha} />
        ))}
        {xLabel && <text x={iw / 2} y={ih + 32} textAnchor="middle" fill={AXIS} fontSize={12}>{xLabel}</text>}
        {yLabel && <text x={-ih / 2} y={-36} textAnchor="middle" transform="rotate(-90)" fill={AXIS} fontSize={12}>{yLabel}</text>}
      </g>
    </ChartFrame>
  );
}

export function Heatmap({
  rows, cols, values, width = 560, height = 380, title,
  colorScale = ['#0a1840', '#3b82f6', '#f59e0b', '#ef4444'],
}: {
  rows: string[]; cols: string[];
  values: { r: number; c: number; v: number }[];
  width?: number; height?: number; title?: string;
  colorScale?: string[];
}) {
  if (values.length === 0) return <Empty />;
  const margin = { top: 28, right: 16, bottom: 56, left: 90 };
  const iw = width - margin.left - margin.right;
  const ih = height - margin.top - margin.bottom;
  const cw = iw / cols.length;
  const ch = ih / rows.length;
  const vMax = Math.max(...values.map((d) => Math.abs(d.v)));
  const vMin = Math.min(...values.map((d) => d.v));
  const range = vMax - vMin || 1;

  return (
    <ChartFrame width={width} height={height} title={title}>
      <g transform={`translate(${margin.left},${margin.top})`}>
        {values.map((d, i) => {
          const t = (d.v - vMin) / range;
          const fillColor = lerpColor(colorScale, t);
          return (
            <rect key={i} x={d.c * cw} y={d.r * ch} width={cw} height={ch} fill={fillColor} stroke="rgba(0,0,0,0.2)" strokeWidth={0.5}>
              <title>{`${rows[d.r]} × ${cols[d.c]}: ${d.v.toFixed(2)}`}</title>
            </rect>
          );
        })}
        {cols.map((c, i) => (
          <text key={i} x={i * cw + cw / 2} y={ih + 14} textAnchor="end" dominantBaseline="middle" fill={AXIS} fontSize={9} transform={`rotate(-45 ${i * cw + cw / 2},${ih + 14})`}>{c}</text>
        ))}
        {rows.map((r, i) => (
          <text key={i} x={-6} y={i * ch + ch / 2} textAnchor="end" dominantBaseline="middle" fill={AXIS} fontSize={9}>{r}</text>
        ))}
      </g>
    </ChartFrame>
  );
}

function ChartFrame({ width, height, title, children }: { width: number; height: number; title?: string; children: ReactNode }) {
  return (
    <div className="w-full overflow-x-auto">
      <svg width={width} height={height} className="block max-w-full" role="img" aria-label={title ?? 'chart'}>
        {title && <text x={12} y={18} fill="#e6ebf5" fontSize={13} fontWeight={600}>{title}</text>}
        {children}
      </svg>
    </div>
  );
}

function Empty() {
  return <div className="text-[--text-dim] text-sm py-12 text-center border border-[--border] rounded-xl">No data to display.</div>;
}

export function autoTicks(min: number, max: number, count: number): { value: number; label: string }[] {
  const span = max - min || 1;
  const step = niceStep(span / count);
  const start = Math.ceil(min / step) * step;
  const ticks: { value: number; label: string }[] = [];
  for (let v = start; v <= max + 1e-9; v += step) ticks.push({ value: v, label: formatTick(v) });
  return ticks;
}

function niceStep(raw: number): number {
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / pow;
  let nice: number;
  if (n <= 1) nice = 1; else if (n <= 2) nice = 2; else if (n <= 5) nice = 5; else nice = 10;
  return nice * pow;
}

function formatTick(v: number): string {
  if (Math.abs(v) >= 1000) return (v / 1000).toFixed(v % 1000 === 0 ? 0 : 1) + 'k';
  if (Math.abs(v) < 1 && v !== 0) return v.toFixed(2);
  return v.toFixed(0);
}

function lerpColor(stops: string[], t: number): string {
  const clamped = Math.max(0, Math.min(1, t));
  const seg = clamped * (stops.length - 1);
  const i = Math.min(stops.length - 2, Math.floor(seg));
  const f = seg - i;
  return mixHex(stops[i], stops[i + 1], f);
}
function mixHex(a: string, b: string, t: number): string {
  const pa = hexToRgb(a), pb = hexToRgb(b);
  return `rgb(${Math.round(pa.r + (pb.r - pa.r) * t)},${Math.round(pa.g + (pb.g - pa.g) * t)},${Math.round(pa.b + (pb.b - pa.b) * t)})`;
}
function hexToRgb(h: string): { r: number; g: number; b: number } {
  const m = h.replace('#', '');
  return { r: parseInt(m.slice(0, 2), 16), g: parseInt(m.slice(2, 4), 16), b: parseInt(m.slice(4, 6), 16) };
}
