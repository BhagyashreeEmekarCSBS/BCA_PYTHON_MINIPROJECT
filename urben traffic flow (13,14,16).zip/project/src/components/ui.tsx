// Small shared UI primitives.
import { ReactNode } from 'react';

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`card p-5 ${className}`}>{children}</div>;
}

export function PageHeader({ title, subtitle, icon }: { title: string; subtitle?: string; icon?: ReactNode }) {
  return (
    <div className="mb-6 fade-in">
      <div className="flex items-center gap-3">
        {icon && <div className="text-[--primary]">{icon}</div>}
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          {subtitle && <p className="text-[--text-dim] text-sm mt-1 max-w-3xl">{subtitle}</p>}
        </div>
      </div>
    </div>
  );
}

export function Stat({ label, value, sub, accent }: { label: string; value: ReactNode; sub?: string; accent?: string }) {
  return (
    <div className="card p-4">
      <div className="text-[--text-dim] text-xs uppercase tracking-wider">{label}</div>
      <div className={`text-2xl font-semibold metric-num mt-1 ${accent ?? 'text-[--text]'}`}>{value}</div>
      {sub && <div className="text-[--text-dim] text-xs mt-1">{sub}</div>}
    </div>
  );
}

export function Badge({ children, tone = 'blue' }: { children: ReactNode; tone?: 'blue' | 'green' | 'amber' | 'red' | 'gray' }) {
  const tones: Record<string, string> = {
    blue: 'bg-blue-500/15 text-blue-300 border border-blue-500/30',
    green: 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30',
    amber: 'bg-amber-500/15 text-amber-300 border border-amber-500/30',
    red: 'bg-red-500/15 text-red-300 border border-red-500/30',
    gray: 'bg-slate-500/15 text-slate-300 border border-slate-500/30',
  };
  return <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${tones[tone]}`}>{children}</span>;
}

export function Button({
  children, onClick, variant = 'primary', disabled, className = '', type = 'button',
}: {
  children: ReactNode; onClick?: () => void; variant?: 'primary' | 'ghost' | 'outline';
  disabled?: boolean; className?: string; type?: 'button' | 'submit';
}) {
  const base = 'inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition disabled:opacity-50 disabled:cursor-not-allowed';
  const styles: Record<string, string> = {
    primary: 'bg-[--primary] hover:bg-blue-400 text-white shadow-lg shadow-blue-500/20',
    ghost: 'text-[--text-dim] hover:text-[--text] hover:bg-white/5',
    outline: 'border border-[--border] hover:border-[--primary] text-[--text]',
  };
  return <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${styles[variant]} ${className}`}>{children}</button>;
}

export function Table({ headers, rows }: { headers: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-[--border] text-left">
            {headers.map((h, i) => <th key={i} className="py-2.5 px-3 font-medium text-[--text-dim]">{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-[--border]/50 hover:bg-white/[0.02]">
              {r.map((c, j) => <td key={j} className="py-2.5 px-3">{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="card p-10 text-center fade-in">
      <div className="text-[--text-dim] text-lg">{title}</div>
      {hint && <div className="text-[--text-dim] text-sm mt-2 max-w-md mx-auto">{hint}</div>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-[--text-dim]">
      <div className="w-4 h-4 border-2 border-[--primary] border-t-transparent rounded-full animate-spin" />
      {label}
    </div>
  );
}

export function Section({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <div className="card p-5 fade-in">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold">{title}</h2>
        {right}
      </div>
      {children}
    </div>
  );
}

export function Note({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <p className={`text-[--text-dim] text-sm leading-relaxed ${className}`}>{children}</p>;
}
