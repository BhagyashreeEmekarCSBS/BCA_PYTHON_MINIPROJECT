import { useState } from 'react';
import { Home, Table2, BarChart3, GitCompare, Cpu, Calculator, BookOpen, TrafficCone } from 'lucide-react';
import { AppStateProvider } from '@/lib/appState';
import HomePage from '@/pages/HomePage';
import DataExplorerPage from '@/pages/DataExplorerPage';
import TrafficAnalysisPage from '@/pages/TrafficAnalysisPage';
import CorrelationPage from '@/pages/CorrelationPage';
import MLPage from '@/pages/MLPage';
import PredictionPage from '@/pages/PredictionPage';
import InfoPage from '@/pages/InfoPage';

export type Page = 'home' | 'data' | 'analysis' | 'correlation' | 'ml' | 'prediction' | 'info';

const NAV: { key: Page; label: string; icon: typeof Home }[] = [
  { key: 'home', label: 'Home', icon: Home },
  { key: 'data', label: 'Dataset Explorer', icon: Table2 },
  { key: 'analysis', label: 'Traffic Analysis', icon: BarChart3 },
  { key: 'correlation', label: 'Correlation', icon: GitCompare },
  { key: 'ml', label: 'Machine Learning', icon: Cpu },
  { key: 'prediction', label: 'Prediction', icon: Calculator },
  { key: 'info', label: 'Project Info', icon: BookOpen },
];

function Shell() {
  const [page, setPage] = useState<Page>('home');

  const go = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex min-h-screen">
      <aside className="hidden md:flex flex-col w-64 shrink-0 border-r border-[--border] glass sticky top-0 h-screen">
        <div className="px-5 py-5 flex items-center gap-2.5 border-b border-[--border]">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-emerald-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <TrafficCone className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-semibold text-sm leading-tight">Traffic Flow</div>
            <div className="text-[--text-dim] text-xs">Optimization System</div>
          </div>
        </div>
        <nav className="flex-1 py-3">
          {NAV.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => go(key)}
              className={`nav-item w-full flex items-center gap-3 px-5 py-2.5 text-sm transition ${page === key ? 'active' : 'text-[--text-dim]'}`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </nav>
        <div className="px-5 py-4 border-t border-[--border] text-[10px] text-[--text-dim]">
          College Mini Project · React + TypeScript · In-browser ML
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <div className="md:hidden glass border-b border-[--border] sticky top-0 z-10">
          <div className="flex items-center gap-2 px-4 py-3 overflow-x-auto">
            {NAV.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => go(key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition ${page === key ? 'bg-blue-500/20 text-blue-200' : 'text-[--text-dim]'}`}
              >
                <Icon className="w-3.5 h-3.5" />{label}
              </button>
            ))}
          </div>
        </div>

        <main className="flex-1 p-4 md:p-8 max-w-[1400px] w-full mx-auto">
          {page === 'home' && <HomePage go={go} />}
          {page === 'data' && <DataExplorerPage />}
          {page === 'analysis' && <TrafficAnalysisPage />}
          {page === 'correlation' && <CorrelationPage />}
          {page === 'ml' && <MLPage />}
          {page === 'prediction' && <PredictionPage />}
          {page === 'info' && <InfoPage />}
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AppStateProvider>
      <Shell />
    </AppStateProvider>
  );
}

export default App;
