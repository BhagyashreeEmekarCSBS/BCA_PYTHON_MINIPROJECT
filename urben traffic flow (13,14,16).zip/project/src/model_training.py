"""
model_training.py

Model training and evaluation for traffic volume prediction.
Trains and compares Linear Regression, Decision Tree Regressor, and Random Forest Regressor.
Evaluates using MAE, MSE, RMSE, R². Saves the best model to disk.
"""

import os
import time
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline

from data_preprocessing import build_preprocessing_pipeline, get_feature_columns, split_data

MODELS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")


def get_models():
    return {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=12, min_samples_split=12, random_state=42),
        "Random Forest": RandomForestRegressor(n_estimators=25, max_depth=10, min_samples_split=4, random_state=42, n_jobs=-1),
    }


def compute_metrics(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    return {"MAE": mae, "MSE": mse, "RMSE": rmse, "R2": r2}


def train_and_evaluate(df, target_col="traffic_volume"):
    numeric_features, categorical_features = get_feature_columns()
    numeric_features = [c for c in numeric_features if c in df.columns]
    categorical_features = [c for c in categorical_features if c in df.columns]
    feature_names = numeric_features + categorical_features

    cols = feature_names + [target_col]
    df_model = df[cols].dropna().reset_index(drop=True)

    if len(df_model) < 10:
        raise ValueError("Not enough data to train models (need at least 10 rows after cleaning).")

    X_train, X_test, y_train, y_test = split_data(df_model, target_col=target_col, test_size=0.2)
    X_train = X_train[feature_names]
    X_test = X_test[feature_names]

    results = []
    trained_pipelines = {}
    predictions = {}

    for name, model in get_models().items():
        preprocessor = build_preprocessing_pipeline(numeric_features, categorical_features)
        pipeline = Pipeline([("preprocessor", preprocessor), ("model", model)])
        start = time.time()
        pipeline.fit(X_train, y_train)
        train_time = time.time() - start
        y_pred = pipeline.predict(X_test)
        y_pred = np.maximum(0, y_pred)
        metrics = compute_metrics(y_test, y_pred)
        results.append({
            "Model": name, "MAE": metrics["MAE"], "MSE": metrics["MSE"],
            "RMSE": metrics["RMSE"], "R2": metrics["R2"], "Train time (s)": round(train_time, 3),
        })
        trained_pipelines[name] = pipeline
        predictions[name] = y_pred

    results_df = pd.DataFrame(results).sort_values(by=["R2", "RMSE"], ascending=[False, True]).reset_index(drop=True)
    best_name = results_df.iloc[0]["Model"]
    best_pipeline = trained_pipelines[best_name]

    importances = None
    if best_name == "Random Forest":
        rf_model = best_pipeline.named_steps["model"]
        preprocessor = best_pipeline.named_steps["preprocessor"]
        try:
            num_names = preprocessor.named_transformers_["num"].get_feature_names_out(numeric_features).tolist()
        except Exception:
            num_names = numeric_features
        try:
            cat_names = preprocessor.named_transformers_["cat"].get_feature_names_out(categorical_features).tolist()
        except Exception:
            cat_names = categorical_features
        all_names = num_names + cat_names
        importances = list(zip(all_names, rf_model.feature_importances_))
        importances.sort(key=lambda x: x[1], reverse=True)

    return {
        "results_df": results_df, "best_name": best_name, "best_pipeline": best_pipeline,
        "feature_names": feature_names, "X_test": X_test, "y_test": y_test,
        "predictions": predictions, "importances": importances,
        "train_size": len(X_train), "test_size": len(X_test),
    }


def save_model(pipeline, name="best_model.joblib"):
    os.makedirs(MODELS_DIR, exist_ok=True)
    path = os.path.join(MODELS_DIR, name)
    joblib.dump(pipeline, path)
    return path


def load_model(name="best_model.joblib"):
    path = os.path.join(MODELS_DIR, name)
    if not os.path.exists(path):
        return None
    return joblib.load(path)


def model_exists(name="best_model.joblib"):
    return os.path.exists(os.path.join(MODELS_DIR, name))