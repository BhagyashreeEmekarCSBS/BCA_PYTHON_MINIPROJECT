"""
prediction.py

Traffic volume prediction logic.
Uses the trained model pipeline to predict traffic volume from user inputs.
"""

import numpy as np
import pandas as pd

from data_preprocessing import get_feature_columns


def make_prediction_input(hour, weekday, month, is_weekend, is_holiday,
                          temp, rain_1h, snow_1h, clouds_all, weather_main):
    numeric_features, categorical_features = get_feature_columns()
    data = {}
    for col in numeric_features + categorical_features:
        if col == "hour":
            data[col] = int(hour)
        elif col == "weekday":
            data[col] = int(weekday)
        elif col == "month":
            data[col] = int(month)
        elif col == "is_weekend":
            data[col] = int(is_weekend)
        elif col == "is_holiday":
            data[col] = int(is_holiday)
        elif col == "temp":
            data[col] = float(temp)
        elif col == "rain_1h":
            data[col] = float(rain_1h)
        elif col == "snow_1h":
            data[col] = float(snow_1h)
        elif col == "clouds_all":
            data[col] = int(clouds_all)
        elif col == "weather_main":
            data[col] = str(weather_main)
        else:
            data[col] = 0
    return pd.DataFrame([data])


def classify_congestion(predicted_volume, traffic_mean, traffic_std):
    if traffic_std == 0 or np.isnan(traffic_std):
        if predicted_volume < traffic_mean:
            return "Low", "Below the dataset average. Expect smooth flow."
        elif predicted_volume > traffic_mean:
            return "High", "Above the dataset average. Expect congestion."
        else:
            return "Moderate", "Close to the dataset average."
    low_threshold = traffic_mean - 0.5 * traffic_std
    high_threshold = traffic_mean + 0.5 * traffic_std
    if predicted_volume < low_threshold:
        return "Low", f"Below average (avg = {traffic_mean:.0f}). Expect smooth flow."
    elif predicted_volume > high_threshold:
        return "High", f"Well above average (avg = {traffic_mean:.0f}). Expect congestion."
    else:
        return "Moderate", "Close to the dataset average; typical conditions expected."


def predict_traffic(pipeline, input_data, traffic_mean=0, traffic_std=0):
    if pipeline is None:
        raise ValueError("Model is not trained or loaded. Please train the model first.")
    numeric_features, categorical_features = get_feature_columns()
    expected_cols = [c for c in numeric_features + categorical_features if c in input_data.columns]
    input_data = input_data[expected_cols]
    predicted = pipeline.predict(input_data)[0]
    predicted = max(0, predicted)
    level, explanation = classify_congestion(predicted, traffic_mean, traffic_std)
    return float(predicted), level, explanation


def validate_input(temp, rain, snow, clouds, hour):
    errors = []
    if hour < 0 or hour > 23:
        errors.append("Hour must be between 0 and 23.")
    if clouds < 0 or clouds > 100:
        errors.append("Cloud coverage must be between 0 and 100.")
    if rain < 0:
        errors.append("Rainfall must be non-negative.")
    if snow < 0:
        errors.append("Snowfall must be non-negative.")
    if temp < 0 or temp > 350:
        errors.append("Temperature must be between 0 and 350 Kelvin.")
    if errors:
        return False, " ".join(errors)
    return True, ""