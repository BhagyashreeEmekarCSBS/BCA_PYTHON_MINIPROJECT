"""
data_preprocessing.py

Data cleaning and feature engineering for the Metro Interstate Traffic Volume dataset.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline


COLUMN_ALIASES = {
    "date_time": ["date_time", "datetime", "timestamp", "time", "date"],
    "traffic_volume": ["traffic_volume", "traffic"],
    "temp": ["temp", "temperature"],
    "rain_1h": ["rain_1h", "rain", "rainfall", "precipitation"],
    "snow_1h": ["snow_1h", "snow", "snowfall"],
    "clouds_all": ["clouds_all", "clouds", "cloud_coverage", "cloud cover"],
    "weather_main": ["weather_main", "weather", "weather_condition"],
    "holiday": ["holiday", "is_holiday"],
}


def find_column(df_columns, candidates):
    lower_cols = {c.lower().strip(): c for c in df_columns}
    for candidate in candidates:
        if candidate in lower_cols:
            return lower_cols[candidate]
    for candidate in candidates:
        for lc, orig in lower_cols.items():
            if candidate in lc:
                return orig
    return None


def map_columns(df):
    mapping = {}
    for standard, aliases in COLUMN_ALIASES.items():
        col = find_column(df.columns, aliases)
        if col and col != standard:
            mapping[col] = standard
    if mapping:
        df = df.rename(columns=mapping)
    return df


def load_dataset(filepath):
    try:
        df = pd.read_csv(filepath)
    except Exception as e:
        raise ValueError(f"Could not read CSV file: {e}")
    if df.empty:
        raise ValueError("The CSV file is empty.")
    df = map_columns(df)
    return df


def generate_sample_data(n_rows=6000, seed=7):
    rng = np.random.RandomState(seed)
    start = pd.Timestamp("2017-01-01")
    hours = pd.date_range(start, periods=n_rows, freq="h")
    records = []
    for ts in hours:
        hour = ts.hour
        day_of_week = ts.dayofweek
        month = ts.month
        is_weekend = 1 if day_of_week >= 5 else 0
        is_holiday = 1 if rng.rand() < 0.03 else 0
        temp = 288 + 18 * np.sin(2 * np.pi * (month - 6) / 12) + (rng.rand() - 0.5) * 6
        cold_season = month <= 2 or month >= 10
        wr = rng.rand()
        if wr < 0.45:
            weather = "Clear"
        elif wr < 0.70:
            weather = "Clouds"
        elif wr < 0.82:
            weather = "Snow" if cold_season else "Rain"
        elif wr < 0.90:
            weather = "Mist"
        elif wr < 0.95:
            weather = "Haze"
        else:
            weather = "Thunderstorm"
        rain = 0.0
        snow = 0.0
        if weather == "Rain":
            rain = round(rng.rand() * 2.5, 2)
        elif weather == "Snow":
            snow = round(rng.rand() * 0.5, 2)
        elif weather == "Thunderstorm":
            rain = round(rng.rand() * 5.0, 2)
        if weather == "Clouds":
            clouds = int(60 + rng.rand() * 40)
        elif weather in ("Mist", "Haze", "Fog"):
            clouds = int(70 + rng.rand() * 30)
        elif weather == "Clear":
            clouds = int(rng.rand() * 20)
        else:
            clouds = int(40 + rng.rand() * 50)
        morning = np.exp(-((hour - 8) ** 2) / 4) * 1500
        evening = np.exp(-((hour - 17) ** 2) / 5) * 1700
        base = 500 + morning + evening
        weekday_effect = -800 if is_weekend else 0
        seasonal = 200 * np.sin(2 * np.pi * month / 12)
        weather_effect = {"Rain": -250, "Snow": -600, "Thunderstorm": -400, "Fog": -150, "Mist": -150}.get(weather, 0)
        holiday_effect = -1200 if is_holiday else 0
        temp_effect = -100 if abs(temp - 290) > 15 else 0
        noise = (rng.rand() - 0.5) * 400
        volume = max(0, round(base + weekday_effect + seasonal + weather_effect + holiday_effect + temp_effect + noise))
        records.append({
            "holiday": "Holiday" if is_holiday else "None",
            "temp": round(temp, 2),
            "rain_1h": rain,
            "snow_1h": snow,
            "clouds_all": clouds,
            "weather_main": weather,
            "date_time": ts.strftime("%Y-%m-%d %H:%M:%S"),
            "traffic_volume": int(volume),
        })
    return pd.DataFrame(records)


def preprocess_data(df):
    report = {"duplicates_removed": 0, "missing_imputed": 0, "total_rows": 0, "notes": []}
    initial_rows = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    report["duplicates_removed"] = initial_rows - len(df)

    if "date_time" not in df.columns:
        report["notes"].append("No date_time column detected — time features unavailable.")
        for col in ["hour", "day", "month", "year", "weekday", "is_weekend"]:
            df[col] = 0
    else:
        df["date_time"] = pd.to_datetime(df["date_time"], errors="coerce")
        bad_dt = df["date_time"].isna().sum()
        if bad_dt > 0:
            df = df.dropna(subset=["date_time"]).reset_index(drop=True)
            report["notes"].append(f"Dropped {bad_dt} rows with unparseable date_time.")
        df["hour"] = df["date_time"].dt.hour
        df["day"] = df["date_time"].dt.day
        df["month"] = df["date_time"].dt.month
        df["year"] = df["date_time"].dt.year
        df["weekday"] = df["date_time"].dt.dayofweek
        df["is_weekend"] = (df["weekday"] >= 5).astype(int)

    if "holiday" in df.columns:
        df["is_holiday"] = df["holiday"].apply(lambda x: 0 if pd.isna(x) or str(x).strip().lower() == "none" else 1)
    else:
        df["is_holiday"] = 0
        report["notes"].append("No holiday column detected — is_holiday set to 0.")

    numeric_cols = ["temp", "rain_1h", "snow_1h", "clouds_all", "traffic_volume"]
    for col in numeric_cols:
        if col in df.columns:
            missing = df[col].isna().sum()
            if missing > 0:
                if col == "traffic_volume":
                    df = df.dropna(subset=[col]).reset_index(drop=True)
                    report["notes"].append(f"Dropped {missing} rows with missing traffic_volume.")
                else:
                    df[col] = df[col].fillna(df[col].mean())
                    report["missing_imputed"] += missing

    if "weather_main" in df.columns:
        df["weather_main"] = df["weather_main"].fillna("Clear")
    else:
        df["weather_main"] = "Clear"
        report["notes"].append("No weather_main column detected — set to 'Clear'.")

    report["total_rows"] = len(df)
    return df, report


def get_feature_columns():
    numeric_features = ["hour", "weekday", "month", "is_weekend", "is_holiday", "temp", "rain_1h", "snow_1h", "clouds_all"]
    categorical_features = ["weather_main"]
    return numeric_features, categorical_features


def build_preprocessing_pipeline(numeric_features, categorical_features):
    numeric_transformer = StandardScaler()
    categorical_transformer = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features),
        ],
        remainder="drop",
    )
    return preprocessor


def split_data(df, target_col="traffic_volume", test_size=0.2, random_state=42):
    feature_cols = [c for c in df.columns if c != target_col]
    if "date_time" in df.columns:
        df = df.sort_values("date_time").reset_index(drop=True)
        split_idx = int(len(df) * (1 - test_size))
        train_df = df.iloc[:split_idx]
        test_df = df.iloc[split_idx:]
        X_train = train_df[feature_cols]
        X_test = test_df[feature_cols]
        y_train = train_df[target_col]
        y_test = test_df[target_col]
    else:
        X_train, X_test, y_train, y_test = train_test_split(
            df[feature_cols], df[target_col], test_size=test_size, random_state=random_state
        )
    return X_train, X_test, y_train, y_test


def get_dataset_summary(df):
    summary = {
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "missing_values": int(df.isna().sum().sum()),
        "duplicates": int(df.duplicated().sum()),
    }
    if "traffic_volume" in df.columns:
        summary["traffic_mean"] = float(df["traffic_volume"].mean())
        summary["traffic_std"] = float(df["traffic_volume"].std())
        summary["traffic_min"] = float(df["traffic_volume"].min())
        summary["traffic_max"] = float(df["traffic_volume"].max())
    return summary