// Data cleaning + feature engineering for the traffic dataset.
import {
  Dataset, EngineeredDataset, FeatureRow, detectColumns, parseDateTime, inferColumns,
} from './dataset';

export interface PreprocessReport {
  removedDuplicates: number;
  handledMissing: number;
  totalRows: number;
  notes: string[];
}

export function buildDataset(headers: string[], rows: string[][]): Dataset {
  const columns = inferColumns(headers, rows);
  return { headers, rawRows: rows, columns, rowCount: rows.length };
}

export function preprocess(ds: Dataset): { engineered: EngineeredDataset; report: PreprocessReport } {
  const notes: string[] = [];
  const cols = detectColumns(ds.headers);

  if (!cols.datetime) notes.push('No date_time column detected — time-based features unavailable.');
  if (!cols.traffic) notes.push('No traffic_volume column detected — target unavailable; prediction disabled.');

  const seen = new Set<string>();
  const uniqueRows: string[][] = [];
  for (const r of ds.rawRows) {
    const key = r.join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    uniqueRows.push(r);
  }
  const removedDuplicates = ds.rawRows.length - uniqueRows.length;

  const colIndex: Record<string, number> = {};
  ds.headers.forEach((h, i) => { colIndex[h] = i; });

  const idx = {
    datetime: cols.datetime ? colIndex[cols.datetime] : -1,
    traffic: cols.traffic ? colIndex[cols.traffic] : -1,
    temp: cols.temp ? colIndex[cols.temp] : -1,
    rain: cols.rain ? colIndex[cols.rain] : -1,
    snow: cols.snow ? colIndex[cols.snow] : -1,
    clouds: cols.clouds ? colIndex[cols.clouds] : -1,
    weatherMain: cols.weatherMain ? colIndex[cols.weatherMain] : -1,
    holiday: cols.holiday ? colIndex[cols.holiday] : -1,
  };

  const numMeans: Record<string, number> = {};
  for (const key of ['temp', 'rain', 'snow', 'clouds'] as const) {
    const ci = idx[key];
    if (ci < 0) continue;
    const vals: number[] = [];
    for (const r of uniqueRows) {
      const v = parseFloat(r[ci]);
      if (!isNaN(v)) vals.push(v);
    }
    numMeans[key] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  }

  let weatherDefault = 'Clear';
  if (idx.weatherMain >= 0) {
    const counts = new Map<string, number>();
    for (const r of uniqueRows) {
      const v = (r[idx.weatherMain] ?? '').trim();
      if (v) counts.set(v, (counts.get(v) ?? 0) + 1);
    }
    if (counts.size) weatherDefault = [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
  }

  let handledMissing = 0;
  const featureRows: FeatureRow[] = [];
  const weatherSet = new Set<string>();

  for (const r of uniqueRows) {
    let missingThisRow = false;

    let dt = new Date(NaN);
    if (idx.datetime >= 0) {
      dt = parseDateTime(r[idx.datetime] ?? '');
      if (isNaN(dt.getTime())) missingThisRow = true;
    } else {
      missingThisRow = true;
    }

    const numField = (key: 'temp' | 'rain' | 'snow' | 'clouds'): number => {
      const ci = idx[key];
      if (ci < 0) return 0;
      const raw = (r[ci] ?? '').trim();
      if (raw === '') { handledMissing++; return numMeans[key]; }
      const v = parseFloat(raw);
      if (isNaN(v)) { handledMissing++; return numMeans[key]; }
      return v;
    };

    let weather = weatherDefault;
    if (idx.weatherMain >= 0) {
      const raw = (r[idx.weatherMain] ?? '').trim();
      if (!raw) { handledMissing++; } else weather = raw;
    }

    let isHoliday = 0;
    if (idx.holiday >= 0) {
      const raw = (r[idx.holiday] ?? '').trim();
      isHoliday = raw === '' || raw.toLowerCase() === 'none' ? 0 : 1;
    }

    let traffic: number | null = null;
    if (idx.traffic >= 0) {
      const raw = (r[idx.traffic] ?? '').trim();
      const v = parseFloat(raw);
      if (!isNaN(v)) traffic = v;
      else missingThisRow = true;
    }

    if (missingThisRow && idx.traffic >= 0 && traffic === null) continue;
    if (isNaN(dt.getTime())) continue;

    const fr: FeatureRow = {
      hour: dt.getHours(),
      day: (dt.getDay() + 6) % 7,
      dayName: '',
      month: dt.getMonth(),
      year: dt.getFullYear(),
      isWeekend: dt.getDay() === 0 || dt.getDay() === 6 ? 1 : 0,
      isHoliday,
      temp: numField('temp'),
      rain: numField('rain'),
      snow: numField('snow'),
      clouds: numField('clouds'),
      weatherMain: weather,
      trafficVolume: traffic,
      ts: dt.getTime(),
    };
    featureRows.push(fr);
    weatherSet.add(weather);
  }

  featureRows.sort((a, b) => a.ts - b.ts);

  const traffics = featureRows.map((r) => r.trafficVolume).filter((v): v is number => v !== null);
  const trafficMean = traffics.length ? traffics.reduce((a, b) => a + b, 0) / traffics.length : 0;
  const trafficStd = traffics.length
    ? Math.sqrt(traffics.reduce((a, b) => a + (b - trafficMean) ** 2, 0) / traffics.length)
    : 0;

  return {
    engineered: {
      rows: featureRows,
      weatherCategories: [...weatherSet].sort(),
      trafficMean, trafficStd,
      trafficMin: traffics.length ? Math.min(...traffics) : 0,
      trafficMax: traffics.length ? Math.max(...traffics) : 0,
    },
    report: { removedDuplicates, handledMissing, totalRows: featureRows.length, notes },
  };
}
