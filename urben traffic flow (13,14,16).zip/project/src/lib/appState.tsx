// Global app state: dataset, preprocessing report, trained models.
import { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { Dataset, EngineeredDataset } from './dataset';
import { buildDataset, preprocess } from './preprocess';
import { TrainingOutput, trainAll } from './training';

interface AppState {
  dataset: Dataset | null;
  engineered: EngineeredDataset | null;
  preprocessReport: { removedDuplicates: number; handledMissing: number; totalRows: number; notes: string[] } | null;
  training: TrainingOutput | null;
  isTraining: boolean;
  loadRaw: (headers: string[], rows: string[][]) => void;
  train: () => Promise<void>;
}

const Ctx = createContext<AppState | null>(null);

export function useAppState() {
  const v = useContext(Ctx);
  if (!v) throw new Error('AppStateProvider missing');
  return v;
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [dataset, setDataset] = useState<Dataset | null>(null);
  const [engineered, setEngineered] = useState<EngineeredDataset | null>(null);
  const [preprocessReport, setReport] = useState<AppState['preprocessReport']>(null);
  const [training, setTraining] = useState<TrainingOutput | null>(null);
  const [isTraining, setIsTraining] = useState(false);

  const loadRaw = useCallback((headers: string[], rows: string[][]) => {
    const ds = buildDataset(headers, rows);
    const { engineered, report } = preprocess(ds);
    setDataset(ds);
    setEngineered(engineered);
    setReport(report);
    setTraining(null);
  }, []);

  const train = useCallback(async () => {
    if (!engineered) return;
    setIsTraining(true);
    await new Promise((r) => setTimeout(r, 30));
    try {
      const out = trainAll(engineered);
      setTraining(out);
    } finally {
      setIsTraining(false);
    }
  }, [engineered]);

  return (
    <Ctx.Provider value={{ dataset, engineered, preprocessReport, training, isTraining, loadRaw, train }}>
      {children}
    </Ctx.Provider>
  );
}
