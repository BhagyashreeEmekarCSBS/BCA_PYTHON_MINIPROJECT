// Column detection + typed dataset model for the Metro Interstate Traffic dataset.

export type FieldType = 'datetime' | 'numeric' | 'categorical';

export interface ColumnInfo {
  name: string;
  type: FieldType;
  missingCount: number;
  uniqueCount: number;
  min?: number;
  max?: number;
  mean?: number;
  std?: number;
  topCategories?: { value: string; count: number }[];
  minDate?: string;
  maxDate?: string;
}

export interface Dataset {
  headers: string[];
  rawRows: string[][];
  columns: ColumnInfo[];
  rowCount: number;
}

export interface TimeFeatures {
  hour: number;
  day: number; // 0=Mon .. 6=Sun
  dayName: string;
  month: number;
  year: number;
  isWeekend: number;
  isHoliday: number;
}

export interface FeatureRow extends TimeFeatures {
  temp: number;
  rain: number;
  snow: number;
  clouds: number;
  weatherMain: string;
  trafficVolume: number | null;
  ts: number;
}

export interface EngineeredDataset {
  rows: FeatureRow[];
  weatherCategories: string[];
  trafficMean: number;
  trafficStd: number;
  trafficMin: number;
  trafficMax: number;
}

const ALIASES = {
  datetime: ['date_time', 'datetime', 'date time', 'timestamp', 'time', 'date'],
  traffic: ['traffic_volume', 'traffic volume', 'traffic'],
  temp: ['temp', 'temperature', 'temp_average', 'avg_temp'],
  rain: ['rain_1h', 'rain 1h', 'rain_1hr', 'rain', 'rainfall', 'precipitation'],
  snow: ['snow_1h', 'snow 1h', 'snow_1hr', 'snow', 'snowfall'],
  clouds: ['clouds_all', 'clouds all', 'clouds', 'cloud_coverage', 'cloud cover', 'cloud'],
  weatherMain: ['weather_main', 'weather main', 'weather', 'weather_condition', 'condition'],
  holiday: ['holiday', 'is_holiday', 'is holiday'],
};

function findHeader(headers: string[], candidates: string[]): string | null {
  const lower = headers.map((h) => h.toLowerCase().trim());
  for (const c of candidates) {
    const idx = lower.indexOf(c);
    if (idx !== -1) return headers[idx];
  }
  for (const c of candidates) {
    const idx = lower.findIndex((h) => h.includes(c));
    if (idx !== -1) return headers[idx];
  }
  return null;
}

export function detectColumns(headers: string[]) {
  return {
    datetime: findHeader(headers, ALIASES.datetime),
    traffic: findHeader(headers, ALIASES.traffic),
    temp: findHeader(headers, ALIASES.temp),
    rain: findHeader(headers, ALIASES.rain),
    snow: findHeader(headers, ALIASES.snow),
    clouds: findHeader(headers, ALIASES.clouds),
    weatherMain: findHeader(headers, ALIASES.weatherMain),
    holiday: findHeader(headers, ALIASES.holiday),
  };
}

export const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
export const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export function parseDateTime(value: string): Date {
  if (!value) return new Date(NaN);
  const v = value.trim();
  const t = Date.parse(v);
  if (!isNaN(t)) return new Date(t);

  const m = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (m) return new Date(+m[3], +m[1] - 1, +m[2], +m[4], +m[5], m[6] ? +m[6] : 0);

  const m2 = v.match(/^(\d{1,2})-(\d{1,2})-(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (m2) return new Date(+m2[3], +m2[2] - 1, +m2[1], +m2[4], +m2[5], m2[6] ? +m2[6] : 0);

  return new Date(NaN);
}

export function inferColumns(headers: string[], rawRows: string[][]): ColumnInfo[] {
  return headers.map((name, colIdx) => {
    const values = rawRows.map((r) => r[colIdx]).filter((v) => v !== undefined && v.trim() !== '');
    const missingCount = rawRows.length - values.length;
    const uniqueCount = new Set(values).size;

    const sample = values.slice(0, 50);
    const dtCount = sample.filter((v) => !isNaN(parseDateTime(v).getTime())).length;
    if (sample.length > 0 && dtCount / sample.length > 0.8) {
      const dates = sample.map((v) => parseDateTime(v)).filter((d) => !isNaN(d.getTime()));
      dates.sort((a, b) => a.getTime() - b.getTime());
      return {
        name, type: 'datetime' as FieldType, missingCount, uniqueCount,
        minDate: dates[0]?.toISOString(), maxDate: dates[dates.length - 1]?.toISOString(),
      };
    }

    const numCount = sample.filter((v) => v.trim() !== '' && !isNaN(parseFloat(v))).length;
    if (sample.length > 0 && numCount / sample.length > 0.8) {
      const nums = values.map((v) => parseFloat(v)).filter((n) => !isNaN(n));
      const mean = nums.reduce((a, b) => a + b, 0) / (nums.length || 1);
      const variance = nums.reduce((a, b) => a + (b - mean) ** 2, 0) / (nums.length || 1);
      return {
        name, type: 'numeric' as FieldType, missingCount, uniqueCount,
        min: Math.min(...nums), max: Math.max(...nums), mean, std: Math.sqrt(variance),
      };
    }

    const counts = new Map<string, number>();
    for (const v of values) counts.set(v, (counts.get(v) ?? 0) + 1);
    const top = [...counts.entries()].map(([value, count]) => ({ value, count })).sort((a, b) => b.count - a.count).slice(0, 8);
    return { name, type: 'categorical' as FieldType, missingCount, uniqueCount, topCategories: top };
  });
}
