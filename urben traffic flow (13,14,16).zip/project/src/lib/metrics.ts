// Train/test split (chronological, no leakage) and evaluation metrics.
export function chronologicalSplit(n: number, testRatio = 0.2): { trainIdx: number[]; testIdx: number[] } {
  const split = Math.floor(n * (1 - testRatio));
  return { trainIdx: Array.from({ length: split }, (_, i) => i), testIdx: Array.from({ length: n - split }, (_, i) => i + split) };
}

export interface Metrics {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
}

export function evaluate(yTrue: number[], yPred: number[]): Metrics {
  const n = yTrue.length;
  let mae = 0, mse = 0;
  const meanTrue = yTrue.reduce((a, b) => a + b, 0) / n;
  let ssTot = 0;
  for (let i = 0; i < n; i++) {
    const e = yTrue[i] - yPred[i];
    mae += Math.abs(e);
    mse += e * e;
    ssTot += (yTrue[i] - meanTrue) ** 2;
  }
  mae /= n; mse /= n;
  return { mae, mse, rmse: Math.sqrt(mse), r2: ssTot === 0 ? 0 : 1 - mse / ssTot };
}
