// Training pipeline: build feature matrix, train all 3 models, evaluate chronologically.
import { EngineeredDataset, FeatureRow } from './dataset';
import { fitEncoder, encodeFeature, FeatureInput, featureNames } from './features';
import { trainLinear, trainTree, trainForest, predict, AnyModel, forestFeatureImportance } from './models';
import { chronologicalSplit, evaluate, Metrics } from './metrics';

export interface ModelResult {
  name: string;
  model: AnyModel;
  metrics: Metrics;
  trainMs: number;
}

export interface TrainingOutput {
  models: ModelResult[];
  best: ModelResult;
  encoder: ReturnType<typeof fitEncoder>;
  featureNames: string[];
  testRows: FeatureRow[];
  yTest: number[];
  predictions: Record<string, number[]>;
  importances: { name: string; importance: number }[];
  trainSize: number;
  testSize: number;
}

export function toInput(r: FeatureRow): FeatureInput {
  return {
    hour: r.hour, day: r.day, month: r.month, isWeekend: r.isWeekend, isHoliday: r.isHoliday,
    temp: r.temp, rain: r.rain, snow: r.snow, clouds: r.clouds, weatherMain: r.weatherMain,
  };
}

export function trainAll(engineered: EngineeredDataset): TrainingOutput {
  const rows = engineered.rows.filter((r) => r.trafficVolume !== null) as (FeatureRow & { trafficVolume: number })[];
  const encoder = fitEncoder(engineered.weatherCategories);

  const X = rows.map((r) => encodeFeature(encoder, toInput(r)));
  const y = rows.map((r) => r.trafficVolume);

  const { trainIdx, testIdx } = chronologicalSplit(rows.length, 0.2);
  const XTrain = trainIdx.map((i) => X[i]);
  const yTrain = trainIdx.map((i) => y[i]);
  const yTest = testIdx.map((i) => y[i]);

  const models: ModelResult[] = [];
  const predictions: Record<string, number[]> = {};

  const t0 = performance.now();
  const lin = trainLinear(XTrain, yTrain);
  models.push({ name: 'Linear Regression', model: lin, metrics: evaluate(yTest, testIdx.map((i) => predict(lin, X[i]))), trainMs: performance.now() - t0 });
  predictions['Linear Regression'] = testIdx.map((i) => predict(lin, X[i]));

  const t1 = performance.now();
  const tree = trainTree(XTrain, yTrain);
  models.push({ name: 'Decision Tree', model: tree, metrics: evaluate(yTest, testIdx.map((i) => predict(tree, X[i]))), trainMs: performance.now() - t1 });
  predictions['Decision Tree'] = testIdx.map((i) => predict(tree, X[i]));

  const t2 = performance.now();
  const forest = trainForest(XTrain, yTrain, 25, 10, 4, 42);
  models.push({ name: 'Random Forest', model: forest, metrics: evaluate(yTest, testIdx.map((i) => predict(forest, X[i]))), trainMs: performance.now() - t2 });
  predictions['Random Forest'] = testIdx.map((i) => predict(forest, X[i]));

  const best = [...models].sort((a, b) => b.metrics.r2 - a.metrics.r2 || a.metrics.rmse - b.metrics.rmse)[0];

  const importances = best.model.type === 'forest'
    ? forestFeatureImportance(best.model as ReturnType<typeof trainForest>, featureNames(encoder))
    : featureNames(encoder).map((n) => ({ name: n, importance: 0 }));

  return {
    models, best, encoder, featureNames: featureNames(encoder),
    testRows: testIdx.map((i) => rows[i]), yTest, predictions, importances,
    trainSize: trainIdx.length, testSize: testIdx.length,
  };
}
