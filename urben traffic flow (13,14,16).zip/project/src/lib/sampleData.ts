// Generate a realistic sample of the Metro Interstate Traffic Volume dataset.
// Synthetic hourly records with realistic diurnal/weekday/seasonal/weather signal.

export const SAMPLE_HEADERS = [
  'holiday', 'temp', 'rain_1h', 'snow_1h', 'clouds_all', 'weather_main', 'date_time', 'traffic_volume',
];

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface SampleOptions {
  hours: number;
  seed: number;
}

export function generateSampleData(opts: SampleOptions = { hours: 6000, seed: 7 }): { headers: string[]; rows: string[][] } {
  const rng = mulberry32(opts.seed);
  const rows: string[][] = [];
  const start = new Date(2017, 0, 1, 0, 0, 0).getTime();

  for (let i = 0; i < opts.hours; i++) {
    const dt = new Date(start + i * 3600 * 1000);
    const hour = dt.getHours();
    const dayOfWeek = dt.getDay();
    const month = dt.getMonth();

    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6 ? 1 : 0;
    const isHoliday = rng() < 0.03 ? 1 : 0;

    const seasonalTemp = 288 + 18 * Math.sin((2 * Math.PI * (month - 6)) / 12) + (rng() - 0.5) * 6;
    const coldSeason = month <= 2 || month >= 10;
    let weather: string;
    const wr = rng();
    if (wr < 0.45) weather = 'Clear';
    else if (wr < 0.7) weather = 'Clouds';
    else if (wr < 0.82) weather = coldSeason ? 'Snow' : 'Rain';
    else if (wr < 0.9) weather = 'Mist';
    else if (wr < 0.95) weather = 'Haze';
    else weather = 'Thunderstorm';

    let rain = 0, snow = 0, clouds = 0;
    if (weather === 'Rain') rain = +(rng() * 2.5).toFixed(2);
    else if (weather === 'Snow') snow = +(rng() * 0.5).toFixed(2);
    else if (weather === 'Thunderstorm') rain = +(rng() * 5).toFixed(2);
    if (weather === 'Clouds') clouds = Math.floor(60 + rng() * 40);
    else if (weather === 'Mist' || weather === 'Haze' || weather === 'Fog') clouds = Math.floor(70 + rng() * 30);
    else if (weather === 'Clear') clouds = Math.floor(rng() * 20);
    else clouds = Math.floor(40 + rng() * 50);

    const morningRush = Math.exp(-((hour - 8) ** 2) / 4) * 1500;
    const eveningRush = Math.exp(-((hour - 17) ** 2) / 5) * 1700;
    const baseDiurnal = 500 + morningRush + eveningRush;
    const weekdayEffect = isWeekend ? -800 : 0;
    const seasonalEffect = 200 * Math.sin((2 * Math.PI * month) / 12);
    let weatherEffect = 0;
    if (weather === 'Rain') weatherEffect = -250;
    else if (weather === 'Snow') weatherEffect = -600;
    else if (weather === 'Thunderstorm') weatherEffect = -400;
    else if (weather === 'Fog' || weather === 'Mist') weatherEffect = -150;
    const holidayEffect = isHoliday ? -1200 : 0;
    const tempEffect = Math.abs(seasonalTemp - 290) > 15 ? -100 : 0;
    const noise = (rng() - 0.5) * 400;

    let volume = baseDiurnal + weekdayEffect + seasonalEffect + weatherEffect + holidayEffect + tempEffect + noise;
    volume = Math.max(0, Math.round(volume));

    const dateStr = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')} ${String(hour).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}:${String(dt.getSeconds()).padStart(2, '0')}`;

    rows.push([
      isHoliday ? 'Holiday' : 'None',
      seasonalTemp.toFixed(2),
      rain.toFixed(2),
      snow.toFixed(2),
      String(clouds),
      weather,
      dateStr,
      String(volume),
    ]);
  }

  return { headers: SAMPLE_HEADERS, rows };
}
