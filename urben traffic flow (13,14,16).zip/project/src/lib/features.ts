// Build numeric feature vectors from FeatureRow / user input, one-hot encoding weather.

export interface FeatureEncoder {
  weatherCategories: string[];
}

export function fitEncoder(weatherCategories: string[]): FeatureEncoder {
  return { weatherCategories: [...weatherCategories].sort() };
}

export function featureNames(encoder: FeatureEncoder): string[] {
  return [
    'hour_sin', 'hour_cos', 'day_sin', 'day_cos', 'month_sin', 'month_cos',
    'is_weekend', 'is_holiday', 'temp', 'rain', 'snow', 'clouds',
    ...encoder.weatherCategories.map((w) => `weather_${w}`),
  ];
}

export interface FeatureInput {
  hour: number;
  day: number;
  month: number;
  isWeekend: number;
  isHoliday: number;
  temp: number;
  rain: number;
  snow: number;
  clouds: number;
  weatherMain: string;
}

export function encodeFeature(encoder: FeatureEncoder, input: FeatureInput): number[] {
  const hourSin = Math.sin((2 * Math.PI * input.hour) / 24);
  const hourCos = Math.cos((2 * Math.PI * input.hour) / 24);
  const daySin = Math.sin((2 * Math.PI * input.day) / 7);
  const dayCos = Math.cos((2 * Math.PI * input.day) / 7);
  const monthSin = Math.sin((2 * Math.PI * input.month) / 12);
  const monthCos = Math.cos((2 * Math.PI * input.month) / 12);
  const weather = encoder.weatherCategories.map((w) => (w === input.weatherMain ? 1 : 0));
  return [
    hourSin, hourCos, daySin, dayCos, monthSin, monthCos,
    input.isWeekend, input.isHoliday, input.temp, input.rain, input.snow, input.clouds,
    ...weather,
  ];
}

export function defaultFeatureInput(): FeatureInput {
  const now = new Date();
  return {
    hour: now.getHours(),
    day: (now.getDay() + 6) % 7,
    month: now.getMonth(),
    isWeekend: now.getDay() === 0 || now.getDay() === 6 ? 1 : 0,
    isHoliday: 0,
    temp: 288,
    rain: 0,
    snow: 0,
    clouds: 40,
    weatherMain: 'Clear',
  };
}
