// Pure-TS regression models: Linear Regression, Decision Tree, Random Forest.

export interface LinearModel {
  type: 'linear';
  weights: number[];
  bias: number;
  xMean: number[];
  xStd: number[];
  yMean: number;
  yStd: number;
}

function standardizeFit(X: number[][]): { mean: number[]; std: number[] } {
  const n = X.length;
  const d = X[0]?.length ?? 0;
  const mean = new Array(d).fill(0);
  const std = new Array(d).fill(0);
  for (const row of X) for (let j = 0; j < d; j++) mean[j] += row[j];
  for (let j = 0; j < d; j++) mean[j] /= n;
  for (const row of X) for (let j = 0; j < d; j++) std[j] += (row[j] - mean[j]) ** 2;
  for (let j = 0; j < d; j++) std[j] = Math.sqrt(std[j] / n) || 1;
  return { mean, std };
}

export function trainLinear(X: number[][], y: number[], iterations = 600, lr = 0.05): LinearModel {
  const { mean, std } = standardizeFit(X);
  const xStd = X.map((row) => row.map((v, j) => (v - mean[j]) / std[j]));
  const n = xStd.length;
  const d = xStd[0].length;
  const yMean = y.reduce((a, b) => a + b, 0) / n;
  const yStdRaw = Math.sqrt(y.reduce((a, b) => a + (b - yMean) ** 2, 0) / n) || 1;
  const yNorm = y.map((v) => (v - yMean) / yStdRaw);

  const weights = new Array(d).fill(0);
  let bias = 0;
  for (let it = 0; it < iterations; it++) {
    const grads = new Array(d).fill(0);
    let gradB = 0;
    for (let i = 0; i < n; i++) {
      let pred = bias;
      for (let j = 0; j < d; j++) pred += weights[j] * xStd[i][j];
      const err = pred - yNorm[i];
      for (let j = 0; j < d; j++) grads[j] += err * xStd[i][j];
      gradB += err;
    }
    for (let j = 0; j < d; j++) weights[j] -= (lr * grads[j]) / n;
    bias -= (lr * gradB) / n;
  }

  return { type: 'linear', weights, bias, xMean: mean, xStd: std, yMean, yStd: yStdRaw };
}

export function predictLinear(model: LinearModel, x: number[]): number {
  let z = model.bias;
  for (let j = 0; j < x.length; j++) z += model.weights[j] * ((x[j] - model.xMean[j]) / model.xStd[j]);
  return z * model.yStd + model.yMean;
}

export interface TreeNode {
  leaf: boolean;
  value?: number;
  feature?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

export interface DecisionTreeModel {
  type: 'tree';
  root: TreeNode;
  maxDepth: number;
  minSamples: number;
}

function variance(y: number[]): number {
  if (y.length === 0) return 0;
  const m = y.reduce((a, b) => a + b, 0) / y.length;
  return y.reduce((a, b) => a + (b - m) ** 2, 0) / y.length;
}

function bestSplit(X: number[][], y: number[], features: number[]): { feature: number; threshold: number; gain: number } | null {
  const n = y.length;
  const totalVar = variance(y) * n;
  let best: { feature: number; threshold: number; gain: number } | null = null;

  for (const f of features) {
    const vals = [...new Set(X.map((r) => r[f]))].sort((a, b) => a - b);
    for (let k = 0; k < vals.length - 1; k++) {
      const threshold = (vals[k] + vals[k + 1]) / 2;
      const left: number[] = [], right: number[] = [];
      for (let i = 0; i < n; i++) {
        if (X[i][f] <= threshold) left.push(y[i]); else right.push(y[i]);
      }
      if (left.length === 0 || right.length === 0) continue;
      const gain = totalVar - (variance(left) * left.length + variance(right) * right.length);
      if (!best || gain > best.gain) best = { feature: f, threshold, gain };
    }
  }
  return best;
}

function buildTree(X: number[][], y: number[], depth: number, maxDepth: number, minSamples: number, features: number[]): TreeNode {
  const mean = y.reduce((a, b) => a + b, 0) / y.length;
  if (depth >= maxDepth || y.length < minSamples || variance(y) === 0) return { leaf: true, value: mean };
  const split = bestSplit(X, y, features);
  if (!split || split.gain <= 0) return { leaf: true, value: mean };

  const leftIdx: number[] = [], rightIdx: number[] = [];
  for (let i = 0; i < X.length; i++) {
    if (X[i][split.feature] <= split.threshold) leftIdx.push(i); else rightIdx.push(i);
  }
  if (leftIdx.length === 0 || rightIdx.length === 0) return { leaf: true, value: mean };

  return {
    leaf: false,
    feature: split.feature,
    threshold: split.threshold,
    left: buildTree(leftIdx.map((i) => X[i]), leftIdx.map((i) => y[i]), depth + 1, maxDepth, minSamples, features),
    right: buildTree(rightIdx.map((i) => X[i]), rightIdx.map((i) => y[i]), depth + 1, maxDepth, minSamples, features),
  };
}

export function trainTree(X: number[][], y: number[], maxDepth = 12, minSamples = 12): DecisionTreeModel {
  const features = X[0].map((_, i) => i);
  return { type: 'tree', root: buildTree(X, y, 0, maxDepth, minSamples, features), maxDepth, minSamples };
}

export function predictTree(node: TreeNode, x: number[]): number {
  let cur: TreeNode = node;
  while (!cur.leaf) {
    if (x[cur.feature!] <= cur.threshold!) cur = cur.left!; else cur = cur.right!;
  }
  return cur.value ?? 0;
}

export interface RandomForestModel {
  type: 'forest';
  trees: { tree: TreeNode; featureIdx: number[] }[];
  maxDepth: number;
  nEstimators: number;
}

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function trainForest(
  X: number[][], y: number[], nEstimators = 25, maxDepth = 10, minSamples = 4, seed = 42,
): RandomForestModel {
  const rng = mulberry32(seed);
  const n = X.length;
  const d = X[0].length;
  const mtry = Math.max(1, Math.round(Math.sqrt(d)));
  const trees: { tree: TreeNode; featureIdx: number[] }[] = [];

  for (let b = 0; b < nEstimators; b++) {
    const sampleIdx: number[] = [];
    for (let i = 0; i < n; i++) sampleIdx.push(Math.floor(rng() * n));
    const Xb = sampleIdx.map((i) => X[i]);
    const yb = sampleIdx.map((i) => y[i]);

    const allFeatures = X[0].map((_, i) => i);
    const shuffled = [...allFeatures].sort(() => rng() - 0.5);
    const featureIdx = shuffled.slice(0, mtry);

    trees.push({ tree: buildTree(Xb, yb, 0, maxDepth, minSamples, featureIdx), featureIdx });
  }
  return { type: 'forest', trees, maxDepth, nEstimators };
}

export function predictForest(model: RandomForestModel, x: number[]): number {
  let sum = 0;
  for (const { tree, featureIdx } of model.trees) {
    const projected = featureIdx.map((i) => x[i]);
    let node: TreeNode = tree;
    while (!node.leaf) {
      const xi = projected[node.feature!];
      if (xi <= node.threshold!) node = node.left!; else node = node.right!;
    }
    sum += node.value ?? 0;
  }
  return sum / model.trees.length;
}

export type AnyModel = LinearModel | DecisionTreeModel | RandomForestModel;
export function predict(model: AnyModel, x: number[]): number {
  if (model.type === 'linear') return predictLinear(model, x);
  if (model.type === 'tree') return predictTree(model.root, x);
  return predictForest(model, x);
}

export function forestFeatureImportance(model: RandomForestModel, featureNames: string[]): { name: string; importance: number }[] {
  const counts = new Array(featureNames.length).fill(0);
  function walk(node: TreeNode, globalIdx: number[]) {
    if (!node.leaf && node.feature !== undefined) {
      counts[globalIdx[node.feature]]++;
      if (node.left) walk(node.left, globalIdx);
      if (node.right) walk(node.right, globalIdx);
    }
  }
  for (const { tree, featureIdx } of model.trees) walk(tree, featureIdx);
  const total = counts.reduce((a, b) => a + b, 0) || 1;
  return featureNames.map((name, i) => ({ name, importance: counts[i] / total }));
}
