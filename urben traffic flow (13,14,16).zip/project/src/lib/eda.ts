// Aggregation helpers used by EDA pages.
import { EngineeredDataset } from './dataset';
import { DAY_NAMES, MONTH_NAMES } from './dataset';

export function avgByHour(ds: EngineeredDataset): number[] {
  const sums = new Array(24).fill(0), counts = new Array(24).fill(0);
  for (const r of ds.rows) {
    if (r.trafficVolume === null) continue;
    sums[r.hour] += r.trafficVolume; counts[r.hour]++;
  }
  return sums.map((s, i) => (counts[i] ? s / counts[i] : 0));
}

export function avgByDayOfWeek(ds: EngineeredDataset): { label: string; value: number }[] {
  const sums = new Array(7).fill(0), counts = new Array(7).fill(0);
  for (const r of ds.rows) {
    if (r.trafficVolume === null) continue;
    sums[r.day] += r.trafficVolume; counts[r.day]++;
  }
  return DAY_NAMES.map((label, i) => ({ label, value: counts[i] ? sums[i] / counts[i] : 0 }));
}

export function avgByMonth(ds: EngineeredDataset): { label: string; value: number }[] {
  const sums = new Array(12).fill(0), counts = new Array(12).fill(0);
  for (const r of ds.rows) {
    if (r.trafficVolume === null) continue;
    sums[r.month] += r.trafficVolume; counts[r.month]++;
  }
  return MONTH_NAMES.map((label, i) => ({ label: label.slice(0, 3), value: counts[i] ? sums[i] / counts[i] : 0 }));
}

export function weekdayVsWeekend(ds: EngineeredDataset): { label: string; value: number }[] {
  const wd = { sum: 0, count: 0 }, we = { sum: 0, count: 0 };
  for (const r of ds.rows) {
    if (r.trafficVolume === null) continue;
    if (r.isWeekend) { we.sum += r.trafficVolume; we.count++; }
    else { wd.sum += r.trafficVolume; wd.count++; }
  }
  return [
    { label: 'Weekday', value: wd.count ? wd.sum / wd.count : 0 },
    { label: 'Weekend', value: we.count ? we.sum / we.count : 0 },
  ];
}

export function avgByWeather(ds: EngineeredDataset): { label: string; value: number; count: number }[] {
  const map = new Map<string, { sum: number; count: number }>();
  for (const r of ds.rows) {
    if (r.trafficVolume === null) continue;
    const e = map.get(r.weatherMain) ?? { sum: 0, count: 0 };
    e.sum += r.trafficVolume; e.count++;
    map.set(r.weatherMain, e);
  }
  return [...map.entries()].map(([label, e]) => ({ label, value: e.count ? e.sum / e.count : 0, count: e.count })).sort((a, b) => b.value - a.value);
}

export function tempVsTraffic(ds: EngineeredDataset, maxPoints = 1500): { x: number; y: number }[] {
  const rows = ds.rows.filter((r) => r.trafficVolume !== null);
  if (rows.length <= maxPoints) return rows.map((r) => ({ x: r.temp, y: r.trafficVolume as number }));
  const step = rows.length / maxPoints;
  const out: { x: number; y: number }[] = [];
  for (let i = 0; i < rows.length; i += step) out.push({ x: rows[Math.floor(i)].temp, y: rows[Math.floor(i)].trafficVolume as number });
  return out;
}

export function hourlyTrend(ds: EngineeredDataset, maxPoints = 800): { x: number; y: number }[] {
  const rows = ds.rows.filter((r) => r.trafficVolume !== null);
  if (rows.length === 0) return [];
  const step = Math.max(1, Math.floor(rows.length / maxPoints));
  const out: { x: number; y: number }[] = [];
  for (let i = 0; i < rows.length; i += step) out.push({ x: rows[i].ts, y: rows[i].trafficVolume as number });
  return out;
}

export interface CorrelationMatrix {
  labels: string[];
  values: number[][];
}

export function correlationMatrix(ds: EngineeredDataset): CorrelationMatrix {
  const fields = ['hour', 'isWeekend', 'isHoliday', 'temp', 'rain', 'snow', 'clouds', 'trafficVolume'];
  const labels = ['Hour', 'Weekend', 'Holiday', 'Temp', 'Rain', 'Snow', 'Clouds', 'Traffic'];
  const cols = fields.map((f) => ds.rows.map((r) => (r as unknown as Record<string, number>)[f] ?? 0));
  const n = cols[0].length;
  const means = cols.map((c) => c.reduce((a, b) => a + b, 0) / n);
  const stds = cols.map((c, i) => Math.sqrt(c.reduce((a, b) => a + (b - means[i]) ** 2, 0) / n) || 1);
  const corr: number[][] = [];
  for (let i = 0; i < fields.length; i++) {
    const row: number[] = [];
    for (let j = 0; j < fields.length; j++) {
      let cov = 0;
      for (let k = 0; k < n; k++) cov += (cols[i][k] - means[i]) * (cols[j][k] - means[j]);
      cov /= n;
      row.push(cov / (stds[i] * stds[j]));
    }
    corr.push(row);
  }
  return { labels, values: corr };
}
