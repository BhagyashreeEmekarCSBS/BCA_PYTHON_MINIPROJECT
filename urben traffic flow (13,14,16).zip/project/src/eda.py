"""
eda.py

Exploratory Data Analysis: visualizations and analysis for the traffic dataset.
All functions return matplotlib Figure objects for display in Streamlit.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 100
plt.rcParams["font.size"] = 10

DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def plot_traffic_over_time(df):
    fig, ax = plt.subplots(figsize=(12, 5))
    if "date_time" in df.columns and "traffic_volume" in df.columns:
        plot_df = df[["date_time", "traffic_volume"]].dropna()
        ax.plot(plot_df["date_time"], plot_df["traffic_volume"], color="#3b82f6", linewidth=0.8, alpha=0.8)
        ax.set_title("Traffic Volume Over Time", fontsize=14, fontweight="bold")
        ax.set_xlabel("Date")
        ax.set_ylabel("Traffic Volume (vehicles/hr)")
        ax.tick_params(axis="x", rotation=30)
    else:
        ax.text(0.5, 0.5, "date_time or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def plot_avg_by_hour(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    peak_hour = None
    if "hour" in df.columns and "traffic_volume" in df.columns:
        hourly = df.groupby("hour")["traffic_volume"].mean().reindex(range(24), fill_value=0)
        peak_hour = hourly.idxmax()
        colors = ["#ef4444" if h == peak_hour else "#3b82f6" for h in range(24)]
        ax.bar(hourly.index, hourly.values, color=colors, edgecolor="white", linewidth=0.5)
        ax.set_title(f"Average Traffic Volume by Hour (Peak: {peak_hour}:00)", fontsize=14, fontweight="bold")
        ax.set_xlabel("Hour of Day")
        ax.set_ylabel("Avg Traffic Volume (vehicles/hr)")
        ax.set_xticks(range(24))
    else:
        ax.text(0.5, 0.5, "hour or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig, peak_hour


def plot_avg_by_day(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    if "weekday" in df.columns and "traffic_volume" in df.columns:
        daily = df.groupby("weekday")["traffic_volume"].mean().reindex(range(7), fill_value=0)
        ax.bar(range(7), daily.values, color="#10b981", edgecolor="white", linewidth=0.5)
        ax.set_title("Average Traffic Volume by Day of Week", fontsize=14, fontweight="bold")
        ax.set_xlabel("Day of Week")
        ax.set_ylabel("Avg Traffic Volume (vehicles/hr)")
        ax.set_xticks(range(7))
        ax.set_xticklabels(DAY_NAMES, rotation=30, ha="right")
    else:
        ax.text(0.5, 0.5, "weekday or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def plot_avg_by_month(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    if "month" in df.columns and "traffic_volume" in df.columns:
        monthly = df.groupby("month")["traffic_volume"].mean().reindex(range(1, 13), fill_value=0)
        ax.bar(range(12), monthly.values, color="#f59e0b", edgecolor="white", linewidth=0.5)
        ax.set_title("Average Traffic Volume by Month", fontsize=14, fontweight="bold")
        ax.set_xlabel("Month")
        ax.set_ylabel("Avg Traffic Volume (vehicles/hr)")
        ax.set_xticks(range(12))
        ax.set_xticklabels(MONTH_NAMES)
    else:
        ax.text(0.5, 0.5, "month or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def plot_weekday_vs_weekend(df):
    fig, ax = plt.subplots(figsize=(7, 5))
    if "is_weekend" in df.columns and "traffic_volume" in df.columns:
        weekend = df.groupby("is_weekend")["traffic_volume"].mean()
        labels = ["Weekday", "Weekend"]
        values = [weekend.get(0, 0), weekend.get(1, 0)]
        ax.bar(labels, values, color=["#3b82f6", "#10b981"], edgecolor="white", linewidth=0.5, width=0.5)
        ax.set_title("Weekday vs Weekend Traffic", fontsize=14, fontweight="bold")
        ax.set_ylabel("Avg Traffic Volume (vehicles/hr)")
    else:
        ax.text(0.5, 0.5, "is_weekend or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def plot_traffic_by_weather(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    if "weather_main" in df.columns and "traffic_volume" in df.columns:
        weather_avg = df.groupby("weather_main")["traffic_volume"].mean().sort_values(ascending=False)
        ax.barh(weather_avg.index, weather_avg.values, color="#8b5cf6", edgecolor="white", linewidth=0.5)
        ax.set_title("Average Traffic Volume by Weather Condition", fontsize=14, fontweight="bold")
        ax.set_xlabel("Avg Traffic Volume (vehicles/hr)")
        ax.set_ylabel("Weather")
    else:
        ax.text(0.5, 0.5, "weather_main or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def plot_temp_vs_traffic(df, sample=5000):
    fig, ax = plt.subplots(figsize=(10, 5))
    if "temp" in df.columns and "traffic_volume" in df.columns:
        plot_df = df[["temp", "traffic_volume"]].dropna()
        if len(plot_df) > sample:
            plot_df = plot_df.sample(sample, random_state=42)
        ax.scatter(plot_df["temp"], plot_df["traffic_volume"], alpha=0.2, s=5, color="#3b82f6")
        ax.set_title("Temperature vs Traffic Volume", fontsize=14, fontweight="bold")
        ax.set_xlabel("Temperature (Kelvin)")
        ax.set_ylabel("Traffic Volume (vehicles/hr)")
    else:
        ax.text(0.5, 0.5, "temp or traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def plot_correlation_heatmap(df):
    numeric_df = df.select_dtypes(include=[np.number])
    if len(numeric_df.columns) < 2:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.text(0.5, 0.5, "Not enough numeric columns", ha="center", va="center", transform=ax.transAxes)
        plt.tight_layout()
        return fig, None
    corr = numeric_df.corr()
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0, square=True,
                linewidths=0.5, ax=ax, cbar_kws={"shrink": 0.8})
    ax.set_title("Correlation Heatmap of Numerical Features", fontsize=14, fontweight="bold")
    plt.tight_layout()
    traffic_corr = None
    if "traffic_volume" in corr.columns:
        traffic_corr = corr["traffic_volume"].drop("traffic_volume").sort_values(key=abs, ascending=False)
    return fig, traffic_corr


def get_peak_hours(df, top_n=5):
    if "hour" not in df.columns or "traffic_volume" not in df.columns:
        return None
    hourly = df.groupby("hour")["traffic_volume"].mean().sort_values(ascending=False)
    return hourly.head(top_n)


def plot_traffic_distribution(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    if "traffic_volume" in df.columns:
        ax.hist(df["traffic_volume"].dropna(), bins=40, color="#10b981", edgecolor="white", alpha=0.85)
        ax.set_title("Distribution of Traffic Volume", fontsize=14, fontweight="bold")
        ax.set_xlabel("Traffic Volume (vehicles/hr)")
        ax.set_ylabel("Frequency")
    else:
        ax.text(0.5, 0.5, "traffic_volume not available", ha="center", va="center", transform=ax.transAxes)
    plt.tight_layout()
    return fig


def get_insights(df):
    insights = []
    if "traffic_volume" in df.columns:
        insights.append(f"Average traffic volume: {df['traffic_volume'].mean():.0f} vehicles/hr")
        insights.append(f"Maximum traffic volume: {df['traffic_volume'].max():.0f} vehicles/hr")
        insights.append(f"Minimum traffic volume: {df['traffic_volume'].min():.0f} vehicles/hr")
    if "hour" in df.columns and "traffic_volume" in df.columns:
        hourly = df.groupby("hour")["traffic_volume"].mean()
        peak = hourly.idxmax()
        low = hourly.idxmin()
        insights.append(f"Peak traffic hour: {peak}:00 ({hourly[peak]:.0f} vehicles/hr)")
        insights.append(f"Lowest traffic hour: {low}:00 ({hourly[low]:.0f} vehicles/hr)")
    if "is_weekend" in df.columns and "traffic_volume" in df.columns:
        wd = df[df["is_weekend"] == 0]["traffic_volume"].mean()
        we = df[df["is_weekend"] == 1]["traffic_volume"].mean()
        if not np.isnan(wd) and not np.isnan(we):
            insights.append(f"Weekday avg: {wd:.0f} | Weekend avg: {we:.0f} vehicles/hr")
    if "weather_main" in df.columns and "traffic_volume" in df.columns:
        weather_avg = df.groupby("weather_main")["traffic_volume"].mean()
        best = weather_avg.idxmax()
        worst = weather_avg.idxmin()
        insights.append(f"Highest traffic weather: {best} ({weather_avg[best]:.0f} vehicles/hr)")
        insights.append(f"Lowest traffic weather: {worst} ({weather_avg[worst]:.0f} vehicles/hr)")
    if "is_holiday" in df.columns and "traffic_volume" in df.columns:
        hol = df[df["is_holiday"] == 1]["traffic_volume"].mean()
        non_hol = df[df["is_holiday"] == 0]["traffic_volume"].mean()
        if not np.isnan(hol) and not np.isnan(non_hol):
            insights.append(f"Holiday avg: {hol:.0f} | Non-holiday avg: {non_hol:.0f} vehicles/hr")
    return insights