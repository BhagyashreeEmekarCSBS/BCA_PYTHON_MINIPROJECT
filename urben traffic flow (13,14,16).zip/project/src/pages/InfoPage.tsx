import { BookOpen, Boxes, Workflow, Layers, Cpu, AlertTriangle, Rocket } from 'lucide-react';
import { Badge, PageHeader, Section, Note, Card } from '@/components/ui';

export default function InfoPage() {
  return (
    <div>
      <PageHeader
        icon={<BookOpen className="w-7 h-7" />}
        title="Project Information"
        subtitle="Urban Traffic Flow Optimization — Traffic Analysis and Prediction System. A college mini project implementing data analysis, visualization, and regression-based traffic prediction."
      />

      <div className="space-y-6">
        <Section title="Problem statement">
          <Note>
            Urban traffic congestion causes wasted time, fuel, and pollution. Existing systems report current conditions but rarely predict future volume, so city planners and commuters cannot act ahead of time. This project analyzes historical traffic and weather data to understand what drives congestion and to predict traffic volume from time and weather inputs.
          </Note>
        </Section>

        <Section title="Objectives">
          <ul className="text-sm text-[--text-dim] space-y-1.5 list-disc pl-5">
            <li>Analyze historical traffic data and identify peak congestion periods.</li>
            <li>Study the effect of weather, hour, day, and holidays on traffic volume.</li>
            <li>Perform feature extraction and feature engineering.</li>
            <li>Build and compare regression models (Linear, Decision Tree, Random Forest).</li>
            <li>Predict traffic volume from user-provided inputs.</li>
            <li>Visualize trends and congestion patterns in an interactive dashboard.</li>
          </ul>
        </Section>

        <Section title="Dataset">
          <Note>
            Designed for the Metro Interstate Traffic Volume dataset (hourly traffic on a US interstate). Columns: date_time, traffic_volume, temp (Kelvin), rain_1h, snow_1h, clouds_all, weather_main, holiday. The app accepts any CSV with these (or similarly-named) columns, and includes a synthetic sample dataset that reproduces the same statistical patterns so the full pipeline runs without external downloads.
          </Note>
        </Section>

        <div className="grid lg:grid-cols-2 gap-6">
          <Section title="System architecture" right={<Badge tone="blue"><Boxes className="w-3 h-3 mr-1" />Architecture</Badge>}>
            <div className="flex justify-center"><ArchitectureDiagram /></div>
            <Note className="mt-3">Data flows left-to-right: raw CSV → preprocessing → engineered features → model training → evaluation & prediction. The trained model and encoder are shared across the ML and Prediction pages via app state.</Note>
          </Section>
          <Section title="Project workflow" right={<Badge tone="green"><Workflow className="w-3 h-3 mr-1" />Workflow</Badge>}>
            <div className="flex justify-center"><WorkflowDiagram /></div>
            <Note className="mt-3">The user uploads a dataset (or loads the sample), the system cleans and engineers features, the user trains models, evaluates them, and makes predictions — all in the browser.</Note>
          </Section>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Section title="Technologies used" right={<Badge tone="amber"><Layers className="w-3 h-3 mr-1" />Stack</Badge>}>
            <div className="grid grid-cols-2 gap-3">
              {[
                ['React + TypeScript', 'Interactive UI'],
                ['Tailwind CSS', 'Responsive styling'],
                ['Custom CSV parser', 'Dataset loading'],
                ['Custom SVG charts', 'EDA visualizations'],
                ['Pure-TS regression', 'Linear / Tree / Forest'],
                ['Chronological split', 'Leakage-free eval'],
              ].map(([t, d]) => (
                <div key={t} className="p-3 rounded-lg border border-[--border]">
                  <div className="text-sm font-medium">{t}</div>
                  <div className="text-xs text-[--text-dim] mt-0.5">{d}</div>
                </div>
              ))}
            </div>
            <Note className="mt-3">This project is implemented as a web app (React/TypeScript) rather than Python/Streamlit so it runs directly in the browser with no setup. All analysis and machine learning are real, implemented in TypeScript.</Note>
          </Section>

          <Section title="Methodology" right={<Badge tone="blue"><Cpu className="w-3 h-3 mr-1" />Method</Badge>}>
            <ol className="text-sm text-[--text-dim] space-y-2 list-decimal pl-5">
              <li><b>Load & inspect</b> — parse CSV, infer column types, show preview & stats.</li>
              <li><b>Clean</b> — drop duplicates, impute missing numeric values with column means, fix weather/holiday defaults.</li>
              <li><b>Engineer features</b> — extract hour/day/month/year/weekend from date_time; cyclic (sin/cos) encoding of cyclical fields; one-hot encode weather.</li>
              <li><b>EDA</b> — aggregate by hour, day, month, weather; correlation matrix; scatter plots.</li>
              <li><b>Train</b> — chronological 80/20 split; train Linear, Decision Tree, Random Forest.</li>
              <li><b>Evaluate</b> — MAE, MSE, RMSE, R²; pick best by R².</li>
              <li><b>Predict</b> — encode user input with the same encoder, run the best model, classify congestion.</li>
            </ol>
          </Section>
        </div>

        <Section title="Advantages & limitations">
          <div className="grid sm:grid-cols-2 gap-4">
            <Card>
              <div className="flex items-center gap-2 mb-2 text-[--accent]"><Rocket className="w-4 h-4" /><h4 className="font-semibold">Advantages</h4></div>
              <ul className="text-sm text-[--text-dim] space-y-1.5 list-disc pl-5">
                <li>Runs entirely in-browser — no install or server.</li>
                <li>Real regression models, not faked outputs.</li>
                <li>Handles arbitrary CSV column names via flexible detection.</li>
                <li>Leakage-free chronological evaluation.</li>
              </ul>
            </Card>
            <Card>
              <div className="flex items-center gap-2 mb-2 text-[--accent-warm]"><AlertTriangle className="w-4 h-4" /><h4 className="font-semibold">Limitations</h4></div>
              <ul className="text-sm text-[--text-dim] space-y-1.5 list-disc pl-5">
                <li>Prediction accuracy depends on dataset coverage.</li>
                <li>Models don't capture rare events (accidents, construction) absent from training.</li>
                <li>Sample data is synthetic — use the real Metro dataset for production-grade results.</li>
                <li>Browser execution limits model size vs. Python/scikit-learn.</li>
              </ul>
            </Card>
          </div>
        </Section>

        <Section title="Future scope">
          <ul className="text-sm text-[--text-dim] space-y-1.5 list-disc pl-5">
            <li>Integrate live traffic & weather APIs for real-time prediction.</li>
            <li>Time-series models (ARIMA, gradient boosting) for multi-step forecasting.</li>
            <li>Geospatial map view of congestion hotspots.</li>
            <li>Alerting and route-recommendation features for commuters.</li>
            <li>Export trained models and prediction reports.</li>
          </ul>
        </Section>

        <Section title="Conclusion">
          <Note>
            The system demonstrates the full data-science pipeline — ingestion, cleaning, feature engineering, EDA, modeling, evaluation, and prediction — in a single interactive dashboard. It identifies rush hours and weather effects, compares three regression algorithms, and predicts traffic volume with an interpretable congestion label. The Random Forest model is typically best because it captures non-linear interactions between time and weather.
          </Note>
        </Section>
      </div>
    </div>
  );
}

function ArchitectureDiagram() {
  const boxes = [
    { x: 0, label: 'CSV / Sample', color: '#3b82f6' },
    { x: 150, label: 'Preprocess', color: '#10b981' },
    { x: 300, label: 'Feature Eng.', color: '#10b981' },
    { x: 450, label: 'Train Models', color: '#f59e0b' },
    { x: 600, label: 'Evaluate', color: '#ef4444' },
    { x: 750, label: 'Predict', color: '#3b82f6' },
  ];
  return (
    <svg width={860} height={160} className="overflow-x-auto max-w-full">
      <defs>
        <marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
          <path d="M0,0 L8,4 L0,8 z" fill="#4a5878" />
        </marker>
      </defs>
      {boxes.map((b, i) => (
        <g key={i}>
          <rect x={b.x} y={50} width={100} height={50} rx={10} fill={b.color} opacity={0.18} stroke={b.color} />
          <text x={b.x + 50} y={80} textAnchor="middle" fill="#e6ebf5" fontSize={12}>{b.label}</text>
          {i < boxes.length - 1 && <line x1={b.x + 100} y1={75} x2={b.x + 150} y2={75} stroke="#4a5878" strokeWidth={2} markerEnd="url(#arrow)" />}
        </g>
      ))}
    </svg>
  );
}

function WorkflowDiagram() {
  const steps = [
    { y: 0, label: '1. Upload / Load sample' },
    { y: 36, label: '2. Preprocess & engineer' },
    { y: 72, label: '3. EDA & visualizations' },
    { y: 108, label: '4. Train models' },
    { y: 144, label: '5. Evaluate & select best' },
    { y: 180, label: '6. Predict traffic volume' },
  ];
  return (
    <svg width={340} height={210} className="overflow-x-auto max-w-full">
      <defs>
        <marker id="arrow2" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
          <path d="M0,0 L8,4 L0,8 z" fill="#4a5878" />
        </marker>
      </defs>
      {steps.map((s, i) => (
        <g key={i}>
          <rect x={40} y={s.y} width={260} height={28} rx={8} fill="rgba(59,130,246,0.12)" stroke="#3b82f6" />
          <text x={170} y={s.y + 18} textAnchor="middle" fill="#e6ebf5" fontSize={12}>{s.label}</text>
          {i < steps.length - 1 && <line x1={170} y1={s.y + 28} x2={170} y2={s.y + 36} stroke="#4a5878" strokeWidth={2} markerEnd="url(#arrow2)" />}
        </g>
      ))}
    </svg>
  );
}
