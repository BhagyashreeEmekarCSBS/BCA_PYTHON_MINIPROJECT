import { useMemo, useState } from 'react';
import { Calculator, AlertTriangle, Gauge, CheckCircle2 } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { predict } from '@/lib/models';
import { encodeFeature, FeatureInput } from '@/lib/features';
import { Badge, Button, Card, EmptyState, PageHeader, Section, Note } from '@/components/ui';
import { DAY_NAMES, MONTH_NAMES } from '@/lib/dataset';

export default function PredictionPage() {
  const { engineered, training } = useAppState();
  const now = new Date();
  const [input, setInput] = useState<FeatureInput>({
    hour: now.getHours(),
    day: (now.getDay() + 6) % 7,
    month: now.getMonth(),
    isWeekend: now.getDay() === 0 || now.getDay() === 6 ? 1 : 0,
    isHoliday: 0,
    temp: 288,
    rain: 0,
    snow: 0,
    clouds: 25,
    weatherMain: engineered?.weatherCategories[0] ?? 'Clear',
  });
  const [prediction, setPrediction] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const valid = useMemo(() => validate(input), [input]);

  if (!engineered) return <EmptyState title="No dataset loaded" hint="Load a dataset first; the prediction form needs the model's feature encoder." />;
  if (!training) return <EmptyState title="Models not trained" hint="Go to the Machine Learning page and train the models first." />;

  const handlePredict = () => {
    const v = validate(input);
    if (!v.ok) { setError(v.msg ?? null); setPrediction(null); return; }
    setError(null);
    const x = encodeFeature(training.encoder, input);
    const y = predict(training.best.model, x);
    setPrediction(Math.max(0, Math.round(y)));
  };

  const congestion = prediction !== null ? classify(prediction, engineered) : null;

  const update = (patch: Partial<FeatureInput>) => setInput((p) => ({ ...p, ...patch }));

  return (
    <div>
      <PageHeader
        icon={<Calculator className="w-7 h-7" />}
        title="Traffic Volume Prediction"
        subtitle="Enter the time, weather, and holiday conditions you expect. The trained model returns the predicted traffic volume and a congestion level."
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Section title="Input form">
            <div className="grid sm:grid-cols-2 gap-5">
              <Field label="Date">
                <input type="date" className={inputCls} value={toDateString(input)}
                  onChange={(e) => {
                    const d = new Date(e.target.value + 'T00:00:00');
                    if (!isNaN(d.getTime())) update({ day: (d.getDay() + 6) % 7, month: d.getMonth(), isWeekend: d.getDay() === 0 || d.getDay() === 6 ? 1 : 0 });
                  }}
                />
              </Field>
              <Field label="Hour (0–23)">
                <input type="number" min={0} max={23} className={inputCls} value={input.hour}
                  onChange={(e) => update({ hour: clampInt(e.target.value, 0, 23) })} />
              </Field>
              <Field label="Day of week">
                <select className={inputCls} value={input.day} onChange={(e) => update({ day: +e.target.value, isWeekend: +e.target.value >= 5 ? 1 : 0 })}>
                  {DAY_NAMES.map((d, i) => <option key={i} value={i}>{d}</option>)}
                </select>
              </Field>
              <Field label="Month">
                <select className={inputCls} value={input.month} onChange={(e) => update({ month: +e.target.value })}>
                  {MONTH_NAMES.map((m, i) => <option key={i} value={i}>{m}</option>)}
                </select>
              </Field>
              <Field label="Holiday">
                <select className={inputCls} value={input.isHoliday} onChange={(e) => update({ isHoliday: +e.target.value })}>
                  <option value={0}>None</option>
                  <option value={1}>Holiday</option>
                </select>
              </Field>
              <Field label="Weekend">
                <select className={inputCls} value={input.isWeekend} onChange={(e) => update({ isWeekend: +e.target.value })}>
                  <option value={0}>Weekday</option>
                  <option value={1}>Weekend</option>
                </select>
              </Field>
              <Field label="Temperature (K)">
                <input type="number" step="0.1" className={inputCls} value={input.temp}
                  onChange={(e) => update({ temp: parseFloat(e.target.value) || 0 })} />
              </Field>
              <Field label="Cloud cover (%)">
                <input type="number" min={0} max={100} className={inputCls} value={input.clouds}
                  onChange={(e) => update({ clouds: clampInt(e.target.value, 0, 100) })} />
              </Field>
              <Field label="Rain (mm/h)">
                <input type="number" min={0} step="0.1" className={inputCls} value={input.rain}
                  onChange={(e) => update({ rain: Math.max(0, parseFloat(e.target.value) || 0) })} />
              </Field>
              <Field label="Snow (mm/h)">
                <input type="number" min={0} step="0.01" className={inputCls} value={input.snow}
                  onChange={(e) => update({ snow: Math.max(0, parseFloat(e.target.value) || 0) })} />
              </Field>
              <Field label="Weather condition" full>
                <select className={inputCls} value={input.weatherMain} onChange={(e) => update({ weatherMain: e.target.value })}>
                  {training.encoder.weatherCategories.map((w) => <option key={w} value={w}>{w}</option>)}
                </select>
              </Field>
            </div>

            {error && <div className="mt-4 flex items-center gap-2 text-red-300 text-sm"><AlertTriangle className="w-4 h-4" />{error}</div>}
            <div className="mt-5">
              <Button onClick={handlePredict} disabled={!valid.ok}><Calculator className="w-4 h-4" /> Predict traffic volume</Button>
            </div>
          </Section>
        </div>

        <div className="space-y-6">
          <Card>
            <div className="flex items-center gap-2 mb-3"><Gauge className="w-5 h-5 text-[--primary]" /><h3 className="font-semibold">Prediction</h3></div>
            {prediction === null ? (
              <Note>Run the prediction to see the result.</Note>
            ) : (
              <div className="fade-in">
                <div className="text-4xl font-bold metric-num">{prediction.toLocaleString()}</div>
                <div className="text-[--text-dim] text-sm mt-1">vehicles per hour (predicted)</div>
                <div className="mt-4">
                  {congestion?.tone === 'green' && <Badge tone="green"><CheckCircle2 className="w-3 h-3 mr-1" />{congestion.label}</Badge>}
                  {congestion?.tone === 'amber' && <Badge tone="amber">{congestion.label}</Badge>}
                  {congestion?.tone === 'red' && <Badge tone="red"><AlertTriangle className="w-3 h-3 mr-1" />{congestion.label}</Badge>}
                </div>
                <div className="text-xs text-[--text-dim] mt-3">{congestion?.explanation}</div>
              </div>
            )}
          </Card>

          <Card>
            <h3 className="font-semibold mb-2">Model used</h3>
            <div className="text-sm">{training.best.name}</div>
            <div className="text-xs text-[--text-dim] mt-1">R² = {training.best.metrics.r2.toFixed(3)} · RMSE = {Math.round(training.best.metrics.rmse).toLocaleString()}</div>
            <Note className="mt-3">
              Predictions are estimates based on patterns in the loaded dataset. Accuracy depends on data coverage and quality. Values are floored at 0 vehicles/hour.
            </Note>
          </Card>
        </div>
      </div>
    </div>
  );
}

const inputCls = "w-full bg-[--panel-2] border border-[--border] rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[--primary] transition";

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? 'sm:col-span-2' : ''}>
      <label className="block text-xs text-[--text-dim] mb-1.5 uppercase tracking-wider">{label}</label>
      {children}
    </div>
  );
}

function clampInt(v: string, min: number, max: number): number {
  const n = parseInt(v, 10);
  if (isNaN(n)) return min;
  return Math.max(min, Math.min(max, n));
}

function validate(input: FeatureInput): { ok: boolean; msg?: string } {
  if (input.hour < 0 || input.hour > 23) return { ok: false, msg: 'Hour must be between 0 and 23.' };
  if (input.clouds < 0 || input.clouds > 100) return { ok: false, msg: 'Cloud cover must be 0–100%.' };
  if (input.rain < 0 || input.snow < 0) return { ok: false, msg: 'Rain and snow must be non-negative.' };
  if (isNaN(input.temp)) return { ok: false, msg: 'Temperature must be a number (Kelvin).' };
  return { ok: true };
}

function classify(pred: number, eng: { trafficMean: number; trafficStd: number }): { label: string; tone: 'green' | 'amber' | 'red'; explanation: string } {
  const low = eng.trafficMean - 0.5 * eng.trafficStd;
  const high = eng.trafficMean + 0.5 * eng.trafficStd;
  if (pred < low) return { label: 'Low traffic', tone: 'green', explanation: `Below average (avg ≈ ${Math.round(eng.trafficMean)}). Expect smooth flow.` };
  if (pred > high) return { label: 'High traffic', tone: 'red', explanation: `Well above average (avg ≈ ${Math.round(eng.trafficMean)}). Expect congestion.` };
  return { label: 'Moderate traffic', tone: 'amber', explanation: 'Close to the dataset average; typical conditions expected.' };
}

function toDateString(input: FeatureInput): string {
  const year = new Date().getFullYear();
  for (let day = 1; day <= 28; day++) {
    const d = new Date(year, input.month, day);
    if ((d.getDay() + 6) % 7 === input.day) {
      return `${year}-${String(input.month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
  }
  return `${year}-${String(input.month + 1).padStart(2, '0')}-01`;
}
