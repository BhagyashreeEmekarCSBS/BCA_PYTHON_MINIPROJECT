import { useRef, useState } from 'react';
import { FileUp, Table2, Download, Sparkles, AlertCircle } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { parseCsv, downloadFile } from '@/lib/csv';
import { generateSampleData } from '@/lib/sampleData';
import { Badge, Button, Card, EmptyState, PageHeader, Section, Table, Note } from '@/components/ui';

export default function DataExplorerPage() {
  const { dataset, engineered, preprocessReport, loadRaw } = useAppState();
  const fileRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  const onFile = async (file: File) => {
    setBusy(true); setError(null);
    try {
      const text = await file.text();
      const { headers, rows, errors } = parseCsv(text);
      if (errors.length && rows.length === 0) { setError(errors.join(' ')); return; }
      if (rows.length === 0) { setError('No data rows found.'); return; }
      setFileName(file.name);
      loadRaw(headers, rows);
    } catch {
      setError('Could not parse the file. Make sure it is a valid CSV.');
    } finally {
      setBusy(false);
    }
  };

  const loadSample = () => {
    setBusy(true); setError(null);
    setTimeout(() => {
      const { headers, rows } = generateSampleData({ hours: 6000, seed: 7 });
      setFileName('sample_metro_traffic.csv (synthetic)');
      loadRaw(headers, rows);
      setBusy(false);
    }, 50);
  };

  const downloadSample = () => {
    const { headers, rows } = generateSampleData({ hours: 3000, seed: 11 });
    const csv = [headers.join(','), ...rows.map((r) => r.map(escapeCsv).join(','))].join('\n');
    downloadFile('sample_metro_traffic.csv', csv, 'text/csv');
  };

  const previewRows = dataset ? dataset.rawRows.slice(0, 8) : [];

  return (
    <div>
      <PageHeader
        icon={<Table2 className="w-7 h-7" />}
        title="Dataset Explorer"
        subtitle="Upload a CSV in the Metro Interstate Traffic Volume format, or load bundled synthetic sample data. Expected columns: date_time, traffic_volume, temp, rain_1h, snow_1h, clouds_all, weather_main, holiday."
      />

      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <Card>
          <div className="flex items-center gap-2 mb-3"><FileUp className="w-5 h-5 text-[--primary]" /><h3 className="font-semibold">Upload CSV</h3></div>
          <input ref={fileRef} type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }} />
          <Button onClick={() => fileRef.current?.click()} disabled={busy} className="w-full">{busy ? 'Loading…' : 'Choose CSV file'}</Button>
          {error && <div className="mt-3 flex items-start gap-2 text-red-300 text-sm"><AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{error}</div>}
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><Sparkles className="w-5 h-5 text-[--accent]" /><h3 className="font-semibold">Sample data</h3></div>
          <p className="text-sm text-[--text-dim] mb-3">Synthetic hourly records with realistic diurnal, weekday, seasonal & weather signal (~6,000 rows).</p>
          <Button variant="outline" onClick={loadSample} disabled={busy} className="w-full">Load sample dataset</Button>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><Download className="w-5 h-5 text-[--accent-warm]" /><h3 className="font-semibold">Download sample</h3></div>
          <p className="text-sm text-[--text-dim] mb-3">Get a starter CSV to inspect the expected format before using your own data.</p>
          <Button variant="ghost" onClick={downloadSample} className="w-full">Download sample CSV</Button>
        </Card>
      </div>

      {fileName && <div className="mb-4"><Badge tone="green">Loaded: {fileName}</Badge></div>}

      {!dataset ? (
        <EmptyState title="No dataset loaded" hint="Upload a CSV or load the sample data to begin." />
      ) : (
        <div className="space-y-6 fade-in">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatBox label="Rows (clean)" value={preprocessReport?.totalRows.toLocaleString() ?? '—'} />
            <StatBox label="Columns" value={String(dataset.headers.length)} />
            <StatBox label="Duplicates removed" value={String(preprocessReport?.removedDuplicates ?? 0)} />
            <StatBox label="Missing imputed" value={String(preprocessReport?.handledMissing ?? 0)} />
          </div>

          {preprocessReport?.notes?.length ? (
            <Section title="Preprocessing notes">
              <ul className="text-sm text-[--text-dim] space-y-1">
                {preprocessReport.notes.map((n, i) => <li key={i} className="flex gap-2"><AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-[--accent-warm]" />{n}</li>)}
              </ul>
            </Section>
          ) : null}

          <Section title="Column information">
            <Table
              headers={['Column', 'Type', 'Missing', 'Unique', 'Stats']}
              rows={dataset.columns.map((c) => [
                c.name,
                <Badge tone={c.type === 'numeric' ? 'blue' : c.type === 'datetime' ? 'amber' : 'gray'}>{c.type}</Badge>,
                String(c.missingCount),
                String(c.uniqueCount),
                <span className="text-[--text-dim] text-xs">
                  {c.type === 'numeric' ? `min ${fmtNum(c.min)}, max ${fmtNum(c.max)}, mean ${fmtNum(c.mean)}` : ''}
                  {c.type === 'datetime' ? `${fmtDate(c.minDate)} → ${fmtDate(c.maxDate)}` : ''}
                  {c.type === 'categorical' ? (c.topCategories?.slice(0, 3).map((t) => t.value).join(', ') ?? '') : ''}
                </span>,
              ])}
            />
          </Section>

          <Section title="Data preview (first 8 rows)">
            <Table
              headers={dataset.headers}
              rows={previewRows.map((r) => r.map((c, i) => <span key={i} className="text-xs text-[--text-dim]">{c}</span>))}
            />
          </Section>

          <Section title="Descriptive statistics (numeric columns)">
            <Table
              headers={['Column', 'Count', 'Mean', 'Std', 'Min', 'Max']}
              rows={dataset.columns.filter((c) => c.type === 'numeric').map((c) => [
                c.name, String(c.uniqueCount), fmtNum(c.mean), fmtNum(c.std), fmtNum(c.min), fmtNum(c.max),
              ])}
            />
            {dataset.columns.filter((c) => c.type === 'numeric').length === 0 && <Note>No numeric columns detected.</Note>}
          </Section>
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return <div className="card p-4"><div className="text-[--text-dim] text-xs uppercase tracking-wider">{label}</div><div className="text-xl font-semibold metric-num mt-1">{value}</div></div>;
}
function fmtNum(n?: number) { return n === undefined ? '—' : Math.abs(n) >= 1000 ? n.toLocaleString(undefined, { maximumFractionDigits: 0 }) : n.toFixed(2); }
function fmtDate(d?: string) { return d ? new Date(d).toISOString().slice(0, 10) : '—'; }
function escapeCsv(v: string) { return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v; }
