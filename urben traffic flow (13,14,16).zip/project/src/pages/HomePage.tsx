import { useMemo } from 'react';
import { BarChart3, Database, GitBranch, Layers, Sparkles } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { Badge, Button, Card, EmptyState, PageHeader, Stat } from '@/components/ui';
import { Page } from '@/App';

export default function HomePage({ go }: { go: (p: Page) => void }) {
  const { dataset, engineered, preprocessReport, training } = useAppState();

  const stats = useMemo(() => {
    if (!engineered) return null;
    const rows = engineered.rows.filter((r) => r.trafficVolume !== null);
    const total = rows.length;
    const avg = total ? rows.reduce((a, r) => a + (r.trafficVolume as number), 0) / total : 0;
    const years = new Set(rows.map((r) => r.year));
    return { total, avg, years: years.size, weatherTypes: engineered.weatherCategories.length };
  }, [engineered]);

  return (
    <div>
      <PageHeader
        icon={<Sparkles className="w-7 h-7" />}
        title="Urban Traffic Flow Optimization"
        subtitle="Traffic analysis and prediction system — load a dataset, explore congestion patterns, train regression models, and predict traffic volume from weather and time inputs."
      />

      {!dataset ? (
        <EmptyState
          title="No dataset loaded yet"
          hint="Upload your own CSV in the Dataset Explorer, or load the bundled synthetic sample data based on the Metro Interstate Traffic Volume schema."
          action={
            <div className="flex gap-3 justify-center">
              <Button onClick={() => go('data')}>Go to Dataset Explorer</Button>
              <Button variant="outline" onClick={() => go('info')}>Learn about the project</Button>
            </div>
          }
        />
      ) : (
        <div className="space-y-6 fade-in">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Stat label="Total Records" value={stats?.total.toLocaleString() ?? '—'} accent="text-[--primary]" />
            <Stat label="Avg Traffic / hr" value={stats ? Math.round(stats.avg).toLocaleString() : '—'} accent="text-[--accent]" sub="vehicles per hour" />
            <Stat label="Weather Types" value={stats?.weatherTypes ?? '—'} />
            <Stat label="Years Covered" value={stats?.years ?? '—'} />
          </div>

          <div className="grid lg:grid-cols-3 gap-4">
            <Card>
              <div className="flex items-center gap-2 mb-3 text-[--primary]"><Database className="w-5 h-5" /><h3 className="font-semibold">1. Dataset</h3></div>
              <p className="text-sm text-[--text-dim] mb-4">{preprocessReport?.totalRows.toLocaleString()} rows after cleaning. {preprocessReport?.removedDuplicates} duplicates removed, {preprocessReport?.handledMissing} missing values imputed.</p>
              <Button variant="outline" onClick={() => go('data')}>Explore dataset →</Button>
            </Card>
            <Card>
              <div className="flex items-center gap-2 mb-3 text-[--accent]"><BarChart3 className="w-5 h-5" /><h3 className="font-semibold">2. Analysis</h3></div>
              <p className="text-sm text-[--text-dim] mb-4">Visualize traffic trends, peak hours, day/month patterns, and weather impact on congestion.</p>
              <Button variant="outline" onClick={() => go('analysis')}>View analysis →</Button>
            </Card>
            <Card>
              <div className="flex items-center gap-2 mb-3 text-[--accent-warm]" ><GitBranch className="w-5 h-5" /><h3 className="font-semibold">3. Machine Learning</h3></div>
              <p className="text-sm text-[--text-dim] mb-4">
                {training ? `Trained 3 models. Best: ${training.best.name} (R² = ${training.best.metrics.r2.toFixed(3)}).` : 'Train Linear, Decision Tree, and Random Forest regressors and compare.'}
              </p>
              <Button variant="outline" onClick={() => go('ml')}>{training ? 'View results →' : 'Train models →'}</Button>
            </Card>
          </div>

          <Card>
            <div className="flex items-center gap-2 mb-4"><Layers className="w-5 h-5 text-[--primary]" /><h3 className="font-semibold">Navigate the dashboard</h3></div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {([
                ['Home', 'Overview & stats', 'home', 'blue'],
                ['Dataset Explorer', 'Upload & inspect CSV', 'data', 'gray'],
                ['Traffic Analysis', 'Trends & peak hours', 'analysis', 'green'],
                ['Correlation', 'Feature relationships', 'correlation', 'amber'],
                ['Machine Learning', 'Train & compare models', 'ml', 'red'],
                ['Prediction', 'Predict traffic volume', 'prediction', 'blue'],
                ['Project Info', 'Docs & methodology', 'info', 'gray'],
              ] as const).map(([label, desc, key, tone]) => (
                <button key={key} onClick={() => go(key)} className="text-left p-3 rounded-lg border border-[--border] hover:border-[--primary] transition group">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{label}</span>
                    <Badge tone={tone as 'blue' | 'green' | 'amber' | 'red' | 'gray'}>open</Badge>
                  </div>
                  <div className="text-xs text-[--text-dim] mt-1">{desc}</div>
                </button>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
