import { useMemo } from 'react';
import { GitBranch, Cpu, Trophy, Activity, BarChart3 } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { Badge, Button, Card, EmptyState, PageHeader, Section, Table, Note, Spinner } from '@/components/ui';
import { BarChart, ScatterChart } from '@/components/charts';

export default function MLPage() {
  const { engineered, training, isTraining, train } = useAppState();

  const predVsActual = useMemo(() => {
    if (!training) return [];
    return training.yTest.map((y, i) => ({ x: y, y: training.predictions[training.best.name][i] }));
  }, [training]);

  const importanceBars = useMemo(() => {
    if (!training) return [];
    return training.importances
      .filter((d) => d.importance > 0.001)
      .sort((a, b) => b.importance - a.importance)
      .slice(0, 12)
      .map((d) => ({ label: d.name, value: d.importance * 100 }));
  }, [training]);

  if (!engineered) return <EmptyState title="No dataset loaded" hint="Load a dataset to train models." />;

  return (
    <div>
      <PageHeader
        icon={<Cpu className="w-7 h-7" />}
        title="Machine Learning"
        subtitle="Train Linear Regression, Decision Tree, and Random Forest regressors on a chronological 80/20 split (no data leakage). Compare MAE, MSE, RMSE, and R², then use the best model for prediction."
      />

      <Card className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="font-semibold mb-1">Train models</div>
          <Note>
            Training runs entirely in your browser. The Random Forest uses 25 trees and capped depth to keep it fast. Features include cyclic-encoded hour/day/month, weather one-hot, and numeric weather fields.
          </Note>
        </div>
        <div className="flex items-center gap-3">
          {isTraining && <Spinner label="Training…" />}
          <Button onClick={() => train()} disabled={isTraining}>
            <GitBranch className="w-4 h-4" /> {training ? 'Retrain models' : 'Train models'}
          </Button>
        </div>
      </Card>

      {!training && !isTraining && (
        <EmptyState title="Models not trained yet" hint="Click 'Train models' to train and evaluate all three regressors." />
      )}

      {training && (
        <div className="space-y-6 fade-in">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Stat label="Train size" value={training.trainSize.toLocaleString()} />
            <Stat label="Test size" value={training.testSize.toLocaleString()} />
            <Stat label="Best model" value={training.best.name} accent="text-[--accent]" />
            <Stat label="Best R²" value={training.best.metrics.r2.toFixed(3)} accent="text-[--accent]" />
          </div>

          <Section title="Model comparison" right={<Badge tone="green"><Trophy className="w-3 h-3 mr-1" />Best: {training.best.name}</Badge>}>
            <Table
              headers={['Model', 'MAE', 'MSE', 'RMSE', 'R²', 'Train time', '']}
              rows={training.models.map((m) => [
                m.name, fmt(m.metrics.mae), fmt(m.metrics.mse), fmt(m.metrics.rmse), fmt(m.metrics.r2),
                `${m.trainMs.toFixed(0)} ms`,
                m.name === training.best.name ? <Badge tone="green">selected</Badge> : <Badge tone="gray">—</Badge>,
              ])}
            />
            <Note className="mt-3">
              {training.best.name === 'Random Forest'
                ? 'Random Forest is selected — it captures non-linear interactions between hour, weather, and day type without overfitting, yielding the best generalization.'
                : training.best.name === 'Decision Tree'
                ? 'The Decision Tree edges out the others here, but watch for overfitting on smaller datasets — Random Forest is usually more robust.'
                : 'Linear Regression performs best here, suggesting a mostly linear relationship in this dataset.'}
            </Note>
          </Section>

          <div className="grid lg:grid-cols-2 gap-6">
            <Section title="Predicted vs actual (test set)" right={<Badge tone="blue"><Activity className="w-3 h-3 mr-1" />{training.best.name}</Badge>}>
              <ScatterChart points={predVsActual} xLabel="Actual volume" yLabel="Predicted volume" height={300} color="#10b981" alpha={0.35} />
              <Note className="mt-2">Points along the diagonal y=x line indicate accurate predictions. Spread away from the line is error.</Note>
            </Section>

            <Section title="Feature importance" right={<Badge tone="amber"><BarChart3 className="w-3 h-3 mr-1" />Random Forest</Badge>}>
              {importanceBars.length > 0 ? (
                <BarChart data={importanceBars} xLabel="" yLabel="Importance (%)" height={300} color="#f59e0b" valueFmt={(n) => n.toFixed(1)} />
              ) : (
                <Note>Feature importance is available when the Random Forest is the selected model.</Note>
              )}
            </Section>
          </div>

          <Section title="Why this model?">
            <ul className="text-sm text-[--text-dim] space-y-2 list-disc pl-5">
              <li>The best model is chosen by highest R² (explained variance), tie-broken by lowest RMSE.</li>
              <li>Random Forest aggregates many decorrelated trees, reducing variance versus a single Decision Tree.</li>
              <li>It captures non-linear effects (e.g. the bimodal rush-hour curve) that Linear Regression cannot.</li>
              <li>Predictions are bounded by training-set leaf values, so the model won't extrapolate wildly outside observed patterns.</li>
              <li>All training uses a chronological split — earlier data trains, later data tests — preventing look-ahead leakage.</li>
            </ul>
          </Section>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return <div className="card p-4"><div className="text-[--text-dim] text-xs uppercase tracking-wider">{label}</div><div className={`text-lg font-semibold metric-num mt-1 ${accent ?? ''}`}>{value}</div></div>;
}
function fmt(n: number) { return Math.abs(n) >= 1000 ? n.toLocaleString(undefined, { maximumFractionDigits: 0 }) : n.toFixed(3); }
