import { useMemo } from 'react';
import { GitCompare } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { Badge, EmptyState, PageHeader, Section, Note } from '@/components/ui';
import { Heatmap } from '@/components/charts';
import { correlationMatrix } from '@/lib/eda';

export default function CorrelationPage() {
  const { engineered } = useAppState();
  const corr = useMemo(() => (engineered ? correlationMatrix(engineered) : null), [engineered]);

  if (!corr) return <EmptyState title="No dataset loaded" hint="Load a dataset to compute the correlation heatmap." />;

  const cells: { r: number; c: number; v: number }[] = [];
  for (let i = 0; i < corr.labels.length; i++)
    for (let j = 0; j < corr.labels.length; j++)
      cells.push({ r: i, c: j, v: corr.values[i][j] });

  const trafficIdx = corr.labels.indexOf('Traffic');
  const withTraffic = corr.labels
    .map((label, i) => ({ label, value: corr.values[trafficIdx][i] }))
    .filter((d) => d.label !== 'Traffic')
    .sort((a, b) => Math.abs(b.value) - Math.abs(a.value));

  return (
    <div>
      <PageHeader
        icon={<GitCompare className="w-7 h-7" />}
        title="Correlation Analysis"
        subtitle="Pearson correlation between numeric features and traffic volume. Values near ±1 indicate a strong linear relationship; near 0 indicates none."
      />

      <Section title="Correlation heatmap" right={<Badge tone="amber">Pearson r</Badge>}>
        <div className="flex justify-center">
          <Heatmap rows={corr.labels} cols={corr.labels} values={cells} width={620} height={460} title="" />
        </div>
        <Note className="mt-3">Red cells indicate positive correlation, blue cells negative. The diagonal is always 1.0 (self-correlation).</Note>
      </Section>

      <div className="grid lg:grid-cols-2 gap-6 mt-6">
        <Section title="Correlation with traffic volume">
          <div className="space-y-3">
            {withTraffic.map((d) => {
              const abs = Math.abs(d.value);
              const tone = abs > 0.4 ? 'amber' : 'gray';
              const dir = d.value > 0 ? '+' : '';
              return (
                <div key={d.label} className="flex items-center gap-3">
                  <div className="w-24 text-sm">{d.label}</div>
                  <div className="flex-1 h-2 bg-[--panel-2] rounded-full overflow-hidden relative">
                    <div className="absolute top-0 h-full" style={{ left: d.value >= 0 ? '50%' : `${50 + d.value * 50}%`, width: `${Math.abs(d.value) * 50}%`, background: d.value >= 0 ? '#ef4444' : '#3b82f6' }} />
                    <div className="absolute top-0 left-1/2 w-px h-full bg-white/30" />
                  </div>
                  <Badge tone={tone}>{dir}{d.value.toFixed(3)}</Badge>
                </div>
              );
            })}
          </div>
        </Section>

        <Section title="Insights">
          <ul className="text-sm text-[--text-dim] space-y-2 list-disc pl-5">
            <li>Hour of day has the strongest correlation with traffic volume — rush hours dominate the signal.</li>
            <li>Weekend indicator is typically negatively correlated (weekends have less traffic).</li>
            <li>Holiday is negatively correlated — holidays reduce traffic substantially.</li>
            <li>Rain and snow show weak-to-moderate negative correlation — adverse weather suppresses volume.</li>
            <li>Temperature shows a weak relationship, mostly through seasonality.</li>
            <li>Cloud cover correlates weakly; it mostly co-varies with weather types.</li>
          </ul>
          <Note className="mt-3">Correlation measures only linear relationships. Tree-based models can capture non-linear effects that this matrix hides.</Note>
        </Section>
      </div>
    </div>
  );
}
