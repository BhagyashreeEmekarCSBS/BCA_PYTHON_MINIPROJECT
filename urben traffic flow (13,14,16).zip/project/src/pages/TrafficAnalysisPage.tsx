import { useMemo } from 'react';
import { BarChart3, TrendingUp, Clock, CloudRain, Calendar } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { Badge, EmptyState, PageHeader, Section, Note } from '@/components/ui';
import { LineChart, BarChart, ScatterChart } from '@/components/charts';
import { avgByHour, avgByDayOfWeek, avgByMonth, weekdayVsWeekend, avgByWeather, tempVsTraffic, hourlyTrend } from '@/lib/eda';

export default function TrafficAnalysisPage() {
  const { engineered } = useAppState();

  const data = useMemo(() => {
    if (!engineered) return null;
    const hourly = avgByHour(engineered);
    const peakHour = hourly.indexOf(Math.max(...hourly));
    return {
      hourly, peakHour,
      byDay: avgByDayOfWeek(engineered),
      byMonth: avgByMonth(engineered),
      weekdayWeekend: weekdayVsWeekend(engineered),
      byWeather: avgByWeather(engineered),
      tempScatter: tempVsTraffic(engineered, 1500),
      trend: hourlyTrend(engineered, 800),
    };
  }, [engineered]);

  if (!data) return <EmptyState title="No dataset loaded" hint="Load a dataset in the Dataset Explorer to see traffic analysis." />;

  return (
    <div>
      <PageHeader
        icon={<BarChart3 className="w-7 h-7" />}
        title="Traffic Analysis"
        subtitle="Explore how traffic volume varies across hours, days, months, weekends, and weather conditions — and identify peak congestion periods."
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Stat label="Peak hour" value={`${data.peakHour}:00`} accent="text-[--danger]" />
        <Stat label="Peak volume" value={Math.round(data.hourly[data.peakHour]).toLocaleString()} sub="vehicles / hr at peak" />
        <Stat label="Weekday avg" value={Math.round(data.weekdayWeekend[0].value).toLocaleString()} accent="text-[--primary]" />
        <Stat label="Weekend avg" value={Math.round(data.weekdayWeekend[1].value).toLocaleString()} accent="text-[--accent]" />
      </div>

      <Section title="Traffic volume over time" right={<Badge tone="blue"><TrendingUp className="w-3 h-3 mr-1" />Trend</Badge>}>
        <LineChart
          series={[{ name: 'Traffic volume', color: '#3b82f6', points: data.trend }]}
          xLabel="Time" yLabel="Vehicles / hour" height={300}
          xTicks={makeTimeTicks(data.trend)}
        />
        <Note className="mt-3">Hourly traffic volume over the full dataset period. Spikes correspond to rush hours; dips to nighttime.</Note>
      </Section>

      <div className="grid lg:grid-cols-2 gap-6 mt-6">
        <Section title="Average traffic by hour of day" right={<Badge tone="amber"><Clock className="w-3 h-3 mr-1" />Diurnal</Badge>}>
          <BarChart
            data={data.hourly.map((v, i) => ({ label: `${i}`, value: v, color: i === data.peakHour ? '#ef4444' : '#3b82f6' }))}
            xLabel="Hour" yLabel="Avg vehicles / hr" height={280}
            valueFmt={(n) => Math.round(n).toString()}
          />
          <Note className="mt-2">The red bar marks the peak hour ({data.peakHour}:00). Traffic shows a bimodal rush-hour pattern.</Note>
        </Section>

        <Section title="Average traffic by day of week">
          <BarChart data={data.byDay} xLabel="Day of week" yLabel="Avg vehicles / hr" height={280} valueFmt={(n) => Math.round(n).toString()} />
          <Note className="mt-2">Weekdays typically carry more traffic than weekends; Saturday/Sunday show lower volumes.</Note>
        </Section>

        <Section title="Average traffic by month" right={<Badge tone="green"><Calendar className="w-3 h-3 mr-1" />Seasonal</Badge>}>
          <BarChart data={data.byMonth} xLabel="Month" yLabel="Avg vehicles / hr" height={280} valueFmt={(n) => Math.round(n).toString()} />
          <Note className="mt-2">Monthly averages reveal seasonal travel patterns.</Note>
        </Section>

        <Section title="Weekday vs weekend">
          <BarChart data={data.weekdayWeekend} xLabel="" yLabel="Avg vehicles / hr" height={280} valueFmt={(n) => Math.round(n).toString()} />
          <Note className="mt-2">Weekday commuting drives higher average volumes than weekend leisure travel.</Note>
        </Section>

        <Section title="Traffic under weather conditions" right={<Badge tone="blue"><CloudRain className="w-3 h-3 mr-1" />Weather</Badge>}>
          <BarChart
            data={data.byWeather.map((w) => ({ label: w.label, value: w.value, color: w.value < data.hourly[data.peakHour] * 0.7 ? '#f59e0b' : '#10b981' }))}
            xLabel="Weather" yLabel="Avg vehicles / hr" height={280} valueFmt={(n) => Math.round(n).toString()}
          />
          <Note className="mt-2">Adverse weather (rain, snow, thunderstorm) tends to reduce traffic volume compared to clear conditions.</Note>
        </Section>

        <Section title="Temperature vs traffic volume">
          <ScatterChart points={data.tempScatter} xLabel="Temperature (K)" yLabel="Traffic volume" height={280} alpha={0.3} />
          <Note className="mt-2">Each point is one hourly record. Extreme temperatures modestly reduce volume.</Note>
        </Section>
      </div>
    </div>
  );
}

function Stat({ label, value, sub, accent }: { label: string; value: string; sub?: string; accent?: string }) {
  return <div className="card p-4"><div className="text-[--text-dim] text-xs uppercase tracking-wider">{label}</div><div className={`text-xl font-semibold metric-num mt-1 ${accent ?? ''}`}>{value}</div>{sub && <div className="text-[--text-dim] text-xs mt-1">{sub}</div>}</div>;
}

function makeTimeTicks(points: { x: number; y: number }[]): { value: number; label: string }[] {
  if (points.length === 0) return [];
  const min = points[0].x, max = points[points.length - 1].x;
  const span = max - min || 1;
  const ticks: { value: number; label: string }[] = [];
  const count = 6;
  for (let i = 0; i <= count; i++) {
    const v = min + (span * i) / count;
    ticks.push({ value: v, label: new Date(v).toISOString().slice(0, 10) });
  }
  return ticks;
}
