"""
app.py

Urban Traffic Flow Optimization - Traffic Analysis and Prediction System
A Streamlit web application for traffic analysis and prediction.

Run with: streamlit run app.py
"""

import os
import sys
import streamlit as st

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

import pandas as pd
import numpy as np

from data_preprocessing import (
    load_dataset, generate_sample_data, preprocess_data,
    get_dataset_summary, get_feature_columns,
)
from eda import (
    plot_traffic_over_time, plot_avg_by_hour, plot_avg_by_day, plot_avg_by_month,
    plot_weekday_vs_weekend, plot_traffic_by_weather, plot_temp_vs_traffic,
    plot_correlation_heatmap, plot_traffic_distribution, get_peak_hours, get_insights,
)
from model_training import train_and_evaluate, save_model, load_model, model_exists
from prediction import make_prediction_input, predict_traffic, validate_input

# ----------------------------------------------------------------------------
st.set_page_config(
    page_title="Urban Traffic Flow Optimization",
    page_icon="🚦",
    layout="wide",
    initial_sidebar_state="expanded",
)

if "df" not in st.session_state:
    st.session_state.df = None
if "df_clean" not in st.session_state:
    st.session_state.df_clean = None
if "preprocess_report" not in st.session_state:
    st.session_state.preprocess_report = None
if "training_results" not in st.session_state:
    st.session_state.training_results = None
if "dataset_name" not in st.session_state:
    st.session_state.dataset_name = None

st.sidebar.title("🚦 Traffic Flow Optimization")
st.sidebar.markdown("---")
page = st.sidebar.radio(
    "Navigation",
    ["🏠 Home", "📂 Dataset Explorer", "📊 Traffic Analysis", "🔗 Correlation Analysis",
     "🤖 Machine Learning", "🔮 Traffic Prediction", "📖 Project Info"],
    index=0,
)
st.sidebar.markdown("---")
st.sidebar.caption("College Mini Project\nPython · Streamlit · Scikit-learn")


def load_data_into_session(df, name="Uploaded CSV"):
    with st.spinner("Preprocessing data..."):
        df_clean, report = preprocess_data(df)
        st.session_state.df = df
        st.session_state.df_clean = df_clean
        st.session_state.preprocess_report = report
        st.session_state.dataset_name = name
        st.session_state.training_results = None


# ----------------------------------------------------------------------------
def home_page():
    st.title("🚦 Urban Traffic Flow Optimization")
    st.markdown("### Traffic Analysis and Prediction System")
    st.markdown("---")
    st.markdown("""
    This project analyzes historical traffic data, identifies major traffic congestion factors,
    visualizes traffic patterns, and predicts traffic volume using regression techniques.

    Traffic volume depends on several factors including time, weather, temperature, holidays,
    and day of the week. The system analyzes these factors to help understand and predict congestion.
    """)
    if st.session_state.df_clean is not None:
        df = st.session_state.df_clean
        summary = get_dataset_summary(df)
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Records", f"{summary['total_rows']:,}")
        with col2:
            st.metric("Avg Traffic/hr", f"{summary.get('traffic_mean', 0):.0f}")
        with col3:
            st.metric("Weather Types", df["weather_main"].nunique() if "weather_main" in df.columns else "—")
        with col4:
            st.metric("Max Volume", f"{summary.get('traffic_max', 0):.0f}")
        st.markdown("---")
        st.markdown("### Navigate using the sidebar to explore:")
        st.markdown("""
        - **Dataset Explorer** — Upload CSV, preview data, view statistics
        - **Traffic Analysis** — Trends, peak hours, weather impact
        - **Correlation Analysis** — Feature relationships and heatmap
        - **Machine Learning** — Train and compare regression models
        - **Traffic Prediction** — Predict volume from inputs
        - **Project Info** — Documentation and methodology
        """)
    else:
        st.info("No dataset loaded yet. Go to **Dataset Explorer** to upload a CSV or load sample data.")
        if st.button("Load Sample Data"):
            df = generate_sample_data(6000, seed=7)
            load_data_into_session(df, "Sample Data (Synthetic)")
            st.success("Sample data loaded! Explore the dashboard using the sidebar.")
            st.rerun()


def dataset_explorer_page():
    st.title("📂 Dataset Explorer")
    st.markdown("Upload a CSV file or load the built-in sample data based on the Metro Interstate Traffic Volume schema.")
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("#### Upload CSV")
        uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"], label_visibility="collapsed")
        if uploaded_file is not None:
            try:
                df = pd.read_csv(uploaded_file)
                load_data_into_session(df, uploaded_file.name)
                st.success(f"Loaded: {uploaded_file.name}")
            except Exception as e:
                st.error(f"Error reading file: {e}")
    with col2:
        st.markdown("#### Sample Data")
        if st.button("Load Sample Dataset", key="load_sample"):
            df = generate_sample_data(6000, seed=7)
            load_data_into_session(df, "Sample Data (Synthetic)")
            st.success("Sample data loaded!")
            st.rerun()
    with col3:
        st.markdown("#### Download Sample")
        if st.button("Download Sample CSV"):
            df_sample = generate_sample_data(3000, seed=11)
            st.download_button(
                label="Download CSV", data=df_sample.to_csv(index=False).encode("utf-8"),
                file_name="sample_metro_traffic.csv", mime="text/csv",
            )
    st.markdown("---")
    if st.session_state.df is not None:
        df = st.session_state.df
        report = st.session_state.preprocess_report
        st.markdown(f"**Loaded:** {st.session_state.dataset_name}")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Rows (clean)", f"{report['total_rows']:,}")
        with col2:
            st.metric("Columns", len(df.columns))
        with col3:
            st.metric("Duplicates removed", report["duplicates_removed"])
        with col4:
            st.metric("Missing imputed", report["missing_imputed"])
        if report["notes"]:
            st.markdown("#### Preprocessing Notes")
            for note in report["notes"]:
                st.warning(note)
        st.markdown("#### Data Preview (first 10 rows)")
        st.dataframe(df.head(10), use_container_width=True)
        st.markdown("#### Column Information")
        col_info = pd.DataFrame({
            "Column": df.columns,
            "Type": [str(df[c].dtype) for c in df.columns],
            "Missing": [df[c].isna().sum() for c in df.columns],
            "Unique": [df[c].nunique() for c in df.columns],
        })
        st.dataframe(col_info, use_container_width=True)
        st.markdown("#### Missing Value Report")
        missing = df.isna().sum()
        missing = missing[missing > 0]
        if len(missing) > 0:
            st.dataframe(missing.rename("Missing Count").to_frame(), use_container_width=True)
        else:
            st.success("No missing values in the raw data.")
        st.markdown("#### Descriptive Statistics")
        st.dataframe(df.describe(), use_container_width=True)
    else:
        st.info("No dataset loaded. Upload a CSV or load sample data above.")


def traffic_analysis_page():
    st.title("📊 Traffic Analysis")
    st.markdown("Explore traffic patterns across hours, days, months, and weather conditions.")
    st.markdown("---")
    if st.session_state.df_clean is None:
        st.info("No dataset loaded. Go to **Dataset Explorer** first.")
        return
    df = st.session_state.df_clean
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Records", f"{len(df):,}")
    with col2:
        st.metric("Avg Traffic/hr", f"{df['traffic_volume'].mean():.0f}" if "traffic_volume" in df.columns else "—")
    with col3:
        st.metric("Max Volume", f"{df['traffic_volume'].max():.0f}" if "traffic_volume" in df.columns else "—")
    with col4:
        st.metric("Min Volume", f"{df['traffic_volume'].min():.0f}" if "traffic_volume" in df.columns else "—")
    st.markdown("---")
    st.markdown("#### Traffic Volume Over Time")
    st.pyplot(plot_traffic_over_time(df))
    st.caption("Hourly traffic volume over the full dataset period. Spikes correspond to rush hours.")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Average Traffic by Hour of Day")
        fig, peak_hour = plot_avg_by_hour(df)
        st.pyplot(fig)
        if peak_hour is not None:
            st.caption(f"The red bar marks the peak hour ({peak_hour}:00). Traffic shows a bimodal rush-hour pattern.")
    with col2:
        st.markdown("#### Average Traffic by Day of Week")
        st.pyplot(plot_avg_by_day(df))
        st.caption("Weekdays typically carry more traffic than weekends.")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Average Traffic by Month")
        st.pyplot(plot_avg_by_month(df))
        st.caption("Monthly averages reveal seasonal travel patterns.")
    with col2:
        st.markdown("#### Weekday vs Weekend")
        st.pyplot(plot_weekday_vs_weekend(df))
        st.caption("Weekday commuting drives higher average volumes than weekend leisure travel.")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Traffic Under Weather Conditions")
        st.pyplot(plot_traffic_by_weather(df))
        st.caption("Adverse weather (rain, snow, thunderstorm) reduces traffic volume vs clear conditions.")
    with col2:
        st.markdown("#### Temperature vs Traffic Volume")
        st.pyplot(plot_temp_vs_traffic(df))
        st.caption("Each point is one hourly record. Extreme temperatures modestly reduce volume.")
    st.markdown("#### Peak Hour Analysis")
    peak_hours = get_peak_hours(df, top_n=5)
    if peak_hours is not None:
        st.dataframe(peak_hours.rename("Avg Volume").to_frame(), use_container_width=True)
    st.markdown("#### Traffic Volume Distribution")
    st.pyplot(plot_traffic_distribution(df))
    st.markdown("#### Key Insights")
    for insight in get_insights(df):
        st.markdown(f"- {insight}")


def correlation_page():
    st.title("🔗 Correlation Analysis")
    st.markdown("Pearson correlation between numeric features and traffic volume.")
    st.markdown("---")
    if st.session_state.df_clean is None:
        st.info("No dataset loaded. Go to **Dataset Explorer** first.")
        return
    df = st.session_state.df_clean
    st.markdown("#### Correlation Heatmap")
    fig, traffic_corr = plot_correlation_heatmap(df)
    st.pyplot(fig)
    st.caption("Red = positive correlation, Blue = negative. The diagonal is always 1.0 (self-correlation).")
    if traffic_corr is not None:
        st.markdown("#### Correlation with Traffic Volume")
        corr_df = traffic_corr.to_frame("Correlation").reset_index().rename(columns={"index": "Feature"})
        st.dataframe(corr_df, use_container_width=True)
        st.markdown("#### Insights")
        st.markdown("""
        - **Hour of day** has the strongest correlation with traffic volume — rush hours dominate.
        - **Weekend** is typically negatively correlated (less traffic on weekends).
        - **Holiday** is negatively correlated — holidays reduce traffic substantially.
        - **Rain and snow** show weak-to-moderate negative correlation.
        - **Temperature** shows a weak relationship, mostly through seasonality.
        - **Cloud cover** correlates weakly; it co-varies with weather types.
        """)
        st.info("Correlation measures only linear relationships. Tree-based models can capture non-linear effects.")


def ml_page():
    st.title("🤖 Machine Learning")
    st.markdown("Train and compare Linear Regression, Decision Tree, and Random Forest regressors.")
    st.markdown("Uses a chronological 80/20 split (no data leakage). Features: hour, weekday, month, "
                "is_weekend, is_holiday, temp, rain, snow, clouds, weather_main (one-hot encoded).")
    st.markdown("---")
    if st.session_state.df_clean is None:
        st.info("No dataset loaded. Go to **Dataset Explorer** first.")
        return
    col1, col2 = st.columns([3, 1])
    with col2:
        if st.button("Train Models", type="primary"):
            with st.spinner("Training models..."):
                try:
                    results = train_and_evaluate(st.session_state.df_clean)
                    st.session_state.training_results = results
                    save_model(results["best_pipeline"])
                    st.success(f"Training complete! Best model: {results['best_name']}")
                except Exception as e:
                    st.error(f"Training error: {e}")
            st.rerun()
    if st.session_state.training_results is not None:
        results = st.session_state.training_results
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Train Size", f"{results['train_size']:,}")
        with col2:
            st.metric("Test Size", f"{results['test_size']:,}")
        with col3:
            st.metric("Best Model", results["best_name"])
        with col4:
            best_r2 = results["results_df"].iloc[0]["R2"]
            st.metric("Best R²", f"{best_r2:.3f}")
        st.markdown("---")
        st.markdown("#### Model Comparison")
        st.dataframe(results["results_df"], use_container_width=True)
        st.markdown("#### Why this model?")
        best_name = results["best_name"]
        if best_name == "Random Forest":
            st.info("Random Forest is selected — it captures non-linear interactions between hour, weather, "
                    "and day type without overfitting, yielding the best generalization.")
        elif best_name == "Decision Tree":
            st.info("The Decision Tree edges out others here, but watch for overfitting on smaller datasets. "
                    "Random Forest is usually more robust.")
        else:
            st.info("Linear Regression performs best here, suggesting a mostly linear relationship in this dataset.")
        import matplotlib.pyplot as plt
        st.markdown("#### Predicted vs Actual (Test Set)")
        fig, ax = plt.subplots(figsize=(8, 6))
        y_test = results["y_test"]
        y_pred = results["predictions"][best_name]
        ax.scatter(y_test, y_pred, alpha=0.3, s=8, color="#10b981")
        min_val = min(y_test.min(), y_pred.min())
        max_val = max(y_test.max(), y_pred.max())
        ax.plot([min_val, max_val], [min_val, max_val], "r--", linewidth=1.5)
        ax.set_xlabel("Actual Volume")
        ax.set_ylabel("Predicted Volume")
        ax.set_title(f"Predicted vs Actual — {best_name}")
        plt.tight_layout()
        st.pyplot(fig)
        st.caption("Points along the diagonal line indicate accurate predictions.")
        if results["importances"] is not None:
            st.markdown("#### Feature Importance (Random Forest)")
            imp_df = pd.DataFrame(results["importances"], columns=["Feature", "Importance"]).head(12)
            fig, ax = plt.subplots(figsize=(10, 5))
            ax.barh(imp_df["Feature"][::-1], imp_df["Importance"][::-1], color="#f59e0b")
            ax.set_xlabel("Importance")
            ax.set_title("Top 12 Feature Importances")
            plt.tight_layout()
            st.pyplot(fig)
    else:
        if model_exists():
            st.info("A saved model was found. Click 'Train Models' to retrain, or go to **Traffic Prediction** to use it.")
            if st.button("Load Saved Model"):
                pipeline = load_model()
                if pipeline is not None:
                    st.session_state.training_results = {"best_pipeline": pipeline, "best_name": "Saved Model"}
                    st.success("Model loaded!")
                    st.rerun()
        else:
            st.info("Click **Train Models** to train and evaluate all three regressors.")


def prediction_page():
    st.title("🔮 Traffic Volume Prediction")
    st.markdown("Enter the expected conditions to predict traffic volume using the trained model.")
    st.markdown("---")
    if st.session_state.training_results is None:
        if model_exists():
            pipeline = load_model()
            if pipeline is not None:
                st.session_state.training_results = {"best_pipeline": pipeline, "best_name": "Saved Model"}
                st.success("Loaded saved model.")
                st.rerun()
            else:
                st.warning("No trained model found. Go to **Machine Learning** to train models first.")
                return
        else:
            st.warning("No trained model found. Go to **Machine Learning** to train models first.")
            return
    pipeline = st.session_state.training_results["best_pipeline"]
    traffic_mean = 3000
    traffic_std = 1500
    if st.session_state.df_clean is not None and "traffic_volume" in st.session_state.df_clean.columns:
        traffic_mean = st.session_state.df_clean["traffic_volume"].mean()
        traffic_std = st.session_state.df_clean["traffic_volume"].std()
    st.markdown("#### Input Parameters")
    col1, col2, col3 = st.columns(3)
    with col1:
        date = st.date_input("Date")
        hour = st.slider("Hour of Day", 0, 23, 8)
        temp = st.number_input("Temperature (Kelvin)", value=288.0, min_value=200.0, max_value=350.0, step=0.5)
        rain = st.number_input("Rain (mm/h)", value=0.0, min_value=0.0, step=0.1)
    with col2:
        weather_options = ["Clear", "Clouds", "Rain", "Drizzle", "Mist", "Haze", "Fog", "Snow", "Thunderstorm", "Squall"]
        if st.session_state.df_clean is not None and "weather_main" in st.session_state.df_clean.columns:
            weather_options = sorted(st.session_state.df_clean["weather_main"].unique())
        weather = st.selectbox("Weather Condition", weather_options)
        snow = st.number_input("Snow (mm/h)", value=0.0, min_value=0.0, step=0.01)
        clouds = st.slider("Cloud Coverage (%)", 0, 100, 40)
    with col3:
        is_holiday = st.selectbox("Holiday", ["None", "Holiday"]) == "Holiday"
        weekday = date.weekday()
        month = date.month
        is_weekend = 1 if weekday >= 5 else 0
        st.markdown(f"**Day of week:** {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][weekday]}")
        st.markdown(f"**Month:** {month}")
        st.markdown(f"**Weekend:** {'Yes' if is_weekend else 'No'}")
    st.markdown("---")
    is_valid, error_msg = validate_input(temp, rain, snow, clouds, hour)
    if not is_valid:
        st.error(f"Input validation error: {error_msg}")
        return
    if st.button("Predict Traffic Volume", type="primary"):
        try:
            input_df = make_prediction_input(
                hour=hour, weekday=weekday, month=month, is_weekend=is_weekend,
                is_holiday=1 if is_holiday else 0, temp=temp, rain_1h=rain,
                snow_1h=snow, clouds_all=clouds, weather_main=weather,
            )
            predicted, level, explanation = predict_traffic(pipeline, input_df, traffic_mean, traffic_std)
            st.markdown("---")
            st.markdown("#### Prediction Result")
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Predicted Volume", f"{predicted:,.0f}", "vehicles/hr")
            with col2:
                color = {"Low": "green", "Moderate": "orange", "High": "red"}[level]
                st.markdown("### Congestion Level")
                st.markdown(f"<span style='color:{color}; font-size:24px; font-weight:bold;'>{level}</span>",
                            unsafe_allow_html=True)
            with col3:
                st.markdown("#### Explanation")
                st.caption(explanation)
            st.info("Predictions are estimates based on patterns in the loaded dataset. "
                    "Accuracy depends on data coverage and quality.")
        except Exception as e:
            st.error(f"Prediction error: {e}")


def info_page():
    st.title("📖 Project Information")
    st.markdown("---")
    st.markdown("### Problem Statement")
    st.markdown("""
    Urban traffic congestion causes wasted time, fuel, and pollution. Existing systems report current
    conditions but rarely predict future volume, so city planners and commuters cannot act ahead of time.
    This project analyzes historical traffic and weather data to understand what drives congestion and
    predicts traffic volume from time and weather inputs.
    """)
    st.markdown("### Objectives")
    for obj in [
        "Analyze historical traffic data and identify peak congestion periods.",
        "Study the effect of weather, hour, day, and holidays on traffic volume.",
        "Perform feature extraction and feature engineering.",
        "Build and compare regression models (Linear, Decision Tree, Random Forest).",
        "Predict traffic volume from user-provided inputs.",
        "Visualize trends and congestion patterns in an interactive dashboard.",
    ]:
        st.markdown(f"- {obj}")
    st.markdown("### Dataset")
    st.markdown("""
    **Metro Interstate Traffic Volume Dataset** — hourly traffic on a US interstate.

    | Column | Type | Description |
    |--------|------|-------------|
    | date_time | datetime | Date and time |
    | traffic_volume | int | Traffic volume (vehicles/hr) |
    | temp | float | Temperature (Kelvin) |
    | rain_1h | float | Rain (mm/h) |
    | snow_1h | float | Snow (mm/h) |
    | clouds_all | int | Cloud coverage (%) |
    | weather_main | string | Weather condition |
    | holiday | string | Holiday name or "None" |
    """)
    st.markdown("### Technologies Used")
    for tech, desc in {
        "Python": "Core programming language",
        "Pandas": "Data cleaning and analysis",
        "NumPy": "Numerical calculations",
        "Matplotlib": "Graphs and visualizations",
        "Seaborn": "Statistical visualizations",
        "Scikit-learn": "Machine learning and regression",
        "Streamlit": "Interactive web interface",
        "Joblib": "Model persistence",
    }.items():
        st.markdown(f"- **{tech}:** {desc}")
    st.markdown("### Methodology")
    for step in [
        "1. Load & inspect — parse CSV, infer column types, show preview & stats.",
        "2. Clean — drop duplicates, impute missing values, fix weather/holiday defaults.",
        "3. Engineer features — extract hour/day/month/weekday/weekend from date_time; one-hot encode weather.",
        "4. EDA — aggregate by hour, day, month, weather; correlation matrix; scatter plots.",
        "5. Train — chronological 80/20 split; train Linear, Decision Tree, Random Forest.",
        "6. Evaluate — MAE, MSE, RMSE, R²; pick best by R².",
        "7. Predict — encode user input, run the best model, classify congestion.",
    ]:
        st.markdown(step)
    st.markdown("### System Architecture")
    st.code("CSV/Sample -> Preprocessing -> Feature Engineering -> Model Training -> Evaluation -> Prediction", language="text")
    st.markdown("### Workflow")
    st.code("1. Upload / Load sample\n2. Preprocess & engineer\n3. EDA & visualizations\n4. Train models\n5. Evaluate & select best\n6. Predict traffic volume", language="text")
    st.markdown("### Advantages")
    for adv in [
        "Real machine learning — no fabricated metrics or hardcoded predictions.",
        "Flexible column detection handles variations in CSV headers.",
        "Leakage-free chronological evaluation.",
        "Model saved to disk for reuse without retraining.",
        "Simple, clean UI suitable for a college demonstration.",
    ]:
        st.markdown(f"- {adv}")
    st.markdown("### Limitations")
    for lim in [
        "Prediction accuracy depends on dataset coverage and quality.",
        "Models cannot capture rare events (accidents, construction) absent from training data.",
        "Sample data is synthetic — use the real Metro dataset for production results.",
        "Linear Regression cannot model non-linear rush-hour patterns.",
    ]:
        st.markdown(f"- {lim}")
    st.markdown("### Future Scope")
    for fut in [
        "Integrate live traffic & weather APIs for real-time prediction.",
        "Time-series models (ARIMA, gradient boosting) for multi-step forecasting.",
        "Geospatial map view of congestion hotspots.",
        "Alerting and route-recommendation features for commuters.",
    ]:
        st.markdown(f"- {fut}")
    st.markdown("### Conclusion")
    st.markdown("""
    The system demonstrates the full data-science pipeline — ingestion, cleaning, feature engineering,
    EDA, modeling, evaluation, and prediction — in a single Streamlit dashboard. It identifies rush hours
    and weather effects, compares three regression algorithms, and predicts traffic volume with an
    interpretable congestion label. The Random Forest model is typically best because it captures non-linear
    interactions between time and weather.
    """)
    st.markdown("### References")
    st.markdown("""
    - Hodge, V. J. and Austin, J. (2017). "Mining for Correlations Between Traffic Volume and Weather Conditions." Intelligent Transportation Systems.
    - Metro Interstate Traffic Volume Dataset, UCI Machine Learning Repository.
    - Pedregosa et al. (2011). "Scikit-learn: Machine Learning in Python." JMLR.
    """)


# ----------------------------------------------------------------------------
if page == "🏠 Home":
    home_page()
elif page == "📂 Dataset Explorer":
    dataset_explorer_page()
elif page == "📊 Traffic Analysis":
    traffic_analysis_page()
elif page == "🔗 Correlation Analysis":
    correlation_page()
elif page == "🤖 Machine Learning":
    ml_page()
elif page == "🔮 Traffic Prediction":
    prediction_page()
elif page == "📖 Project Info":
    info_page()