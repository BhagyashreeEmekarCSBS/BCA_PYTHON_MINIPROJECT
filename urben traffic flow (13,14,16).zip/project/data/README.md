# Metro Interstate Traffic Volume Dataset

## How to obtain the dataset

### Option 1: UCI Machine Learning Repository
Download from: https://archive.ics.uci.edu/dataset/492/metro+interstate+traffic+volume

Save the extracted file as `data/Metro_Interstate_Traffic_Volume.csv`

### Option 2: Kaggle
https://www.kaggle.com/datasets/maharshipandya/-metro-interstate-traffic-volume

### Option 3: Use the built-in sample generator
If the dataset is not available, the app can generate synthetic sample data
with the same schema and realistic patterns. Just click "Load sample data"
on the Dataset Explorer page.

## Expected columns

| Column            | Type    | Description                        |
|-------------------|---------|------------------------------------|
| holiday           | string  | Holiday name or "None"             |
| temp              | float   | Temperature in Kelvin              |
| rain_1h           | float   | Rain in mm per hour                |
| snow_1h           | float   | Snow in mm per hour                |
| clouds_all        | int     | Cloud coverage percentage (0-100)  |
| weather_main      | string  | Short weather description          |
| weather_description| string | Detailed weather description       |
| date_time         | string  | Date and time (YYYY-MM-DD HH:MM:SS)|
| traffic_volume    | int     | Traffic volume (vehicles per hour) |
