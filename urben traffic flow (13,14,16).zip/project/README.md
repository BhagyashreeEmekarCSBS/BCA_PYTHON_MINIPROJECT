# Urban Traffic Flow Optimization - Traffic Analysis and Prediction System

A Python + Streamlit web application that analyzes historical traffic data, identifies congestion factors, visualizes traffic patterns, and predicts traffic volume using regression machine learning models.

## Project Structure

```
urban-traffic-flow-optimization/
├── app.py                       # Main Streamlit application
├── requirements.txt              # Python dependencies
├── README.md                     # This file
├── data/
│   ├── README.md                 # Dataset download instructions
│   └── Metro_Interstate_Traffic_Volume.csv  # (download or auto-generated)
├── src/
│   ├── __init__.py
│   ├── data_preprocessing.py     # Data cleaning & feature engineering
│   ├── eda.py                    # Exploratory data analysis & visualizations
│   ├── model_training.py         # Regression model training & evaluation
│   └── prediction.py             # Prediction logic
└── models/
    └── best_model.joblib         # Saved trained model (created after training)
```

## 1. Install Python Dependencies

### Prerequisites
- Python 3.9 or higher
- pip (comes with Python)

### Option A: Install directly
```bash
pip install -r requirements.txt
```

### Option B: Use a virtual environment (recommended)

**Windows:**
```cmd
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

**macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 2. Download or Upload the Dataset

### Download the real Metro Interstate Traffic Volume dataset:
1. Go to https://archive.ics.uci.edu/dataset/492/metro+interstate+traffic+volume
2. Download the CSV file
3. Save it as `data/Metro_Interstate_Traffic_Volume.csv`

### Or use the built-in sample data:
The app can generate synthetic sample data with the same schema and realistic patterns.
Just click **"Load Sample Dataset"** on the Dataset Explorer page — no download needed.

### Or upload your own CSV:
Use the file uploader on the Dataset Explorer page. The app auto-detects columns by name.

## 3. Open the Project in VS Code

1. Open VS Code
2. File -> Open Folder -> select the project folder
3. Open a terminal: Terminal -> New Terminal
4. Install dependencies (see step 1)
5. Run the app (see step 5)

## 4. Create and Activate a Virtual Environment

See **Option B** in step 1 above.

## 5. Run the Application

```bash
streamlit run app.py
```

This will start the Streamlit server and open your browser to http://localhost:8501

## 6. Using the Application

1. **Home** — Overview and dataset statistics
2. **Dataset Explorer** — Upload CSV or load sample data; preview data and statistics
3. **Traffic Analysis** — View trend graphs, peak-hour analysis, weather impact
4. **Correlation Analysis** — See the correlation heatmap and feature relationships
5. **Machine Learning** — Click "Train Models" to train Linear Regression, Decision Tree, and Random Forest
6. **Traffic Prediction** — Enter time, weather, and holiday info; click "Predict" to get the predicted volume
7. **Project Info** — Full documentation, methodology, and architecture

### Training the model:
- Go to **Machine Learning** page
- Click **"Train Models"**
- The best model is automatically saved to `models/best_model.joblib`
- On next launch, you can load the saved model without retraining

### Making predictions:
- Go to **Traffic Prediction** page
- Enter the date, hour, temperature, weather, etc.
- Click **"Predict Traffic Volume"**
- View the predicted volume and congestion level (Low / Moderate / High)

## 7. Troubleshooting

| Error | Solution |
|-------|----------|
| `ModuleNotFoundError: No module named 'streamlit'` | Run `pip install -r requirements.txt` |
| `FileNotFoundError: dataset not found` | Download the Metro dataset or use "Load Sample Dataset" |
| `Port 8501 already in use` | Run `streamlit run app.py --server.port 8502` |
| `Training error: Not enough data` | Need at least 10 rows after cleaning; load a larger dataset |
| `Prediction error: Model is not trained` | Go to Machine Learning page and click "Train Models" first |
| Charts not displaying | Run `pip install matplotlib seaborn` |
| Virtual environment issues | Ensure `(venv)` shows in your terminal prompt before running |

## Technologies Used

| Technology | Purpose |
|-----------|---------|
| Python | Core programming language |
| Pandas | Data cleaning and analysis |
| NumPy | Numerical calculations |
| Matplotlib | Graphs and visualizations |
| Seaborn | Statistical visualizations and heatmaps |
| Scikit-learn | Machine learning and regression models |
| Streamlit | Interactive web application interface |
| Joblib | Model persistence |

## License

This is an educational college mini project.
