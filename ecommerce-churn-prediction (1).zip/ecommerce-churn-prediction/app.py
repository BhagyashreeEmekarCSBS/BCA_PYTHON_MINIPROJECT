"""
app.py - Streamlit dashboard for the E-Commerce Customer Churn Prediction System.
Run with:   streamlit run app.py
"""
from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import config
from src import data_loader as dl
from src import eda
from src import explainability as ex
from src import predict as pr
from src import preprocessing as pp
from src import recommendations as rc
from src import reports
from src import train_model as tm

st.set_page_config(page_title=config.APP_TITLE, page_icon="📉", layout="wide",
                   initial_sidebar_state="expanded")

PAGES = ["🏠 Home", "📂 Dataset", "📊 EDA", "🧹 Preprocessing", "🤖 Model Training",
         "🔮 Prediction", "🧠 Churn Factors", "💡 Recommendations", "📑 Reports", "ℹ️ About"]

NAVY, TEAL = config.COLORS["navy"], config.COLORS["teal"]

CSS = f"""
<style>
.block-container {{ padding-top: 1.6rem; max-width: 1250px; }}
[data-testid="stSidebar"] {{ background: linear-gradient(180deg,{NAVY} 0%,#102B52 100%); }}
[data-testid="stSidebar"] * {{ color: #E6EEF8 !important; }}
[data-testid="stSidebar"] hr {{ border-color: rgba(255,255,255,.15); }}
.hero {{ background: linear-gradient(120deg,{NAVY} 0%,#12407A 60%,{TEAL} 140%); color:#fff;
        padding: 28px 32px; border-radius: 18px; box-shadow: 0 10px 28px rgba(11,31,58,.25); margin-bottom: 18px; }}
.hero h1 {{ color:#fff; margin:0 0 6px 0; font-size: 1.9rem; }}
.hero p {{ color:#D5E3F5; margin:0; font-size:1.02rem; }}
.page-title {{ color:{NAVY}; font-weight:800; font-size:1.7rem; margin-bottom:2px; }}
.page-sub {{ color:#64748B; margin-bottom:18px; }}
.kpi-card {{ background:#fff; border-radius:16px; padding:16px 18px; box-shadow:0 4px 16px rgba(11,31,58,.08);
            border-left:6px solid {TEAL}; margin-bottom:10px; height: 118px; }}
.kpi-red {{ border-left-color:{config.COLORS['churned']}; }}
.kpi-blue {{ border-left-color:{config.COLORS['blue']}; }}
.kpi-navy {{ border-left-color:{NAVY}; }}
.kpi-label {{ color:#64748B; font-size:.82rem; text-transform:uppercase; letter-spacing:.05em; font-weight:600; }}
.kpi-value {{ color:{NAVY}; font-size:1.85rem; font-weight:800; line-height:1.25; }}
.kpi-sub {{ color:#94A3B8; font-size:.8rem; }}
.card {{ background:#fff; border-radius:16px; padding:18px 20px; box-shadow:0 4px 16px rgba(11,31,58,.08); margin-bottom:12px; }}
.badge {{ display:inline-block; padding:6px 18px; border-radius:999px; color:#fff; font-weight:700; font-size:1.05rem; }}
.badge-Low {{ background:#16A34A; }} .badge-Medium {{ background:#F59E0B; }} .badge-High {{ background:#DC2626; }}
div.stButton > button, div.stDownloadButton > button {{ border-radius:10px; font-weight:600; }}
.stTabs [data-baseweb="tab"] {{ font-weight:600; }}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


# ============================================================ UI helpers
def kpi_card(label, value, sub="", accent="teal"):
    return (f'<div class="kpi-card kpi-{accent}"><div class="kpi-label">{label}</div>'
            f'<div class="kpi-value">{value}</div><div class="kpi-sub">{sub}</div></div>')


def kpi_row(items):
    cols = st.columns(len(items))
    for col, item in zip(cols, items):
        col.markdown(kpi_card(*item), unsafe_allow_html=True)


def page_header(title, subtitle):
    st.markdown(f'<div class="page-title">{title}</div><div class="page-sub">{subtitle}</div>',
                unsafe_allow_html=True)


def csv_bytes(df: pd.DataFrame) -> bytes:
    """utf-8-sig so that Excel on Windows shows the text correctly."""
    return df.to_csv(index=False).encode("utf-8-sig")


def go_to(page):
    st.session_state["nav"] = page


# ============================================================ session state
def set_dataset(df, name, synthetic=False):
    ss = st.session_state
    ss.df_raw = df
    ss.df_clean, ss.clean_report = dl.clean_dataframe(df)
    ss.dataset_name, ss.is_synthetic = name, synthetic
    ss.target_col = dl.detect_target_column(df)
    ss.positive_label = None
    if ss.target_col is not None:
        s = ss.df_clean[ss.target_col].dropna()
        if s.nunique() == 2:
            ss.positive_label = pp.guess_positive_label(list(pd.unique(s)), s)
    ss.bulk_results = None


def init_state():
    ss = st.session_state
    if "initialised" in ss:
        return
    ss.initialised = True
    ss.update(df_raw=None, df_clean=None, dataset_name=None, is_synthetic=False, clean_report={},
              target_col=None, positive_label=None, test_size=config.TEST_SIZE, bundle=None,
              model_error=None, sample_error=None, bulk_results=None, last_upload=None,
              low=config.LOW_RISK_THRESHOLD, high=config.HIGH_RISK_THRESHOLD, nav=PAGES[0])
    try:                                           # start with the sample data loaded
        set_dataset(dl.load_sample(), "sample_customers.csv (synthetic demo data)", True)
    except dl.DatasetError as exc:
        ss.sample_error = str(exc)
    try:                                           # reload a previously saved model
        ss.bundle = tm.load_bundle()
    except tm.ModelLoadError as exc:
        ss.model_error = str(exc)


def flagged():
    """Clean dataset + churn flag, or None if the target is not valid yet."""
    ss = st.session_state
    if ss.df_clean is None or ss.target_col is None:
        return None
    try:
        return eda.add_churn_flag(ss.df_clean, ss.target_col, ss.positive_label)
    except (pp.PreprocessingError, KeyError):
        return None


def need_data():
    ss = st.session_state
    if ss.df_clean is None:
        st.warning("No dataset loaded. Open **📂 Dataset** and upload a CSV or load the sample data.")
        st.button("Go to Dataset page", on_click=go_to, args=(PAGES[1],))
        return True
    return False


def need_target():
    dfx = flagged()
    if dfx is None:
        st.warning("A valid churn (target) column is needed. Select it on the **🧹 Preprocessing** page.")
        st.button("Go to Preprocessing page", on_click=go_to, args=(PAGES[3],))
    return dfx


def need_model():
    ss = st.session_state
    if ss.bundle is None:
        if ss.model_error:
            st.error(ss.model_error)
        st.info("No trained model yet. Open **🤖 Model Training** and click **Train models** (usually under a minute).")
        st.button("Go to Model Training", on_click=go_to, args=(PAGES[4],))
        return True
    return False


# ================================================================ pages
def page_home():
    ss = st.session_state
    st.markdown(f'<div class="hero"><h1>📉 {config.APP_TITLE}</h1>'
                '<p>Analyse customer behaviour, predict who is likely to stop buying, understand the '
                'factors linked with churn and plan retention actions.</p></div>', unsafe_allow_html=True)
    if ss.sample_error:
        st.error(ss.sample_error)
    if need_data():
        return
    if ss.is_synthetic:
        st.info("You are viewing the **synthetic demo dataset**. Figures illustrate how the system works and "
                "are not real business findings.")
    dfx = need_target()
    if dfx is None:
        return
    k = eda.compute_kpis(dfx)
    kpi_row([("Total customers", f"{k['total']:,}", ss.dataset_name or "", "navy"),
             ("Churned customers", f"{k['churned']:,}", "stopped purchasing", "red"),
             ("Retention rate", f"{k['retention_rate']:.1f}%", "customers retained", "teal"),
             ("Churn rate", f"{k['churn_rate']:.1f}%", "overall", "red"),
             ("Avg purchase value",
              f"{k['avg_purchase_value']:,.0f}" if k["avg_purchase_value"] is not None else "N/A",
              k["aov_col"] or "no such column in data", "blue")])
    left, right = st.columns([3, 2])
    with left:
        st.markdown("#### 💬 Business insights (calculated from the data)")
        num, cat = eda.feature_lists(dfx, ss.target_col)
        for line in eda.generate_insights(dfx, num, cat) or ["Not enough data for insights."]:
            st.markdown(f"- {line}")
        if ss.bundle:
            b = ss.bundle
            t = b["results"][b["best_model_name"]]["test"]
            st.success(f"Trained model available: **{b['best_model_name']}** "
                       f"(test F1 {t['f1']:.2f}, ROC-AUC {t['roc_auc']:.2f}).")
        else:
            st.warning("No trained model yet - go to **Model Training**.")
    with right:
        st.plotly_chart(eda.churn_donut(dfx), width="stretch")
    st.markdown("#### 🧭 Explore the modules")
    cols = st.columns(3)
    blurbs = ["Upload / validate data", "Charts and filters", "Pipeline and target", "Train & compare models",
              "Single and bulk prediction", "Why customers churn", "Retention suggestions", "Downloads", "Project details"]
    for i, page in enumerate(PAGES[1:]):
        with cols[i % 3]:
            st.button(f"{page}  -  {blurbs[i]}", key=f"home_{i}", on_click=go_to, args=(page,), width="stretch")


def page_dataset():
    ss = st.session_state
    page_header("📂 Dataset Upload & Management", "Upload a customer CSV, validate it and download the cleaned version.")
    c1, c2 = st.columns([3, 1])
    with c1:
        up = st.file_uploader("Upload customer dataset (CSV)", type=["csv"])
    with c2:
        st.write("")
        st.write("")
        if st.button("Load sample dataset", width="stretch"):
            try:
                set_dataset(dl.load_sample(), "sample_customers.csv (synthetic demo data)", True)
                st.success("Sample dataset loaded.")
            except dl.DatasetError as exc:
                st.error(str(exc))
    if up is not None:
        uid = f"{up.name}-{up.size}"
        if ss.last_upload != uid:
            try:
                set_dataset(dl.load_csv(up), up.name, False)
                ss.last_upload = uid
                st.success(f"Loaded **{up.name}**.")
            except dl.DatasetError as exc:
                ss.last_upload = uid
                st.error(f"Upload failed: {exc}")
    if need_data():
        return
    raw, clean = ss.df_raw, ss.df_clean
    summ = dl.get_data_summary(raw)
    st.caption(f"Current dataset: **{ss.dataset_name}**" + ("  |  synthetic data" if ss.is_synthetic else ""))
    kpi_row([("Rows", f"{summ['rows']:,}", "in uploaded file", "navy"), ("Columns", summ["columns"], "", "blue"),
             ("Duplicate rows", summ["duplicates"], "removed in cleaned data", "red"),
             ("Missing cells", f"{summ['missing_cells']:,}", "filled inside the ML pipeline", "red")])
    check = dl.validate_dataframe(clean, ss.target_col)
    for msg in check["errors"]:
        st.error(msg)
    for msg in check["warnings"]:
        st.warning(msg)
    if not check["errors"]:
        st.success("Validation passed - the dataset can be used for analysis and training.")
    t1, t2, t3, t4 = st.tabs(["Preview", "Types & missing values", "Data dictionary", "Cleaned data"])
    with t1:
        st.dataframe(raw.head(100), width="stretch")
    with t2:
        st.dataframe(summ["table"], width="stretch", hide_index=True)
    with t3:
        st.dataframe(dl.build_data_dictionary(raw, ss.target_col), width="stretch", hide_index=True)
        if ss.is_synthetic:
            st.caption("Source: generated by data/generate_sample_data.py (synthetic, seed 42).")
    with t4:
        r = ss.clean_report
        st.write(f"Rows before: **{r['rows_before']:,}** | duplicates removed: **{r['duplicates_removed']}** | "
                 f"rows without target removed: **{r['missing_target_removed']}** | rows after: **{r['rows_after']:,}**")
        st.dataframe(clean.head(100), width="stretch")
        st.download_button("⬇️ Download cleaned dataset (CSV)", csv_bytes(clean), "cleaned_customers.csv", "text/csv")


def page_eda():
    ss = st.session_state
    page_header("📊 Exploratory Data Analysis", "Understand customer behaviour and how it relates to churn.")
    if need_data():
        return
    dfx = need_target()
    if dfx is None:
        return
    num, cat = eda.feature_lists(dfx, ss.target_col)

    with st.expander("🔎 Filters", expanded=False):
        f1, f2 = st.columns(2)
        with f1:
            fc = st.selectbox("Filter by category", ["(none)"] + [c for c in cat if dfx[c].nunique() <= 30])
            if fc != "(none)":
                chosen = st.multiselect(f"{fc} values", sorted(dfx[fc].dropna().unique().tolist()),
                                        default=sorted(dfx[fc].dropna().unique().tolist()))
                dfx = dfx[dfx[fc].isin(chosen)]
        with f2:
            fn = st.selectbox("Filter by numeric range", ["(none)"] + num)
            if fn != "(none)":
                lo, hi = float(dfx[fn].min()), float(dfx[fn].max())
                if lo < hi:
                    rng = st.slider(fn, lo, hi, (lo, hi))
                    dfx = dfx[dfx[fn].between(*rng)]
    if dfx.empty or dfx[eda.FLAG].nunique() < 2:
        st.warning("The current filters leave too little data for charts. Widen the filters.")
        return
    k = eda.compute_kpis(dfx)
    kpi_row([("Customers (filtered)", f"{k['total']:,}", "", "navy"), ("Churn rate", f"{k['churn_rate']:.1f}%", "", "red"),
             ("Retention rate", f"{k['retention_rate']:.1f}%", "", "teal")])

    tabs = st.tabs(["Churn overview", "Behaviour distributions", "Segments", "Correlation", "Box plots"])
    with tabs[0]:
        a, b = st.columns(2)
        a.plotly_chart(eda.churn_bar(dfx), width="stretch")
        b.plotly_chart(eda.churn_donut(dfx), width="stretch")
    with tabs[1]:
        roles = {"Purchase frequency": ["purchase_freq", "frequency", "orders_per"],
                 "Total spending": ["total_spend", "spending", "monetary"],
                 "Average order value": ["avg_order", "average_order", "aov", "order_value"],
                 "Days since last purchase": ["days_since", "recency", "last_purchase"],
                 "Engagement": ["session", "engagement", "visit", "login"]}
        found = {lbl: dl.find_column(num, kw) for lbl, kw in roles.items()}
        found = {k_: v for k_, v in found.items() if v}
        st.caption("Charts are created automatically for the behaviour columns found in your data.")
        for i in range(0, len(found), 2):
            cols = st.columns(2)
            for col, (lbl, name) in zip(cols, list(found.items())[i:i + 2]):
                col.plotly_chart(eda.histogram(dfx, name), width="stretch")
        extra = st.selectbox("Explore any other numeric column", num)
        st.plotly_chart(eda.histogram(dfx, extra), width="stretch")
    with tabs[2]:
        small = [c for c in cat] + [c for c in num if dfx[c].nunique() <= 8]
        if small:
            pref = dl.find_column(small, ["member", "tier", "plan"]) or small[0]
            choice = st.selectbox("Churn rate by", small, index=small.index(pref))
            st.plotly_chart(eda.churn_rate_by_category(dfx, choice), width="stretch")
        cs = dl.find_column(num, ["complaint", "support", "ticket"])
        if cs:
            st.plotly_chart(eda.churn_rate_by_category(dfx, cs) if dfx[cs].nunique() <= 15
                            else eda.churn_rate_by_bins(dfx, cs), width="stretch")
        cont = st.selectbox("Churn trend across groups of", num)
        fig = eda.churn_rate_by_bins(dfx, cont)
        if fig is not None:
            st.plotly_chart(fig, width="stretch")
    with tabs[3]:
        if len(num) >= 2:
            st.pyplot(eda.correlation_heatmap(dfx, num))
            st.caption("Correlation shows linear association only; it does not prove cause and effect.")
        else:
            st.info("At least two numeric columns are needed for a correlation heatmap.")
    with tabs[4]:
        pick = st.multiselect("Choose columns", num, default=num[:4])
        for i in range(0, len(pick), 2):
            cols = st.columns(2)
            for col, name in zip(cols, pick[i:i + 2]):
                col.plotly_chart(eda.box_plot(dfx, name), width="stretch")


def page_preprocessing():
    ss = st.session_state
    page_header("🧹 Data Preprocessing", "Choose the churn column and see how the data is prepared for machine learning.")
    if need_data():
        return
    df = ss.df_clean
    cols = list(df.columns)
    idx = cols.index(ss.target_col) if ss.target_col in cols else 0
    sel = st.selectbox("Target (churn) column", cols, index=idx,
                       help="Detected automatically when possible - change it if it is wrong.")
    if sel != ss.target_col:
        ss.target_col, ss.positive_label = sel, None
    uniques = list(pd.unique(df[sel].dropna()))
    if len(uniques) != 2:
        st.error(f"'{sel}' has {len(uniques)} distinct values. A churn column must have exactly 2 (e.g. Yes/No).")
        return
    guess = ss.positive_label if ss.positive_label in uniques else pp.guess_positive_label(uniques, df[sel].dropna())
    ss.positive_label = st.selectbox("Which value means the customer CHURNED?", uniques, index=uniques.index(guess))
    ss.test_size = st.slider("Test set size", 0.10, 0.40, float(ss.test_size), 0.05,
                             help="Share of customers kept aside to test the final model.")
    try:
        X, y, info = pp.prepare_xy(df, ss.target_col, ss.positive_label)
    except pp.PreprocessingError as exc:
        st.error(str(exc))
        return
    kpi_row([("Features used", len(X.columns), f"{len(info['numeric_cols'])} numeric, {len(info['categorical_cols'])} categorical", "teal"),
             ("Churn rate", f"{info['churn_rate'] * 100:.1f}%", f"imbalance ratio {info['imbalance_ratio']:.1f}:1", "red"),
             ("Customers", f"{info['n_rows']:,}", "after cleaning", "navy")])
    for note in info["notes"]:
        st.warning(note)
    a, b = st.columns(2)
    with a:
        st.markdown("**Numeric features** (missing → median, then standardised)")
        st.write(", ".join(info["numeric_cols"]) or "none")
        st.markdown("**Categorical features** (missing → most common, then one-hot encoded)")
        st.write(", ".join(info["categorical_cols"]) or "none")
    with b:
        st.markdown("**Columns excluded from the model**")
        if info["dropped_columns"]:
            st.dataframe(pd.DataFrame(info["dropped_columns"], columns=["Column", "Reason"]), hide_index=True,
                         width="stretch")
        else:
            st.write("none")
    X_tr, X_te, y_tr, y_te = pp.split_data(X, y, ss.test_size)
    st.markdown("#### Train / test split (stratified, random seed 42)")
    split = pd.DataFrame({"Set": ["Training", "Testing"], "Customers": [len(X_tr), len(X_te)],
                          "Churn rate %": [round(y_tr.mean() * 100, 2), round(y_te.mean() * 100, 2)]})
    st.dataframe(split, hide_index=True, width="stretch")
    pre = pp.build_preprocessor(info["numeric_cols"], info["categorical_cols"]).fit(X_tr)   # fitted on TRAIN only
    st.success(f"Preprocessor fitted on the training set only (no data leakage): "
               f"{X_tr.shape[1]} raw features → {len(pre.get_feature_names_out())} model inputs.")
    with st.expander("How is class imbalance and leakage handled?"):
        st.markdown("- **Imbalance:** every model uses `class_weight='balanced'`, so the minority (churn) class counts more.\n"
                    "- **Leakage:** imputing, scaling and encoding are learned inside the scikit-learn Pipeline, "
                    "separately for each cross-validation fold and for the final training set. "
                    "ID columns and columns named *churn* are never used as features.")


def page_training():
    ss = st.session_state
    page_header("🤖 Machine Learning Models", "Train Logistic Regression, Decision Tree and Random Forest, then compare them fairly.")
    if need_data():
        return
    ready = flagged() is not None
    if not ready:
        st.warning("Select a valid churn column on the Preprocessing page first.")
    if ss.bundle is None:
        st.info("**First-time setup:** no saved model was found. Click the button to train (under a minute).")
    label = "🔁 Retrain models" if ss.bundle else "🚀 Train models"
    if st.button(label, type="primary", disabled=not ready):
        bar, msg = st.progress(0.0), st.empty()
        try:
            bundle = tm.train_and_compare(ss.df_clean, ss.target_col, ss.positive_label, test_size=ss.test_size,
                                          progress_callback=lambda p, m: (bar.progress(min(p, 1.0)), msg.write(m)))
            tm.save_bundle(bundle)
            ss.bundle, ss.model_error, ss.bulk_results = bundle, None, None
            st.success(f"Training finished in {bundle['training_seconds']} s. Model saved to models/churn_model.joblib")
        except (pp.PreprocessingError, ValueError) as exc:
            st.error(f"Training failed: {exc}")
        except Exception as exc:  # unexpected problem - show it instead of crashing
            st.error(f"Unexpected error during training: {exc}")
        bar.empty()
        msg.empty()
    if ss.model_error and ss.bundle is None:
        st.error(ss.model_error)
    b = ss.bundle
    if b is None:
        return
    warn = tm.bundle_version_warning(b)
    if warn:
        st.warning(warn)
    best = b["best_model_name"]
    res = b["results"][best]
    st.markdown(f"### ✅ Selected model: **{best}**")
    st.caption(f"Trained {b['trained_at']} on {b['n_train']:,} customers, tested on {b['n_test']:,}. {b['selection_rule']}")
    t = res["test"]
    kpi_row([("Accuracy", f"{t['accuracy']:.3f}", "test set", "navy"), ("Precision", f"{t['precision']:.3f}", "test set", "blue"),
             ("Recall", f"{t['recall']:.3f}", "test set", "teal"), ("F1-score", f"{t['f1']:.3f}", "test set", "teal"),
             ("ROC-AUC", f"{t['roc_auc']:.3f}", "test set", "blue")])
    st.markdown("#### Model comparison")
    comp = b["comparison"]
    st.dataframe(comp.style.format({c: "{:.3f}" for c in comp.columns if c != "Model"})
                 .highlight_max(subset=["CV F1"], color="#C7F1EE"), hide_index=True, width="stretch")
    st.caption("**CV** columns = 5-fold cross-validation inside the training data (used to choose the model). "
               "**Test** columns = unseen customers (final, honest result). **Train** columns are shown only to "
               "detect over-fitting - a big gap between train and test means the model memorised the training data.")
    fig = go.Figure()
    for metric, color in [("Test Precision", config.COLORS["blue"]), ("Test Recall", config.COLORS["teal"]),
                          ("Test F1", config.COLORS["navy"]), ("Test ROC-AUC", config.COLORS["churned"])]:
        fig.add_bar(name=metric.replace("Test ", ""), x=comp["Model"], y=comp[metric], marker_color=color)
    fig.update_layout(barmode="group", yaxis_range=[0, 1])
    st.plotly_chart(eda._style(fig, "Test-set performance by model", 380), width="stretch")

    pick = st.selectbox("Inspect model", list(b["models"].keys()), index=list(b["models"].keys()).index(best))
    r = b["results"][pick]
    a, c = st.columns(2)
    a.plotly_chart(eda.confusion_matrix_fig(r["test"]["confusion_matrix"], [b["negative_label"], b["positive_label"]]),
                   width="stretch")
    c.plotly_chart(eda.roc_fig(b["results"]), width="stretch")
    rep = pd.DataFrame(r["test"]["report"]).T.round(3)
    st.markdown("**Classification report (test set)**")
    st.dataframe(rep, width="stretch")
    tr = r["train"]
    st.markdown("**Train vs test results**")
    st.dataframe(pd.DataFrame({"Metric": ["Accuracy", "Precision", "Recall", "F1", "ROC-AUC"],
                               "Training": [tr[k] for k in ["accuracy", "precision", "recall", "f1", "roc_auc"]],
                               "Testing": [r["test"][k] for k in ["accuracy", "precision", "recall", "f1", "roc_auc"]]})
                 .round(3), hide_index=True, width="stretch")
    st.info(f"**What does {pick} do?** {tm.MODEL_EXPLANATIONS[pick]}")
    st.success(f"**Why {best}?** It achieved the best validation (cross-validated) F1-score, which balances "
               "catching churners (recall) with not raising false alarms (precision). Accuracy alone can be misleading "
               "when far fewer customers churn than stay.")


def input_form(b):
    """Build the single-customer form from the trained model's features."""
    ref, record = b["reference"], {}
    cols = st.columns(3)
    for i, col in enumerate(b["feature_columns"]):
        with cols[i % 3]:
            if col in ref["numeric"]:
                r = ref["numeric"][col]
                lo = 0.0 if r["min"] >= 0 else r["min"] * 2
                if r["is_integer"]:
                    record[col] = st.number_input(col, min_value=int(lo), value=int(round(r["median"])), step=1)
                else:
                    step = max(round((r["max"] - r["min"]) / 200, 2), 0.01)
                    record[col] = st.number_input(col, min_value=float(lo), value=float(round(r["median"], 2)), step=float(step))
            else:
                vals = ref["categorical"][col]["values"]
                record[col] = st.selectbox(col, vals, index=vals.index(ref["categorical"][col]["mode"])
                                           if ref["categorical"][col]["mode"] in vals else 0)
    return record


def page_prediction():
    ss = st.session_state
    page_header("🔮 Churn Prediction", "Predict churn for one customer or for a whole CSV file.")
    if need_model():
        return
    b = ss.bundle
    with st.expander("⚙️ Risk thresholds", expanded=False):
        c1, c2 = st.columns(2)
        ss.low = c1.slider("Low risk below", 0.05, 0.60, float(ss.low), 0.05)
        ss.high = c2.slider("High risk from", 0.30, 0.95, float(ss.high), 0.05)
        if ss.low >= ss.high:
            st.error("The low-risk threshold must be smaller than the high-risk threshold.")
            return
    t1, t2 = st.tabs(["👤 Single customer", "📦 Bulk prediction"])
    with t1:
        with st.form("single"):
            st.caption("Enter the customer's details (defaults are typical values from the training data).")
            record = input_form(b)
            go_btn = st.form_submit_button("Predict churn", type="primary")
        if go_btn:
            res = pr.predict_single(record, b, ss.low, ss.high)
            p = res["probability"]
            a, c = st.columns([1, 1])
            with a:
                gauge = go.Figure(go.Indicator(mode="gauge+number", value=p * 100, number={"suffix": "%"},
                    title={"text": "Churn probability"},
                    gauge={"axis": {"range": [0, 100]}, "bar": {"color": NAVY},
                           "steps": [{"range": [0, ss.low * 100], "color": "#BBF7D0"},
                                     {"range": [ss.low * 100, ss.high * 100], "color": "#FDE68A"},
                                     {"range": [ss.high * 100, 100], "color": "#FECACA"}]}))
                st.plotly_chart(eda._style(gauge, None, 300), width="stretch")
            with c:
                st.markdown(f'<div class="card"><div class="kpi-label">Risk level</div>'
                            f'<span class="badge badge-{res["risk_level"]}">{res["risk_level"]} risk</span>'
                            f'<p style="margin-top:14px">Predicted class: <b>{res["prediction"]}</b> '
                            f'({"likely to churn" if res["is_churn"] else "likely to stay"})</p>'
                            f'<p>Model: {b["best_model_name"]}</p></div>', unsafe_allow_html=True)
                if res["risk_level"] == "High":
                    st.error("High churn risk - consider immediate retention action.")
                elif res["risk_level"] == "Medium":
                    st.warning("Medium churn risk - monitor and consider a light-touch action.")
                else:
                    st.success("Low churn risk.")
            st.markdown("#### Main risk indicators for this customer")
            expl = ex.explain_customer(record, b)
            st.dataframe(expl, hide_index=True, width="stretch")
            st.caption("Risk Change = how many percentage points the churn probability would change if this value "
                       "were replaced by a typical one. " + "These are associations, not proven causes.")
            st.markdown("#### Suggested retention actions")
            for r in rc.recommend_for_customer(record, res["risk_level"], b):
                st.markdown(f"**[{r['Priority']}] {r['Segment']}** - {r['Action']}  \n*Why:* {r['Reason']}")
            st.caption("These are suggestions only. The application does not send emails, offers or notifications.")
    with t2:
        st.markdown("Upload a CSV with the customer columns below. A churn column is **not** required.")
        st.code(", ".join(b["feature_columns"]), language=None)
        st.download_button("⬇️ Download CSV template", csv_bytes(pr.template_dataframe(b)), "prediction_template.csv", "text/csv")
        up = st.file_uploader("Upload customers to score", type=["csv"], key="bulk_upload")
        use_sample = st.button("Use the loaded dataset as a demo")
        df_in = None
        try:
            if up is not None:
                df_in = dl.load_csv(up)
            elif use_sample and ss.df_clean is not None:
                df_in = ss.df_clean.drop(columns=[ss.target_col], errors="ignore")
            if df_in is not None:
                res_df, warns = pr.predict_dataframe(df_in, b, ss.low, ss.high)
                ss.bulk_results = res_df
                for w in warns:
                    st.warning(w)
                st.success(f"Predictions generated for {len(res_df):,} customers.")
        except (dl.DatasetError, pr.PredictionError) as exc:
            st.error(str(exc))
        res_df = ss.bulk_results
        if res_df is not None:
            counts = res_df["Risk_Level"].value_counts()
            kpi_row([("High risk", int(counts.get("High", 0)), "", "red"), ("Medium risk", int(counts.get("Medium", 0)), "", "blue"),
                     ("Low risk", int(counts.get("Low", 0)), "", "teal"),
                     ("Avg probability", f"{res_df['Churn_Probability'].mean() * 100:.1f}%", "", "navy")])
            f1, f2 = st.columns(2)
            levels = f1.multiselect("Risk level", ["High", "Medium", "Low"], default=["High", "Medium", "Low"])
            pmin = f2.slider("Minimum churn probability", 0.0, 1.0, 0.0, 0.05)
            view = res_df[res_df["Risk_Level"].isin(levels) & (res_df["Churn_Probability"] >= pmin)]
            st.dataframe(view.sort_values("Churn_Probability", ascending=False), width="stretch", height=380)
            st.download_button("⬇️ Download predictions (CSV)", csv_bytes(view), "churn_predictions.csv", "text/csv")


def page_factors():
    ss = st.session_state
    page_header("🧠 Churn Factors & Explainability", "Which customer attributes are most associated with churn?")
    if need_model():
        return
    b = ss.bundle
    st.warning(ex.CAUSATION_NOTE)
    dfx = flagged()
    comp = ex.churn_group_comparison(dfx, b["numeric_cols"]) if dfx is not None else pd.DataFrame()
    imp = b["permutation_importance"]
    st.markdown(f"#### Overall importance - {b['best_model_name']} (permutation importance)")
    st.caption("How much the ROC-AUC on test data drops when one feature is shuffled. Works for every model type.")
    fig = px.bar(imp.head(12).iloc[::-1], x="Importance", y="Feature", orientation="h", color_discrete_sequence=[TEAL])
    st.plotly_chart(eda._style(fig, None, 420), width="stretch")
    st.markdown("#### In plain language")
    for line in ex.plain_language_factors(imp, comp, 5):
        st.markdown(f"- {line}")
    st.markdown("#### Model-specific view")
    name = st.selectbox("Model", list(b["models"].keys()), index=list(b["models"].keys()).index(b["best_model_name"]))
    out = ex.builtin_importance(b, name)
    if out["kind"] == "importance":
        st.caption("Tree-based feature importance (higher = used more for splitting).")
        fig = px.bar(out["table"].head(12).iloc[::-1], x="Importance", y="Feature", orientation="h",
                     color_discrete_sequence=[config.COLORS["blue"]])
        st.plotly_chart(eda._style(fig, None, 420), width="stretch")
    elif out["kind"] == "coefficients":
        st.caption("Logistic Regression coefficients on standardised inputs. Positive = higher churn risk, "
                   "negative = lower. Odds ratio above 1 raises odds of churn.")
        tab = out["table"].head(14).iloc[::-1]
        fig = px.bar(tab, x="Coefficient", y="Feature", orientation="h", color="Effect",
                     color_discrete_map={"Raises churn risk": config.COLORS["churned"], "Lowers churn risk": config.COLORS["retained"]})
        st.plotly_chart(eda._style(fig, None, 460), width="stretch")
        st.dataframe(out["table"].round(3).head(20), hide_index=True, width="stretch")
    if not comp.empty:
        st.markdown("#### Churned vs retained customers (facts from the data)")
        st.dataframe(comp, hide_index=True, width="stretch")
    if ss.df_clean is not None and ss.target_col in ss.df_clean.columns and all(c in ss.df_clean.columns for c in b["feature_columns"]):
        st.markdown("#### Explain one customer from the loaded dataset")
        n = st.number_input("Row number", 0, len(ss.df_clean) - 1, 0)
        row = ss.df_clean.iloc[int(n)]
        st.dataframe(ex.explain_customer(row.to_dict(), b, 8), hide_index=True, width="stretch")


def page_recommendations():
    ss = st.session_state
    page_header("💡 Customer Retention Recommendations", "Practical actions linked to each customer's behaviour and risk level.")
    if need_model():
        return
    b = ss.bundle
    source = "Bulk prediction results" if ss.bulk_results is not None else "Loaded dataset"
    if ss.bulk_results is not None and ss.df_clean is not None:
        source = st.radio("Customers to analyse", ["Bulk prediction results", "Loaded dataset"], horizontal=True)
    try:
        if source == "Bulk prediction results":
            preds = ss.bulk_results
        elif ss.df_clean is not None:
            preds, _ = pr.predict_dataframe(ss.df_clean.drop(columns=[ss.target_col], errors="ignore"), b, ss.low, ss.high)
        else:
            st.warning("Load a dataset or run a bulk prediction first.")
            return
    except pr.PredictionError as exc:
        st.error(str(exc))
        return
    if source == "Loaded dataset":
        st.caption("Note: the model was trained on this same data, so probabilities look slightly optimistic. "
                   "For real use, score NEW customers in the bulk-prediction tab.")
    recs = rc.add_recommendations(preds[preds["Risk_Level"] != "Low"].head(2000), b)
    kpi_row([("Customers analysed", f"{len(preds):,}", "", "navy"),
             ("Need action", f"{len(recs):,}", "Medium or High risk (first 2,000)", "red")])
    if not recs.empty:
        seg = recs["Primary_Recommendation"].str.split(":").str[0].value_counts().reset_index()
        seg.columns = ["Segment", "Customers"]
        st.plotly_chart(eda._style(px.bar(seg, x="Customers", y="Segment", orientation="h",
                                          color_discrete_sequence=[TEAL]), "Customers per primary recommendation", 360),
                        width="stretch")
        show = [c for c in recs.columns if c in b["feature_columns"][:0]] or []
        id_cols = [c for c in preds.columns if pp.is_identifier(c, preds[c])][:1]
        st.dataframe(recs[id_cols + ["Churn_Probability", "Risk_Level", "Primary_Recommendation"]]
                     .sort_values("Churn_Probability", ascending=False), width="stretch", height=360, hide_index=True)
    st.markdown("#### Recommendation rules")
    st.dataframe(rc.RULE_TABLE, hide_index=True, width="stretch")
    st.caption("Roles detected in your data: " + (", ".join(f"{k}→{v}" for k, v in rc.map_roles(b).items()) or "none"))
    st.info("These are suggestions only. The application does not send any email, discount or notification.")


def page_reports():
    ss = st.session_state
    page_header("📑 Reports & Downloads", "Export data, predictions, metrics and the churn analysis report.")
    dfx = flagged()
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("#### Data")
        if ss.df_clean is not None:
            st.download_button("⬇️ Cleaned dataset", csv_bytes(ss.df_clean), "cleaned_customers.csv", "text/csv", width="stretch")
        else:
            st.caption("No dataset loaded.")
        if ss.bundle and ss.bulk_results is not None:
            st.download_button("⬇️ Churn prediction results", csv_bytes(ss.bulk_results), "churn_predictions.csv", "text/csv", width="stretch")
        else:
            st.caption("Run a bulk prediction to enable the predictions download.")
    with c2:
        st.markdown("#### Model")
        if ss.bundle:
            st.download_button("⬇️ Model evaluation metrics", csv_bytes(tm.metrics_table(ss.bundle)), "model_metrics.csv", "text/csv", width="stretch")
            rep = reports.build_analysis_report(ss.bundle, dfx, ss.bulk_results)
            st.download_button("⬇️ Customer churn analysis report", csv_bytes(rep), "churn_analysis_report.csv", "text/csv", width="stretch")
        else:
            st.caption("Train a model to enable metric and report downloads.")
    if ss.bundle:
        st.markdown("#### Summary of important churn factors")
        st.dataframe(ss.bundle["permutation_importance"].head(8).round(4), hide_index=True, width="stretch")
        st.markdown("#### Retention recommendations")
        st.dataframe(rc.RULE_TABLE, hide_index=True, width="stretch")
        st.caption(ex.CAUSATION_NOTE)


def page_about():
    page_header("ℹ️ About the Project", config.APP_TITLE)
    st.markdown("""
**Introduction** - Customer churn means a customer stops buying from a business. Winning a new customer usually costs
more than keeping an existing one, so predicting churn early is valuable for e-commerce companies.

**Problem statement** - E-commerce businesses hold large amounts of customer data but often cannot tell which customers
are about to leave or why. This project builds a machine-learning system that predicts churn and suggests retention actions.

**Objectives**
1. Load, validate and clean customer data.
2. Explore behaviour patterns with interactive charts.
3. Train and compare Logistic Regression, Decision Tree and Random Forest models.
4. Predict churn probability for single and multiple customers.
5. Show the factors associated with churn.
6. Recommend practical retention actions.

**Technology stack** - Python, Streamlit, Pandas, NumPy, Matplotlib, Seaborn, Plotly, Scikit-learn, Joblib.

**Algorithms** - Logistic Regression (linear, interpretable), Decision Tree (rule-based), Random Forest (ensemble of trees).
The best model is chosen by cross-validated F1-score.

**Dataset** - The included `sample_customers.csv` is **synthetic** (generated by `data/generate_sample_data.py`).
Results on it demonstrate the method and are not real business findings. Any real CSV with a churn column can be uploaded.

**Limitations**
- Synthetic demo data; real data will behave differently.
- Predictions show association, not causation.
- No time-series modelling; one snapshot per customer.
- Rule-based recommendations are generic and not A/B tested.

**Future enhancements** - Gradient boosting / XGBoost, SHAP explanations, database integration, live e-mail campaigns,
time-based churn modelling, user login and role management.
""")


# ============================================================== main
def main():
    init_state()
    with st.sidebar:
        st.markdown("## 📉 ChurnIQ")
        st.caption("E-Commerce Churn Prediction")
        st.radio("Navigation", PAGES, key="nav", label_visibility="collapsed")
        st.markdown("---")
        ss = st.session_state
        st.caption("**Dataset**")
        st.write(ss.dataset_name or "none loaded")
        st.caption("**Model**")
        st.write(ss.bundle["best_model_name"] if ss.bundle else "not trained yet")
    {"🏠 Home": page_home, "📂 Dataset": page_dataset, "📊 EDA": page_eda, "🧹 Preprocessing": page_preprocessing,
     "🤖 Model Training": page_training, "🔮 Prediction": page_prediction, "🧠 Churn Factors": page_factors,
     "💡 Recommendations": page_recommendations, "📑 Reports": page_reports, "ℹ️ About": page_about}[st.session_state.nav]()


main()
