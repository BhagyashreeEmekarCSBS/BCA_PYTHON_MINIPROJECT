# Viva Explanation (short)

**Problem.** Banks must decide whether to approve loans. We build a system that learns from past applications
(Kaggle Loan Prediction data) to predict approval and shows which applicant features matter most.

**Pipeline.** Upload data → EDA → preprocessing → feature selection → PCA → model comparison → prediction.

**Preprocessing.** Remove duplicates; fill missing numbers with the median and categories with the most frequent value;
scale numbers with StandardScaler; one-hot encode categories; stratified train/test split. Everything is fitted on the
training set only, which prevents data leakage.

**Feature selection** keeps the original columns that matter. We use (1) correlation with the target, (2) SelectKBest with the
ANOVA F-test or mutual information, and (3) Random Forest feature importance. Benefits: simpler, faster, less overfitting,
easier to explain.

**PCA** creates new uncorrelated components ordered by explained variance. It is unsupervised, needs numeric input
(hence scaling and encoding first) and the new features are harder to interpret.

**Models.** Logistic Regression (linear, interpretable), Decision Tree (rules), Random Forest (ensemble of trees).
Each is trained on the original, selected and PCA features with the same split. Metrics: accuracy, precision, recall,
F1 and the confusion matrix. We do not assume dimensionality reduction helps; the table shows the real outcome.

**Why F1 and not only accuracy?** Classes are imbalanced (more approvals than rejections), so a model that always
says "approved" can look accurate. We show a baseline and use precision, recall and F1.

**Prediction.** The saved Joblib bundle contains the same fitted preprocessor, selector/PCA and model, so a new
applicant is transformed exactly like the training data. Inputs are validated, and no prediction is shown if no model
has been trained.

**Limitations.** Small dataset, no fairness analysis, the label is just historic approval (not real default), and the
output is an educational estimate, not a bank decision.

**Likely questions.** Feature selection vs extraction? (selection keeps original columns, PCA builds new ones).
Why scale before PCA? (PCA is variance-based, so large-scale columns would dominate.) What is data leakage?
(using test information during training or preprocessing.) Why one-hot encoding? (models cannot use text categories
and label codes would imply a false order.)
