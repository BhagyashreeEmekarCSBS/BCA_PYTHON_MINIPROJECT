# Credit Risk Assessment using Feature Selection & Reduction

A Streamlit website that analyses loan applicant data, selects important features, applies PCA,
compares Logistic Regression / Decision Tree / Random Forest, and predicts loan approval.
Built for a college mini project. **Predictions are educational estimates, not real bank decisions.**

## Project structure
```
credit-risk-assessment/
├── app.py                      # Streamlit website (8 pages)
├── requirements.txt
├── README.md
├── VIVA_NOTES.md               # short explanation for the viva
├── .streamlit/config.toml      # green & white fintech theme
├── data/                       # put the Kaggle train.csv here (sample_loan_data.csv = synthetic demo)
├── models/                     # trained model is saved here (credit_risk_model.joblib)
└── src/
    ├── preprocessing.py        # cleaning, imputation, encoding, scaling, train/test split
    ├── eda.py                  # charts for the EDA page
    ├── feature_selection.py    # correlation, SelectKBest, Random Forest importance
    ├── dimensionality_reduction.py  # PCA + plots
    ├── model_training.py       # 3 models x 3 feature sets, metrics, comparison plots
    ├── prediction.py           # save/load model bundle, validate inputs, predict
    ├── sample_data.py          # synthetic sample data generator
    └── utils.py                # theme and card helpers
```

## Setup on Windows (Visual Studio Code)
1. **Create the folder** `credit-risk-assessment` (e.g. in Documents) and copy all project files into it.
2. **Open in VS Code**: File → Open Folder → select `credit-risk-assessment`. Open a terminal with Ctrl+` (PowerShell).
3. **Create and activate a virtual environment**
   ```
   python -m venv venv
   venv\Scripts\activate
   ```
   If PowerShell blocks activation, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, then activate again.
   You should see `(venv)` at the start of the prompt.
4. **Install dependencies**
   ```
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
5. **Add the dataset**: download the Kaggle *Loan Prediction* `train.csv` and place it in the `data` folder
   (or upload it from the website). No dataset? Use the built-in sample option on the website.
6. **Run the website**
   ```
   python -m streamlit run app.py
   ```
   The browser opens at http://localhost:8501.

## How to use
Follow the sidebar pages in order: Dataset → EDA → Preprocessing → Feature Selection → PCA →
Machine Learning Models (click *Train*) → Credit Risk Prediction.

## Troubleshooting
| Problem | Fix |
|---|---|
| `'python' is not recognized` | Reinstall Python from python.org and tick **Add Python to PATH**; or try `py -m venv venv`. |
| `streamlit is not recognized` | Always run it as `python -m streamlit run app.py` with the venv activated. |
| `ModuleNotFoundError` | The venv is not active or dependencies are missing: activate it and run `pip install -r requirements.txt`. |
| Page says "No dataset loaded" | Load data on the *Dataset Upload & Preview* page first. |
| "Please run Data Preprocessing first" | Click **Run preprocessing** on the preprocessing page. |
| Prediction page says no trained model | Click **Train and compare models** on the Machine Learning Models page. |
| Port already in use | `python -m streamlit run app.py --server.port 8502` |
| CSV error messages | Check the file is a real CSV with a header row and a 2-class target column (e.g. Loan_Status = Y/N). |
| Charts not updating | Press **R** in the browser or use the menu → Rerun. |

## Notes on correctness
- Preprocessing, feature selection and PCA are fitted on the **training split only** (no data leakage).
- All models and feature sets share the same train/test split.
- Metrics are computed from real predictions on the test set; a majority-class baseline is shown for comparison.
- The sample dataset is synthetic; the website warns whenever it is in use.
