"""UI helpers. Design: 'paper & ink' - warm cream background, thick black borders,
hard offset shadows, square corners, tomato / mustard / plum colours, top navigation."""
import html

import streamlit as st

INK, CREAM, PAPER = "#1C1917", "#FFF8E7", "#FFFDF7"
TOMATO, MUSTARD, PLUM = "#E4572E", "#F4B942", "#6D3B5C"

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&display=swap');
:root { --ink:#1C1917; --cream:#FFF8E7; --paper:#FFFDF7; --tomato:#E4572E; --mustard:#F4B942; --plum:#6D3B5C; --sand:#E9DFC7; }
.stApp { background: var(--cream); background-image: radial-gradient(#E9DFC7 1px, transparent 1px); background-size: 22px 22px; }
[data-testid="stSidebar"], [data-testid="stSidebarCollapsedControl"], [data-testid="collapsedControl"] { display: none !important; }
[data-testid="stHeader"] { background: transparent; }
.block-container, [data-testid="stMainBlockContainer"] { max-width: 1180px; padding-top: 1.2rem; }
h1, h2, h3, h4 { font-family: 'Space Grotesk', 'Arial Black', sans-serif !important; color: var(--ink); letter-spacing: -.01em; }
h3 { text-transform: uppercase; font-size: 1.05rem !important; border-bottom: 3px solid var(--ink); padding-bottom: .25rem; display: inline-block; }

/* brand bar */
.brand { display:flex; align-items:center; gap:14px; border:3px solid var(--ink); background:var(--paper);
  padding:.55rem .9rem; box-shadow:6px 6px 0 var(--ink); margin-bottom:1rem; }
.brand .logo { background:var(--ink); color:var(--mustard); font-family:'Space Grotesk',sans-serif; font-weight:700;
  font-size:1.3rem; padding:.2rem .6rem; }
.brand .name { font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:1.15rem; letter-spacing:.06em; }
.brand .sub { color:#78716C; font-size:.78rem; }
.brand .tag { margin-left:auto; background:var(--tomato); color:#fff; font-weight:700; font-size:.7rem;
  padding:.25rem .6rem; border:2px solid var(--ink); letter-spacing:.08em; }

/* top navigation (radio with key "nav") */
.st-key-nav [role="radiogroup"] { gap:0; flex-wrap:wrap; }
.st-key-nav [role="radiogroup"] > label { border:2px solid var(--ink); margin:0 -2px -2px 0 !important; padding:.35rem .85rem;
  background:var(--paper); cursor:pointer; }
.st-key-nav [role="radiogroup"] > label > div:first-child { display:none; }
.st-key-nav [role="radiogroup"] > label p { font-weight:700; font-size:.82rem; text-transform:uppercase; letter-spacing:.04em; }
.st-key-nav [role="radiogroup"] > label:has(input:checked) { background:var(--ink); }
.st-key-nav [role="radiogroup"] > label:has(input:checked) p { color:var(--mustard) !important; }
.st-key-nav [role="radiogroup"] > label:hover { background:var(--mustard); }
.st-key-nav [role="radiogroup"] > label:has(input:checked):hover { background:var(--ink); }

/* stepper */
.stepper { display:flex; gap:0; margin:.9rem 0 1.2rem 0; flex-wrap:wrap; }
.stepper .s { border:2px solid var(--ink); margin-right:-2px; padding:.2rem .7rem; font-size:.72rem; font-weight:700;
  background:var(--paper); color:#A8A29E; letter-spacing:.06em; }
.stepper .s.done { background:var(--tomato); color:#fff; }

/* page header */
.ph { margin: .4rem 0 1.4rem 0; border-bottom: 6px solid var(--ink); padding-bottom: .8rem; }
.ph .num { display:inline-block; background:var(--mustard); border:2px solid var(--ink); font-weight:700;
  font-size:.75rem; padding:.1rem .55rem; letter-spacing:.1em; box-shadow:3px 3px 0 var(--ink); }
.ph h1 { font-size:2.3rem; text-transform:uppercase; margin:.5rem 0 .2rem 0; line-height:1.05; }
.ph p { color:#57534E; margin:0; }

/* cards */
.kpi { border:3px solid var(--ink); box-shadow:5px 5px 0 var(--ink); padding:.8rem 1rem; margin-bottom:.9rem; }
.kpi .label { font-size:.72rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; }
.kpi .value { font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:2.2rem; line-height:1.15; }
.kpi .sub { font-size:.72rem; opacity:.75; }
.card { background:var(--paper); border:3px solid var(--ink); box-shadow:5px 5px 0 var(--ink); padding:1rem 1.2rem; height:100%; }
.card h4 { margin:0 0 .4rem 0; text-transform:uppercase; font-size:.95rem; }
.explain { background:#FFF1C9; border:2px solid var(--ink); box-shadow:3px 3px 0 var(--ink); padding:.7rem 1rem;
  margin:.4rem 0 1.4rem 0; font-size:.85rem; }
.explain .t { background:var(--ink); color:var(--mustard); font-weight:700; font-size:.65rem; padding:.1rem .45rem;
  letter-spacing:.1em; margin-right:.5rem; }
.hero { background:var(--ink); color:var(--cream); border:3px solid var(--ink); box-shadow:8px 8px 0 var(--tomato);
  padding:1.6rem 1.8rem; margin-bottom:1.6rem; }
.hero .q { font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:2rem; color:var(--mustard); }
.hero p { margin:.4rem 0 0 0; color:#E7E5E4; font-size:.9rem; }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(230px,1fr)); gap:16px; margin:.6rem 0 1.4rem 0; }
.step { background:var(--paper); border:2px solid var(--ink); padding:.8rem 1rem; box-shadow:4px 4px 0 var(--ink); }
.step .n { font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:2rem; color:var(--tomato); line-height:1; }
.step .h { font-weight:700; text-transform:uppercase; font-size:.82rem; margin:.3rem 0 .2rem 0; }
.step .d { font-size:.78rem; color:#57534E; }
.result { border:3px solid var(--ink); box-shadow:8px 8px 0 var(--ink); padding:1.2rem 1.6rem; margin-top:1rem; }
.result.yes { background:var(--ink); color:var(--cream); box-shadow:8px 8px 0 var(--mustard); }
.result.yes .big { color:var(--mustard); }
.result.no { background:var(--tomato); color:#fff; }
.result .small { font-size:.72rem; letter-spacing:.12em; font-weight:700; opacity:.85; }
.result .big { font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:2.4rem; line-height:1.1; }

/* buttons */
.stButton > button, .stFormSubmitButton > button, .stDownloadButton > button {
  background:var(--mustard); color:var(--ink); border:3px solid var(--ink); border-radius:0;
  box-shadow:4px 4px 0 var(--ink); font-weight:700; text-transform:uppercase; letter-spacing:.05em; padding:.45rem 1.2rem; }
.stButton > button p, .stFormSubmitButton > button p { color:var(--ink); font-weight:700; }
.stButton > button:hover, .stFormSubmitButton > button:hover { background:var(--tomato); color:#fff; transform:translate(3px,3px); box-shadow:1px 1px 0 var(--ink); border-color:var(--ink); }
.stButton > button:hover p, .stFormSubmitButton > button:hover p { color:#fff; }
[data-baseweb="input"], [data-baseweb="select"] > div, [data-baseweb="base-input"] { border-radius:0 !important; }
[data-testid="stDataFrame"] { border:2px solid var(--ink); }
</style>
"""

_TONES = ["#F4B942", "#FFFDF7", "#F7BBA8", "#D9C2D3"]
_counter = {"i": 0}


def apply_theme():
    st.markdown(CSS, unsafe_allow_html=True)


def brand_bar():
    st.markdown('<div class="brand"><div class="logo">CR</div><div><div class="name">CREDIT RISK LAB</div>'
                '<div class="sub">Feature Selection · PCA · Loan Approval Prediction</div></div>'
                '<div class="tag">COLLEGE MINI PROJECT</div></div>', unsafe_allow_html=True)


def stepper(items):
    """items: list of (label, done_bool)."""
    parts = "".join(f'<div class="s {"done" if done else ""}">{html.escape(l)}</div>' for l, done in items)
    st.markdown(f'<div class="stepper">{parts}</div>', unsafe_allow_html=True)


def page_header(title, subtitle=""):
    _counter["i"] = 0                      # restart the card colour cycle on every page
    nav = str(st.session_state.get("nav", "01"))
    st.markdown(f'<div class="ph"><span class="num">{html.escape(nav[:2])} / 08</span>'
                f'<h1>{html.escape(title)}</h1><p>{html.escape(subtitle)}</p></div>', unsafe_allow_html=True)


def metric_card(label, value, sub=""):
    tone = _TONES[_counter["i"] % len(_TONES)]
    _counter["i"] += 1
    st.markdown(f'<div class="kpi" style="background:{tone}"><div class="label">{html.escape(str(label))}</div>'
                f'<div class="value">{html.escape(str(value))}</div><div class="sub">{html.escape(str(sub))}</div></div>',
                unsafe_allow_html=True)


def explain(text):
    """Short note box shown under charts and tables."""
    st.markdown(f'<div class="explain"><span class="t">NOTE</span>{html.escape(text)}</div>', unsafe_allow_html=True)


def card(title, text):
    st.markdown(f'<div class="card"><h4>{html.escape(title)}</h4><div>{html.escape(text)}</div></div>',
                unsafe_allow_html=True)


def hero(question, text):
    st.markdown(f'<div class="hero"><div class="q">{html.escape(question)}</div><p>{html.escape(text)}</p></div>',
                unsafe_allow_html=True)


def steps_grid(steps):
    """steps: list of (number, heading, description)."""
    cells = "".join(f'<div class="step"><div class="n">{html.escape(n)}</div><div class="h">{html.escape(h)}</div>'
                    f'<div class="d">{html.escape(d)}</div></div>' for n, h, d in steps)
    st.markdown(f'<div class="grid">{cells}</div>', unsafe_allow_html=True)


def result_card(small, big, detail, positive):
    st.markdown(f'<div class="result {"yes" if positive else "no"}"><div class="small">{html.escape(small)}</div>'
                f'<div class="big">{html.escape(big)}</div><div>{html.escape(detail)}</div></div>',
                unsafe_allow_html=True)
