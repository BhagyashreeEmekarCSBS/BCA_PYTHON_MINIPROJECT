"""Save/load the trained model bundle and make predictions for a single applicant."""
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from src.preprocessing import POSITIVE_WORDS, normalize


def build_bundle(prepared, model, model_name, feature_set, selected_features, pca, metrics, source, is_sample):
    """Everything needed to predict later: the SAME fitted preprocessor + selector/PCA + model."""
    names = prepared["feature_names"]
    selected_idx = [names.index(f) for f in selected_features] if feature_set == "Selected features" else None
    return {
        "model": model, "model_name": model_name, "feature_set": feature_set,
        "preprocessor": prepared["preprocessor"], "selected_idx": selected_idx,
        "pca": pca if feature_set == "PCA features" else None,
        "label_encoder": prepared["label_encoder"], "class_names": prepared["class_names"],
        "pos_label": prepared["pos_label"], "pos_index": prepared["pos_index"],
        "numeric_cols": prepared["numeric_cols"], "categorical_cols": prepared["categorical_cols"],
        "form_spec": prepared["form_spec"], "target": prepared["target"],
        "metrics": metrics, "source": source, "is_sample": is_sample,
    }


def save_bundle(bundle, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, path)


def load_bundle(path):
    """Return the saved bundle or None if the file is missing/unreadable."""
    if not Path(path).exists():
        return None
    try:
        return joblib.load(path)
    except Exception:
        return None


def validate_inputs(inputs, bundle):
    """Return a list of readable error messages (empty list = valid)."""
    errors = []
    for col in bundle["numeric_cols"]:
        try:
            v = float(inputs.get(col))
        except (TypeError, ValueError):
            errors.append(f"{col}: please enter a valid number.")
            continue
        if not np.isfinite(v):
            errors.append(f"{col}: value must be a finite number.")
        elif v < 0:
            errors.append(f"{col}: value cannot be negative.")
        else:
            key = normalize(col)
            if key in ("applicantincome", "loanamount") and v <= 0:
                errors.append(f"{col}: must be greater than 0.")
            if "term" in key and v <= 0:
                errors.append(f"{col}: must be greater than 0.")
    for col in bundle["categorical_cols"]:
        if inputs.get(col) not in bundle["form_spec"][col]["options"]:
            errors.append(f"{col}: please choose one of the listed options.")
    return errors


def predict_one(bundle, inputs):
    """Predict one applicant. Returns dict with label, probability and risk category."""
    cols = bundle["numeric_cols"] + bundle["categorical_cols"]
    row = pd.DataFrame([{c: inputs.get(c, np.nan) for c in cols}], columns=cols)
    for c in bundle["numeric_cols"]:
        row[c] = pd.to_numeric(row[c], errors="coerce")
    X = bundle["preprocessor"].transform(row)           # same fitted preprocessing
    if bundle["selected_idx"] is not None:
        X = X[:, bundle["selected_idx"]]
    if bundle["pca"] is not None:
        X = bundle["pca"].transform(X)
    model = bundle["model"]
    pred_idx = int(model.predict(X)[0])
    label = bundle["label_encoder"].inverse_transform([pred_idx])[0]
    proba = model.predict_proba(X)[0]
    p_pos = float(proba[list(model.classes_).index(bundle["pos_index"])])
    approval_like = str(bundle["pos_label"]).strip().lower() in POSITIVE_WORDS
    risk = None
    if approval_like:
        risk = "Low risk" if p_pos >= 0.70 else ("Medium risk" if p_pos >= 0.40 else "High risk")
    return {"label": label, "p_positive": p_pos, "risk": risk, "is_positive": pred_idx == bundle["pos_index"]}
