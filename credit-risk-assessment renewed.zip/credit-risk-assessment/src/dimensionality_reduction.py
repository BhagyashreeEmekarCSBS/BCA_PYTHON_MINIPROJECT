"""PCA helpers. PCA is fitted on training data only."""
import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA

from src.eda import INK, MUSTARD, PALETTE, TOMATO


def fit_pca(X_train_p, X_test_p, mode="components", n_components=2, variance_threshold=0.95, random_state=42):
    """Fit PCA on the training set. mode = 'components' or 'variance'.

    The input is the preprocessed data: numerical columns are already standardized and
    categorical columns are one-hot encoded (0/1), so PCA can be applied to it safely."""
    n_features = X_train_p.shape[1]
    max_components = min(X_train_p.shape[0], n_features)
    full = PCA(n_components=max_components, random_state=random_state).fit(X_train_p)
    evr = full.explained_variance_ratio_
    cumulative = np.cumsum(evr)
    if mode == "variance":
        n = int(np.searchsorted(cumulative, variance_threshold - 1e-12) + 1)
    else:
        n = int(n_components)
    n = max(1, min(n, max_components))
    pca = PCA(n_components=n, random_state=random_state).fit(X_train_p)
    return {"model": pca, "full": full, "n_components": n, "n_original": n_features,
            "evr": evr, "cumulative": cumulative,
            "X_train": pca.transform(X_train_p), "X_test": pca.transform(X_test_p),
            "scatter_2d": full.transform(X_train_p)[:, :2],
            "variance_kept": float(cumulative[n - 1])}


def plot_explained_variance(evr, cumulative, threshold=None, max_show=20):
    k = min(len(evr), max_show)
    x = np.arange(1, k + 1)
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    ax.bar(x, evr[:k] * 100, color=MUSTARD, edgecolor=INK, linewidth=1.5, label="Individual explained variance")
    ax.plot(x, cumulative[:k] * 100, color=TOMATO, marker="s", markeredgecolor=INK, linewidth=2.2,
            label="Cumulative explained variance")
    if threshold:
        ax.axhline(threshold * 100, color=INK, linestyle="--", label=f"Target {threshold:.0%}")
    ax.set_title("EXPLAINED VARIANCE BY PRINCIPAL COMPONENT", fontsize=11, fontweight="bold", color=INK, loc="left")
    ax.set_xlabel("Principal component")
    ax.set_ylabel("Explained variance (%)")
    ax.set_xticks(x)
    ax.legend(frameon=True, edgecolor=INK)
    fig.tight_layout()
    return fig

def plot_pca_scatter(coords_2d, y, class_names):
    fig, ax = plt.subplots(figsize=(6.5, 5))
    y = np.asarray(y)
    for idx, name in enumerate(class_names):
        mask = y == idx
        ax.scatter(coords_2d[mask, 0], coords_2d[mask, 1], s=34, alpha=.85, color=PALETTE[idx % len(PALETTE)],
                   edgecolor=INK, linewidth=.6, label=str(name))
    ax.set_title("PCA: FIRST TWO PRINCIPAL COMPONENTS (TRAINING DATA)", fontsize=11, fontweight="bold", color=INK, loc="left")
    ax.set_xlabel("Principal Component 1")
    ax.set_ylabel("Principal Component 2")
    ax.legend(title="Target class", frameon=True, edgecolor=INK)
    fig.tight_layout()
    return fig