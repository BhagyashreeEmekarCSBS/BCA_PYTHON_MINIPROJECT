"""Train and compare classifiers on three feature sets using the SAME train/test split."""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.tree import DecisionTreeClassifier

from src.eda import CMAP_SEQ, INK, MUSTARD, TOMATO

METRICS = ["Accuracy", "Precision", "Recall", "F1-Score"]


def get_models(random_state=42):
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=random_state),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=random_state),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=random_state),
    }


def evaluate_all(feature_sets, y_train, y_test, pos_index, random_state=42):
    """feature_sets: {name: (X_train, X_test)} as numpy arrays. Returns table, fitted models, confusion matrices."""
    rows, fitted, cms = [], {}, {}
    for fs_name, (Xtr, Xte) in feature_sets.items():
        for m_name, model in get_models(random_state).items():
            model.fit(Xtr, y_train)
            pred = model.predict(Xte)
            rows.append({
                "Feature Set": fs_name, "Model": m_name, "Features Used": Xtr.shape[1],
                "Accuracy": accuracy_score(y_test, pred),
                "Precision": precision_score(y_test, pred, pos_label=pos_index, zero_division=0),
                "Recall": recall_score(y_test, pred, pos_label=pos_index, zero_division=0),
                "F1-Score": f1_score(y_test, pred, pos_label=pos_index, zero_division=0),
            })
            fitted[(m_name, fs_name)] = model
            cms[(m_name, fs_name)] = confusion_matrix(y_test, pred, labels=sorted(np.unique(y_train)))
    return pd.DataFrame(rows), fitted, cms


def majority_baseline(y_train, y_test):
    """Accuracy of always predicting the most common training class (a sanity-check baseline)."""
    majority = y_train.value_counts().idxmax()
    return float((y_test == majority).mean())


def plot_comparison(table, metric):
    fig, ax = plt.subplots(figsize=(8, 4.5))
    sns.barplot(data=table, x="Model", y=metric, hue="Feature Set",
                palette=[INK, TOMATO, MUSTARD][:table["Feature Set"].nunique()], ax=ax,
                edgecolor=INK, linewidth=1.5)
    ax.set_ylim(0, 1.08)
    for container in ax.containers:
        ax.bar_label(container, fmt="%.2f", fontsize=8, fontweight="bold")
    ax.set_title(f"MODEL COMPARISON BY {metric.upper()}", fontsize=11, fontweight="bold", color=INK, loc="left")
    ax.set_xlabel("Model")
    ax.set_ylabel(metric)
    ax.legend(title="Feature set", fontsize=8, frameon=True, edgecolor=INK, loc="lower right")
    fig.tight_layout()
    return fig

def plot_confusion_matrix(cm, class_names, title):
    fig, ax = plt.subplots(figsize=(4.5, 3.8))
    sns.heatmap(cm, annot=True, fmt="d", cmap=CMAP_SEQ, cbar=False, ax=ax, linewidths=2, linecolor=INK,
                xticklabels=class_names, yticklabels=class_names, annot_kws={"fontweight": "bold", "fontsize": 13})
    ax.grid(False)
    ax.set_title(title.upper(), fontsize=10, fontweight="bold", color=INK, loc="left")
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("Actual class")
    fig.tight_layout()
    return fig