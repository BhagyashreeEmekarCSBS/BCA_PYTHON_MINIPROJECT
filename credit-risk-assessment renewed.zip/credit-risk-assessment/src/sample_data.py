"""Synthetic SAMPLE loan data (same columns as the Kaggle Loan Prediction dataset).

IMPORTANT: this data is randomly generated for testing the website only.
It is NOT real banking data, so results on it must not be treated as real.
"""
import numpy as np
import pandas as pd


def generate_sample_data(n=614, seed=42):
    rng = np.random.default_rng(seed)
    gender = rng.choice(["Male", "Female"], n, p=[0.8, 0.2])
    married = rng.choice(["Yes", "No"], n, p=[0.65, 0.35])
    dependents = rng.choice(["0", "1", "2", "3+"], n, p=[0.57, 0.17, 0.17, 0.09])
    education = rng.choice(["Graduate", "Not Graduate"], n, p=[0.78, 0.22])
    self_employed = rng.choice(["No", "Yes"], n, p=[0.86, 0.14])
    applicant_income = np.round(rng.lognormal(8.5, 0.55, n)).astype(int)
    coapplicant_income = np.where(rng.random(n) < 0.4, 0, np.round(rng.lognormal(7.6, 0.7, n))).astype(int)
    loan_amount = np.round(np.clip((applicant_income + coapplicant_income) / 40 * rng.uniform(0.6, 1.8, n), 9, 700))
    term = rng.choice([360, 180, 480, 300, 120, 84], n, p=[0.85, 0.07, 0.03, 0.02, 0.02, 0.01]).astype(float)
    credit_history = rng.choice([1.0, 0.0], n, p=[0.84, 0.16])
    area = rng.choice(["Semiurban", "Urban", "Rural"], n, p=[0.38, 0.33, 0.29])

    # Made-up rule + randomness used only to create a label for the demo data
    logit = (-2.2 + 3.6 * credit_history + 0.4 * (education == "Graduate") + 0.3 * (area == "Semiurban")
             + 0.2 * (married == "Yes") - 0.004 * (loan_amount - 130))
    prob = 1 / (1 + np.exp(-logit))
    status = np.where(rng.random(n) < prob, "Y", "N")

    df = pd.DataFrame({
        "Loan_ID": [f"LP{1000 + i:06d}" for i in range(n)],
        "Gender": gender, "Married": married, "Dependents": dependents, "Education": education,
        "Self_Employed": self_employed, "ApplicantIncome": applicant_income,
        "CoapplicantIncome": coapplicant_income, "LoanAmount": loan_amount, "Loan_Amount_Term": term,
        "Credit_History": credit_history, "Property_Area": area, "Loan_Status": status,
    })
    # Add realistic missing values
    for col, rate in [("Gender", .02), ("Married", .01), ("Dependents", .02), ("Self_Employed", .05),
                      ("LoanAmount", .04), ("Loan_Amount_Term", .02), ("Credit_History", .08)]:
        df.loc[rng.random(n) < rate, col] = np.nan
    # A few duplicate rows so the duplicate-handling step has something to show
    df = pd.concat([df, df.sample(5, random_state=seed)], ignore_index=True)
    return df


if __name__ == "__main__":
    generate_sample_data().to_csv("data/sample_loan_data.csv", index=False)
    print("Saved data/sample_loan_data.csv")
