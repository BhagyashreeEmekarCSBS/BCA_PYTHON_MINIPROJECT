"""Exploratory Data Analysis plots. Every function returns a Matplotlib figure (or None).
Chart style: cream paper, thick ink borders, tomato / mustard / plum colours."""
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

from src.preprocessing import normalize

INK, PAPER, SAND = "#1C1917", "#FFFDF7", "#E9DFC7"
TOMATO, MUSTARD, PLUM = "#E4572E", "#F4B942", "#6D3B5C"
PALETTE = [TOMATO, MUSTARD, PLUM, INK]
CMAP_SEQ = LinearSegmentedColormap.from_list("paper_tomato", [PAPER, MUSTARD, TOMATO])
CMAP_DIV = LinearSegmentedColormap.from_list("plum_tomato", [PLUM, PAPER, TOMATO])
BAR = {"edgecolor": INK, "linewidth": 1.6}

sns.set_theme(style="ticks", rc={
    "axes.facecolor": PAPER, "figure.facecolor": PAPER, "savefig.facecolor": PAPER,
    "axes.edgecolor": INK, "axes.linewidth": 1.8, "axes.grid": True, "grid.color": SAND,
    "axes.axisbelow": True, "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": INK, "ytick.color": INK, "font.family": "monospace"})


def find_col(df, keywords):
    """Find a column whose normalized name equals (or then contains) one of the keywords."""
    names = {c: normalize(c) for c in df.columns}
    for k in keywords:
        for c, n in names.items():
            if n == normalize(k):
                return c
    for k in keywords:
        for c, n in names.items():
            if normalize(k) in n:
                return c
    return None


def _finish(fig, ax, title, xlabel, ylabel):
    ax.set_title(title.upper(), fontsize=11, fontweight="bold", color=INK, loc="left")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    fig.tight_layout()
    return fig


def plot_target_distribution(df, target):
    data = df[target].dropna().astype(str)
    order = sorted(data.unique())
    fig, ax = plt.subplots(figsize=(6, 4))
    sns.countplot(x=data, hue=data, order=order, hue_order=order, palette=PALETTE[:len(order)],
                  legend=False, ax=ax, **BAR)
    for container in ax.containers:
        ax.bar_label(container, fontweight="bold")
    return _finish(fig, ax, "Loan Approval vs Rejection", f"{target} (class)", "Number of applicants")


def plot_distribution(df, col, title, xlabel):
    data = df[col].dropna()
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.histplot(data, bins=30, kde=True, color=MUSTARD, edgecolor=INK, line_kws={"color": TOMATO, "linewidth": 2.2}, ax=ax)
    return _finish(fig, ax, title, xlabel, "Number of applicants")


def plot_category_vs_target(df, cat_col, target, title):
    d = df[[cat_col, target]].dropna().astype(str)
    order = sorted(d[target].unique())
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.countplot(data=d, x=cat_col, hue=target, hue_order=order, palette=PALETTE[:len(order)], ax=ax, **BAR)
    for container in ax.containers:
        ax.bar_label(container, fontweight="bold")
    ax.legend(title=target, frameon=True, edgecolor=INK)
    return _finish(fig, ax, title, cat_col, "Number of applicants")


def plot_correlation_heatmap(df, numeric_cols):
    if len(numeric_cols) < 2:
        return None
    corr = df[numeric_cols].corr()
    fig, ax = plt.subplots(figsize=(7, 5.5))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap=CMAP_DIV, vmin=-1, vmax=1, square=True,
                linewidths=1.5, linecolor=INK, ax=ax)
    ax.grid(False)
    return _finish(fig, ax, "Correlation Heatmap (Numerical Features)", "Feature", "Feature")


def plot_missing(df):
    missing = df.isna().sum()
    missing = missing[missing > 0].sort_values(ascending=False)
    if missing.empty:
        return None
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.barplot(x=missing.values, y=missing.index, color=TOMATO, ax=ax, **BAR)
    for container in ax.containers:
        ax.bar_label(container, fontweight="bold")
    return _finish(fig, ax, "Missing Values per Column", "Number of missing values", "Column")
