"""Feature selection: correlation, SelectKBest and Random Forest importance.
All methods are fitted on TRAINING data only to avoid data leakage."""
from functools import partial

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif

from src.eda import INK, SAND, TOMATO

SCORE_METHODS = {"ANOVA F-test (f_classif)": f_classif,
                 "Mutual Information (mutual_info_classif)": mutual_info_classif}


def correlation_analysis(X_train_p, y_train):
    """Correlation of each processed feature with the target (training data)."""
    corr = X_train_p.apply(lambda c: c.corr(y_train)).fillna(0.0)
    out = pd.DataFrame({"Feature": corr.index, "Correlation": corr.values, "Abs correlation": corr.abs().values})
    return out.sort_values("Abs correlation", ascending=False).reset_index(drop=True)


def high_correlation_pairs(X_train_p, threshold=0.8):
    """Feature pairs that are almost duplicates of each other (redundancy)."""
    corr = X_train_p.corr().fillna(0.0)
    rows = []
    cols = list(corr.columns)
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            if abs(corr.iloc[i, j]) >= threshold:
                rows.append({"Feature A": cols[i], "Feature B": cols[j], "Correlation": round(corr.iloc[i, j], 3)})
    return pd.DataFrame(rows, columns=["Feature A", "Feature B", "Correlation"])


def select_k_best(X_train_p, y_train, k, method="ANOVA F-test (f_classif)", random_state=42):
    score_func = SCORE_METHODS[method]
    if score_func is mutual_info_classif:
        score_func = partial(mutual_info_classif, random_state=random_state)
    selector = SelectKBest(score_func=score_func, k=k).fit(X_train_p, y_train)
    scores = np.nan_to_num(selector.scores_)
    table = pd.DataFrame({"Feature": X_train_p.columns, "Score": scores, "Selected": selector.get_support()})
    return table.sort_values("Score", ascending=False).reset_index(drop=True)


def random_forest_importance(X_train_p, y_train, k, random_state=42):
    rf = RandomForestClassifier(n_estimators=200, random_state=random_state).fit(X_train_p, y_train)
    table = pd.DataFrame({"Feature": X_train_p.columns, "Importance": rf.feature_importances_})
    table = table.sort_values("Importance", ascending=False).reset_index(drop=True)
    table["Selected"] = table.index < k
    return table


def plot_scores(table, value_col, title, xlabel, top_n=15):
    """Horizontal bar chart; selected features are tomato, the rest sand."""
    top = table.head(top_n).iloc[::-1]
    colors = [TOMATO if s else SAND for s in top["Selected"]] if "Selected" in top else [TOMATO] * len(top)
    fig, ax = plt.subplots(figsize=(7, max(3, 0.35 * len(top) + 1)))
    ax.barh(top["Feature"], top[value_col], color=colors, edgecolor=INK, linewidth=1.5)
    ax.set_title(title.upper(), fontsize=11, fontweight="bold", color=INK, loc="left")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Feature")
    fig.tight_layout()
    return fig