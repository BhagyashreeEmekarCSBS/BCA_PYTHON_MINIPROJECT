"""Data cleaning, column detection, encoding, scaling and train/test split."""
import re
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler

TARGET_CANDIDATES = ["loan_status", "loan status", "status", "target", "approved", "loan_approved", "label", "class"]
POSITIVE_WORDS = {"y", "yes", "1", "approved", "approve", "true", "good", "paid", "fully paid"}
EXPECTED_COLUMNS = ["Gender", "Married", "Dependents", "Education", "Self_Employed", "ApplicantIncome",
                    "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term", "Credit_History",
                    "Property_Area", "Loan_Status"]


class DataError(Exception):
    """Raised with a user-friendly message when the data cannot be used."""


def is_text(series):
    """True for text columns (works for both old 'object' and new pandas 'str' dtypes)."""
    return pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)


def normalize(name):
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def read_csv_safely(file_or_path):
    """Read a CSV and convert common problems into readable errors."""
    last_error = None
    for encoding in ("utf-8", "latin-1"):
        try:
            if hasattr(file_or_path, "seek"):
                file_or_path.seek(0)
            df = pd.read_csv(file_or_path, encoding=encoding)
            break
        except UnicodeDecodeError as e:
            last_error = e
        except pd.errors.EmptyDataError:
            raise DataError("The file is empty. Please upload a CSV that contains data.")
        except pd.errors.ParserError as e:
            raise DataError(f"The file could not be parsed as a CSV: {e}")
        except Exception as e:  # any other read problem
            raise DataError(f"Could not read the file as a CSV: {e}")
    else:
        raise DataError(f"Could not decode the file: {last_error}")
    if df.shape[0] == 0 or df.shape[1] < 2:
        raise DataError("The CSV needs at least 2 columns and 1 row.")
    df.columns = [str(c).strip() for c in df.columns]
    return df


def missing_expected_columns(df):
    present = {normalize(c) for c in df.columns}
    return [c for c in EXPECTED_COLUMNS if normalize(c) not in present]


def detect_target(df):
    """Guess the target column: known names first, else a binary last column."""
    lookup = {str(c).lower().strip(): c for c in df.columns}
    for name in TARGET_CANDIDATES:
        if name in lookup:
            return lookup[name]
    last = df.columns[-1]
    if df[last].dropna().nunique() == 2:
        return last
    return None


def guess_positive_label(classes):
    """Pick which class means 'approved' (e.g. Y, Yes, 1). Falls back to the last class."""
    for c in classes:
        if str(c).strip().lower() in POSITIVE_WORDS:
            return c
    return classes[-1]


def get_id_columns(df, target):
    ids = []
    for c in df.columns:
        if c == target:
            continue
        n = normalize(c)
        is_text_col = is_text(df[c])
        looks_like_id = is_text_col and (n == "id" or n.endswith("id"))
        unique_text = is_text_col and len(df) > 20 and df[c].nunique() > 0.95 * max(df[c].notna().sum(), 1)
        if looks_like_id or unique_text:
            ids.append(c)
    return ids


def clean_data(df, target):
    """Strip text, drop exact duplicates and rows with a missing target."""
    d = df.copy()
    for c in d.columns:
        if is_text(d[c]):
            d[c] = d[c].map(lambda v: v.strip() if isinstance(v, str) else v).replace("", np.nan)
    before = len(d)
    d = d.drop_duplicates()
    duplicates_removed = before - len(d)
    n = len(d)
    d = d.dropna(subset=[target])
    missing_target_removed = n - len(d)
    return d.reset_index(drop=True), {"duplicates_removed": duplicates_removed,
                                      "missing_target_removed": missing_target_removed}


def identify_columns(df, target):
    """Return (numeric_cols, categorical_cols, dropped_cols_with_reason)."""
    dropped = {c: "ID-like column (not useful for prediction)" for c in get_id_columns(df, target)}
    for c in df.columns:
        if c != target and c not in dropped and df[c].isna().all():
            dropped[c] = "column is completely empty"
    features = [c for c in df.columns if c != target and c not in dropped]
    numeric = [c for c in features if pd.api.types.is_numeric_dtype(df[c])]
    categorical = [c for c in features if c not in numeric]
    return numeric, categorical, dropped


def build_preprocessor(numeric, categorical):
    """Impute + scale numbers; impute + one-hot encode categories."""
    steps = []
    if numeric:
        steps.append(("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                                       ("scaler", StandardScaler())]), numeric))
    if categorical:
        steps.append(("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                                       ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]),
                      categorical))
    return ColumnTransformer(steps)


def prepare_data(df, target, test_size=0.2, random_state=42):
    """Full preprocessing. The preprocessor is fitted ONLY on the training split (no leakage)."""
    if target not in df.columns:
        raise DataError(f"Target column '{target}' was not found in the dataset.")
    d, report = clean_data(df, target)
    if len(d) < 30:
        raise DataError(f"Only {len(d)} usable rows remain after cleaning. At least 30 are needed.")
    classes_raw = d[target].astype(str)
    if classes_raw.nunique() != 2:
        raise DataError(f"The target '{target}' has {classes_raw.nunique()} distinct values. "
                        "This project supports binary targets (e.g. Approved / Rejected).")
    if classes_raw.value_counts().min() < 5:
        raise DataError("One target class has fewer than 5 rows, so a reliable train/test split is impossible.")

    numeric, categorical, dropped = identify_columns(d, target)
    if not numeric and not categorical:
        raise DataError("No usable feature columns were found.")
    X = d[numeric + categorical].copy()
    for c in categorical:  # make categories plain strings, keep NaN as missing
        X[c] = X[c].map(lambda v: str(v) if pd.notna(v) else np.nan)
    for c in numeric:
        X[c] = pd.to_numeric(X[c], errors="coerce")

    le = LabelEncoder()
    y = pd.Series(le.fit_transform(classes_raw), index=d.index, name=target)
    class_names = list(le.classes_)
    pos_label = guess_positive_label(class_names)
    pos_index = class_names.index(pos_label)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y)

    preprocessor = build_preprocessor(numeric, categorical)
    Xtr = preprocessor.fit_transform(X_train)   # fit on TRAIN only
    Xte = preprocessor.transform(X_test)        # only transform TEST
    feature_names = [n.split("__", 1)[1] for n in preprocessor.get_feature_names_out()]
    X_train_p = pd.DataFrame(Xtr, columns=feature_names, index=X_train.index)
    X_test_p = pd.DataFrame(Xte, columns=feature_names, index=X_test.index)

    # Options used to build the prediction form later
    form_spec = {}
    for c in numeric:
        s = X[c].dropna()
        uniq = sorted(s.unique().tolist())
        form_spec[c] = {"type": "numeric", "min": float(s.min()), "max": float(s.max()),
                        "median": float(s.median()), "options": uniq if len(uniq) <= 2 else None}
    for c in categorical:
        form_spec[c] = {"type": "categorical", "options": sorted(X[c].dropna().unique().tolist())}

    return {"clean_df": d, "report": report, "numeric_cols": numeric, "categorical_cols": categorical,
            "dropped_cols": dropped, "target": target, "label_encoder": le, "class_names": class_names,
            "pos_label": pos_label, "pos_index": pos_index, "preprocessor": preprocessor,
            "X_train_raw": X_train, "X_test_raw": X_test, "y_train": y_train, "y_test": y_test,
            "X_train_p": X_train_p, "X_test_p": X_test_p, "feature_names": feature_names,
            "form_spec": form_spec, "test_size": test_size, "random_state": random_state}
