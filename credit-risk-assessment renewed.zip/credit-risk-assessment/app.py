"""Credit Risk Assessment using Feature Selection & Dimensionality Reduction.
Run with:  python -m streamlit run app.py
"""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

from src import dimensionality_reduction as dimred
from src import eda
from src import feature_selection as fsel
from src import model_training as mt
from src import prediction as pred
from src import preprocessing as prep
from src.sample_data import generate_sample_data
from src.utils import (apply_theme, brand_bar, card, explain, hero, metric_card, page_header,
                       result_card, stepper, steps_grid)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
MODEL_PATH = BASE_DIR / "models" / "credit_risk_model.joblib"

st.set_page_config(page_title="Credit Risk Lab", page_icon="📒", layout="wide",
                   initial_sidebar_state="collapsed")
apply_theme()

# ---------------------------------------------------------------- session state
DEFAULTS = {"df": None, "source": None, "is_sample": False, "target": None,
            "prepared": None, "fs": None, "pca": None, "results": None, "bundle": None}
for key, value in DEFAULTS.items():
    st.session_state.setdefault(key, value)
S = st.session_state


def reset_downstream():
    """When the data or target changes, old preprocessing/model results are no longer valid."""
    for key in ("prepared", "fs", "pca", "results", "bundle"):
        S[key] = None


def set_dataset(df, source, is_sample):
    S.df, S.source, S.is_sample = df, source, is_sample
    S.target = prep.detect_target(df)
    reset_downstream()


def show_fig(fig, caption=None):
    st.pyplot(fig)
    plt.close(fig)
    if caption:
        explain(caption)


def need_data():
    if S.df is None:
        st.warning("No dataset loaded yet. Go to **02 Dataset** and load a CSV or the sample data.")
        return False
    return True


def need_target():
    if not need_data():
        return False
    if S.target is None:
        st.warning("Please choose the target column on the **02 Dataset** page.")
        return False
    return True


def need_prepared():
    if not need_target():
        return False
    if S.prepared is None:
        st.warning("Please run **04 Preprocess** first (it creates the train/test split).")
        return False
    return True


def sample_banner():
    if S.is_sample:
        st.warning("⚠️ You are using the built-in SAMPLE data. It is randomly generated (synthetic), "
                   "so every result here is for demonstration only and is not real banking data.")


# ---------------------------------------------------------------- Page 1
def page_home():
    page_header("Credit Risk Assessment using Feature Selection & Reduction",
                "Analyse loan applicant data, find the most important features, apply PCA and predict loan approval.")
    hero("Will this loan be approved?",
         "Load applicant data, find the features that matter, reduce dimensions with PCA, compare three classifiers "
         "and test a single applicant. Everything is calculated from the data you load.")
    sample_banner()

    if S.df is not None and S.target is not None:
        d = S.df.drop_duplicates().dropna(subset=[S.target])
        classes = sorted(d[S.target].astype(str).unique())
        if len(classes) == 2:
            pos = prep.guess_positive_label(classes)
            neg = [c for c in classes if c != pos][0]
            approved = int((d[S.target].astype(str) == pos).sum())
            rejected = int((d[S.target].astype(str) == neg).sum())
            c1, c2, c3, c4 = st.columns(4)
            with c1: metric_card("Total applicants", f"{len(d):,}", "after removing duplicates")
            with c2: metric_card("Approved", f"{approved:,}", f"class '{pos}'")
            with c3: metric_card("Rejected", f"{rejected:,}", f"class '{neg}'")
            with c4: metric_card("Approval rate", f"{approved / len(d):.1%}", f"{S.source}")
        else:
            st.info(f"The selected target '{S.target}' does not have exactly 2 classes, "
                    "so approval statistics cannot be calculated.")
    else:
        st.info("Load a dataset on the **02 Dataset** page to see the live statistics here.")

    st.subheader("What is credit risk assessment?")
    c1, c2 = st.columns(2)
    with c1:
        card("Credit risk", "Credit risk assessment estimates how likely it is that a loan applicant will repay a loan. "
             "Banks study details such as income, loan amount and credit history to approve or reject an application. "
             "Machine learning can learn these patterns from past applications.")
    with c2:
        card("Why reduce features?", "Datasets contain many columns, and some add noise or repeat the same information. "
             "Feature selection keeps only the most useful original columns. PCA combines columns into a few new components. "
             "Both can simplify models, but they do not always improve accuracy, so this project measures the difference.")
    st.subheader("How the pipeline works")
    steps_grid([("01", "Dataset", "Upload the Kaggle CSV or load the sample data and confirm the target."),
                ("02", "EDA", "Charts that show approvals, income, loan amount and credit history."),
                ("03", "Preprocess", "Impute, scale, encode and split. Fitted on training data only."),
                ("04", "Features", "Correlation, SelectKBest and Random Forest importance."),
                ("05", "PCA", "Compress features into components and check explained variance."),
                ("06", "Models", "Logistic Regression, Decision Tree and Random Forest on 3 feature sets."),
                ("07", "Predict", "Enter one applicant and get an educational estimate.")])


# ---------------------------------------------------------------- Page 2
def page_upload():
    page_header("Dataset Upload & Preview", "Load the Kaggle Loan Prediction CSV (or the sample data) and choose the target.")
    option = st.radio("Choose data source",
                      ["Upload a CSV file", "Use a CSV from the data/ folder", "Use built-in SAMPLE data (synthetic)"],
                      horizontal=True)
    try:
        if option == "Upload a CSV file":
            up = st.file_uploader("Upload your loan dataset (CSV)", type=["csv"])
            if up is not None and S.source != f"Uploaded: {up.name}":
                set_dataset(prep.read_csv_safely(up), f"Uploaded: {up.name}", False)
        elif option == "Use a CSV from the data/ folder":
            files = sorted(p.name for p in DATA_DIR.glob("*.csv"))
            if not files:
                st.info("No CSV files found in the data/ folder. Copy the Kaggle file (e.g. train.csv) there.")
            else:
                choice = st.selectbox("CSV files in data/", files)
                if st.button("Load selected file"):
                    set_dataset(prep.read_csv_safely(DATA_DIR / choice), f"data/{choice}", False)
        else:
            st.caption("The sample data is randomly generated with the same columns as the Kaggle dataset. "
                       "It is only for testing the website.")
            if st.button("Load sample data"):
                set_dataset(generate_sample_data(), "Built-in SAMPLE data (synthetic)", True)
    except prep.DataError as e:
        st.error(f"❌ {e}")

    if S.df is None:
        st.info("No dataset loaded yet.")
        return
    df = S.df
    sample_banner()
    st.success(f"Loaded **{S.source}**")

    missing_cols = prep.missing_expected_columns(df)
    if len(missing_cols) == len(prep.EXPECTED_COLUMNS):
        st.error("❌ This file does not look like a loan dataset: none of the expected columns "
                 "(Gender, Married, ApplicantIncome, LoanAmount, Credit_History, Loan_Status ...) were found.")
    elif missing_cols:
        st.warning("Some usual loan columns are missing: " + ", ".join(missing_cols) +
                   ". The project still works with the columns that exist.")

    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_card("Rows", f"{df.shape[0]:,}")
    with c2: metric_card("Columns", df.shape[1])
    with c3: metric_card("Missing cells", f"{int(df.isna().sum().sum()):,}")
    with c4: metric_card("Duplicate rows", int(df.duplicated().sum()))

    st.subheader("Preview")
    st.dataframe(df.head(20))
    st.subheader("Columns, data types and missing values")
    info = pd.DataFrame({"Column": df.columns, "Data type": df.dtypes.astype(str).values,
                         "Missing": df.isna().sum().values,
                         "Missing %": (df.isna().mean() * 100).round(2).values,
                         "Unique values": df.nunique().values})
    st.dataframe(info)

    st.subheader("Target column")
    cols = list(df.columns)
    default = cols.index(S.target) if S.target in cols else len(cols) - 1
    chosen = st.selectbox("Select the target column (what we want to predict)", cols, index=default)
    if chosen != S.target:
        S.target = chosen
        reset_downstream()
    n_classes = df[S.target].dropna().nunique()
    if n_classes == 2:
        st.success(f"Target **{S.target}** has 2 classes: {sorted(df[S.target].dropna().astype(str).unique())}")
    else:
        st.error(f"❌ The target '{S.target}' has {n_classes} distinct values. Choose a column with exactly 2 "
                 "classes (for example Loan_Status = Y / N).")


# ---------------------------------------------------------------- Page 3
def page_eda():
    page_header("Exploratory Data Analysis", "Understand the data before building models.")
    if not need_target():
        return
    sample_banner()
    d = S.df.drop_duplicates()
    target = S.target
    if d[target].dropna().nunique() != 2:
        st.error("The target column must have exactly 2 classes for these charts.")
        return

    st.subheader("1. Loan approval vs rejection")
    show_fig(eda.plot_target_distribution(d, target),
             "Shows how many applications fall into each class. A big gap between the bars means the data is imbalanced.")

    income = eda.find_col(d, ["ApplicantIncome", "income"])
    st.subheader("2. Applicant income distribution")
    if income and pd.api.types.is_numeric_dtype(d[income]):
        show_fig(eda.plot_distribution(d, income, "Applicant Income Distribution", income),
                 "Income is usually right-skewed: most applicants earn a moderate amount and a few earn a lot.")
    else:
        st.info("No numeric applicant income column was found.")

    loan = eda.find_col(d, ["LoanAmount", "loan_amount"])
    st.subheader("3. Loan amount distribution")
    if loan and pd.api.types.is_numeric_dtype(d[loan]):
        show_fig(eda.plot_distribution(d, loan, "Loan Amount Distribution", loan),
                 "Shows the typical size of the requested loans and any very large outliers.")
    else:
        st.info("No numeric loan amount column was found.")

    edu = eda.find_col(d, ["Education"])
    st.subheader("4. Education vs loan approval")
    if edu:
        show_fig(eda.plot_category_vs_target(d, edu, target, "Education vs Loan Approval"),
                 "Compares approval counts for each education level. Compare the bar heights within each group.")
    else:
        st.info("No Education column was found.")

    credit = eda.find_col(d, ["Credit_History"])
    st.subheader("5. Credit history vs loan approval")
    if credit:
        show_fig(eda.plot_category_vs_target(d, credit, target, "Credit History vs Loan Approval"),
                 "Credit history is normally the strongest signal: applicants with a good history are approved far more often.")
    else:
        st.info("No Credit_History column was found.")

    st.subheader("6. Correlation heatmap")
    numeric, _, _ = prep.identify_columns(d, target)
    fig = eda.plot_correlation_heatmap(d, numeric)
    if fig is None:
        st.info("At least two numerical columns are needed for a correlation heatmap.")
    else:
        show_fig(fig, "Values near +1 or -1 mean two numerical features move together; values near 0 mean little linear relationship.")

    st.subheader("7. Missing values")
    fig = eda.plot_missing(d)
    if fig is None:
        st.success("There are no missing values in this dataset.")
    else:
        show_fig(fig, "Columns with missing values must be imputed before training. This is handled on the Preprocessing page.")


# ---------------------------------------------------------------- Page 4
def page_preprocessing():
    page_header("Data Preprocessing", "Clean, encode, scale and split the data without leaking test information.")
    if not need_target():
        return
    sample_banner()
    explain("Steps: remove duplicates and rows without a target → split into train/test → impute missing values "
            "(median for numbers, most frequent for categories) → scale numbers (StandardScaler) → one-hot encode "
            "categories. All of these are FITTED ON THE TRAINING SET ONLY and then applied to the test set, "
            "so the test data never influences training (no data leakage).")
    c1, c2 = st.columns(2)
    test_size = c1.slider("Test set size", 0.10, 0.40, 0.20, 0.05)
    seed = int(c2.number_input("Random seed", min_value=0, value=42, step=1))
    if st.button("Run preprocessing"):
        try:
            with st.spinner("Preprocessing..."):
                S.prepared = prep.prepare_data(S.df, S.target, test_size, seed)
            S.fs = S.pca = S.results = S.bundle = None
            st.success("Preprocessing finished.")
        except prep.DataError as e:
            st.error(f"❌ {e}")
        except Exception as e:
            st.error(f"❌ Unexpected problem during preprocessing: {e}")
    p = S.prepared
    if p is None:
        return

    a, b, c, d_ = st.columns(4)
    with a: metric_card("Rows after cleaning", f"{len(p['clean_df']):,}",
                        f"{p['report']['duplicates_removed']} duplicates, {p['report']['missing_target_removed']} no-target rows removed")
    with b: metric_card("Training rows", f"{len(p['y_train']):,}")
    with c: metric_card("Testing rows", f"{len(p['y_test']):,}")
    with d_: metric_card("Features after encoding", len(p["feature_names"]),
                         f"from {len(p['numeric_cols']) + len(p['categorical_cols'])} original columns")

    st.markdown(f"**Numerical columns:** {', '.join(p['numeric_cols']) or 'none'}")
    st.markdown(f"**Categorical columns:** {', '.join(p['categorical_cols']) or 'none'}")
    if p["dropped_cols"]:
        st.markdown("**Dropped columns:** " + "; ".join(f"{k} ({v})" for k, v in p["dropped_cols"].items()))
    st.markdown(f"**Target classes:** {p['class_names']} → encoded as 0, 1. "
                f"Class treated as 'approved' (positive): **{p['pos_label']}**")

    st.subheader("Missing values handled (training data)")
    rows = []
    for col in p["numeric_cols"] + p["categorical_cols"]:
        n_missing = int(p["X_train_raw"][col].isna().sum())
        if n_missing:
            rows.append({"Column": col, "Missing before": n_missing,
                         "Strategy": "median" if col in p["numeric_cols"] else "most frequent",
                         "Missing after": 0})
    if rows:
        st.dataframe(pd.DataFrame(rows))
    else:
        st.success("No missing values in the training features.")
    st.subheader("Processed training data (first rows)")
    st.dataframe(p["X_train_p"].head(10))
    explain("Numerical columns now have mean ≈ 0 and standard deviation ≈ 1. Categorical columns are 0/1 indicator columns.")
    dist = pd.DataFrame({"Train": p["y_train"].map(dict(enumerate(p["class_names"]))).value_counts(),
                         "Test": p["y_test"].map(dict(enumerate(p["class_names"]))).value_counts()})
    st.subheader("Class balance in the split")
    st.dataframe(dist)
    explain("The split is stratified, so both sets keep roughly the same approval/rejection proportion.")


# ---------------------------------------------------------------- Page 5
def page_feature_selection():
    page_header("Feature Selection", "Keep only the most informative features.")
    if not need_prepared():
        return
    sample_banner()
    p = S.prepared
    Xtr, ytr = p["X_train_p"], p["y_train"]
    n_feat = Xtr.shape[1]
    explain("Feature selection removes columns that add little information. Benefits: simpler models, faster training, "
            "less overfitting and results that are easier to explain. All scores below use TRAINING data only.")
    c1, c2, c3 = st.columns(3)
    k = c1.slider("Number of features to select (k)", 1, n_feat, min(10, n_feat))
    method = c2.selectbox("SelectKBest scoring method", list(fsel.SCORE_METHODS))
    use = c3.radio("Use these features for modelling", ["SelectKBest", "Random Forest importance"])

    if st.button("Run feature selection"):
        with st.spinner("Calculating feature scores..."):
            corr = fsel.correlation_analysis(Xtr, ytr)
            kbest = fsel.select_k_best(Xtr, ytr, k, method, p["random_state"])
            rf = fsel.random_forest_importance(Xtr, ytr, k, p["random_state"])
            chosen = kbest if use == "SelectKBest" else rf
            S.fs = {"features": chosen[chosen["Selected"]]["Feature"].tolist(), "method": use, "k": k,
                    "corr": corr, "kbest": kbest, "rf": rf, "kbest_method": method,
                    "pairs": fsel.high_correlation_pairs(Xtr)}
            S.results = S.bundle = None
    fs = S.fs
    if fs is None:
        st.info("Choose k and click **Run feature selection**.")
        return

    st.success(f"{len(fs['features'])} features selected with **{fs['method']}**: " + ", ".join(fs["features"]))

    st.subheader("1. Correlation with the target")
    st.dataframe(fs["corr"].round(4))
    show_fig(fsel.plot_scores(fs["corr"].assign(Selected=True), "Abs correlation", "Top Features by |Correlation| with Target",
                              "Absolute correlation"),
             "Linear relationship between each encoded feature and the target. It only captures straight-line effects.")
    st.markdown("**Highly correlated feature pairs (|r| ≥ 0.8)**")
    if fs["pairs"].empty:
        st.success("No highly redundant feature pairs found.")
    else:
        st.dataframe(fs["pairs"])
        explain("Pairs like Gender_Female / Gender_Male are exact opposites, so one of them is redundant.")

    st.subheader(f"2. SelectKBest ({fs['kbest_method']})")
    st.dataframe(fs["kbest"].round(4))
    show_fig(fsel.plot_scores(fs["kbest"], "Score", "SelectKBest Feature Scores", "Score (higher = more related to target)"),
             "Dark bars are the k selected features. The score measures how strongly a feature separates approved from rejected.")

    st.subheader("3. Random Forest feature importance")
    st.dataframe(fs["rf"].round(4))
    show_fig(fsel.plot_scores(fs["rf"], "Importance", "Random Forest Feature Importance", "Importance"),
             "Random Forest importance measures how much each feature helps the trees make correct splits, including non-linear effects.")


# ---------------------------------------------------------------- Page 6
def page_pca():
    page_header("PCA & Dimensionality Reduction", "Compress many features into a few principal components.")
    if not need_prepared():
        return
    sample_banner()
    p = S.prepared
    explain("PCA creates new uncorrelated features (components) that capture as much variance as possible. Input here is the "
            "preprocessed data: numbers are standardized and categories are one-hot encoded, so PCA works on numeric data only. "
            "PCA is fitted on training data and ignores the target (it is unsupervised).")
    n_feat = p["X_train_p"].shape[1]
    mode_label = st.radio("How should the number of components be chosen?",
                          ["Number of components", "Target explained variance"], horizontal=True)
    if mode_label == "Number of components":
        n = st.slider("Number of principal components", 1, min(n_feat, len(p["X_train_p"])), min(5, n_feat))
        res = dimred.fit_pca(p["X_train_p"], p["X_test_p"], "components", n_components=n, random_state=p["random_state"])
        threshold = None
    else:
        threshold = st.slider("Target cumulative explained variance", 0.50, 0.99, 0.95, 0.01)
        res = dimred.fit_pca(p["X_train_p"], p["X_test_p"], "variance", variance_threshold=threshold,
                             random_state=p["random_state"])
    S.pca = res

    a, b, c = st.columns(3)
    with a: metric_card("Original features", res["n_original"])
    with b: metric_card("PCA components", res["n_components"],
                        f"{(1 - res['n_components'] / res['n_original']):.0%} fewer features")
    with c: metric_card("Variance kept", f"{res['variance_kept']:.1%}")

    show_fig(dimred.plot_explained_variance(res["evr"], res["cumulative"], threshold),
             "Bars show the variance explained by each component; the line shows the running total (cumulative).")
    table = pd.DataFrame({"Component": [f"PC{i + 1}" for i in range(len(res["evr"]))],
                          "Explained variance %": (res["evr"] * 100).round(2),
                          "Cumulative %": (res["cumulative"] * 100).round(2)})
    st.dataframe(table)
    if res["scatter_2d"].shape[1] >= 2:
        show_fig(dimred.plot_pca_scatter(res["scatter_2d"], p["y_train"], p["class_names"]),
                 "Each dot is one applicant projected on the first two components. Heavily overlapping colours mean the "
                 "two classes are not clearly separable with just these two components.")
    else:
        st.info("A 2-D scatter plot needs at least 2 features.")


# ---------------------------------------------------------------- Page 7
def default_feature_selection(p):
    k = min(10, p["X_train_p"].shape[1])
    rf = fsel.random_forest_importance(p["X_train_p"], p["y_train"], k, p["random_state"])
    return {"features": rf[rf["Selected"]]["Feature"].tolist(), "method": "Random Forest importance (default)", "k": k}


def deploy_model(model_name, fs_name):
    """Build the prediction bundle for the chosen model and save it with Joblib."""
    res, p = S.results, S.prepared
    row = res["table"][(res["table"]["Model"] == model_name) & (res["table"]["Feature Set"] == fs_name)].iloc[0]
    metrics = {m: float(row[m]) for m in mt.METRICS}
    bundle = pred.build_bundle(p, res["fitted"][(model_name, fs_name)], model_name, fs_name,
                               res["features"], res["pca_model"], metrics, S.source, S.is_sample)
    pred.save_bundle(bundle, MODEL_PATH)
    S.bundle = bundle


def page_models():
    page_header("Machine Learning Models", "Compare three models on original, selected and PCA features.")
    if not need_prepared():
        return
    sample_banner()
    p = S.prepared
    explain("All 9 combinations (3 models × 3 feature sets) use the SAME train/test split, so the comparison is fair. "
            "Dimensionality reduction does not always improve accuracy; the table shows what actually happened.")
    st.markdown(f"Feature selection used: **{S.fs['method'] if S.fs else 'not run yet → top-10 Random Forest features will be used'}**  ·  "
                f"PCA used: **{str(S.pca['n_components']) + ' components' if S.pca else 'not run yet → 95% variance will be used'}**")

    if st.button("Train and compare models"):
        try:
            with st.spinner("Training models..."):
                fs = S.fs or default_feature_selection(p)
                pca_res = S.pca or dimred.fit_pca(p["X_train_p"], p["X_test_p"], "variance",
                                                  variance_threshold=0.95, random_state=p["random_state"])
                Xtr, Xte = p["X_train_p"], p["X_test_p"]
                sets = {"Original features": (Xtr.to_numpy(), Xte.to_numpy()),
                        "Selected features": (Xtr[fs["features"]].to_numpy(), Xte[fs["features"]].to_numpy()),
                        "PCA features": (pca_res["X_train"], pca_res["X_test"])}
                table, fitted, cms = mt.evaluate_all(sets, p["y_train"], p["y_test"], p["pos_index"], p["random_state"])
                S.results = {"table": table, "fitted": fitted, "cms": cms, "features": fs["features"],
                             "pca_model": pca_res["model"], "baseline": mt.majority_baseline(p["y_train"], p["y_test"])}
                best = table.sort_values(["F1-Score", "Accuracy"], ascending=False).iloc[0]
                deploy_model(best["Model"], best["Feature Set"])
            st.success("Training complete. The best model (by F1-score) was saved for the Prediction page.")
        except Exception as e:
            st.error(f"❌ Training failed: {e}")
    res = S.results
    if res is None:
        return

    table = res["table"]
    st.subheader("Performance comparison")
    st.dataframe(table.round(4))
    best = table.sort_values(["F1-Score", "Accuracy"], ascending=False).iloc[0]
    st.markdown(f"Best by F1-score: **{best['Model']}** on **{best['Feature Set']}** (F1 = {best['F1-Score']:.3f}).  \n"
                f"Baseline for reference: always predicting the most common class gives accuracy **{res['baseline']:.3f}**.")
    explain("Precision, recall and F1 treat the class '" + str(p["pos_label"]) + "' as the positive (approved) class. "
            "Compare each result with the baseline: a model that is not better than the baseline has learned little.")

    metric = st.selectbox("Metric to plot", mt.METRICS, index=3)
    show_fig(mt.plot_comparison(table, metric), f"Bar chart of {metric} for every model and feature set.")

    st.subheader("Confusion matrix")
    c1, c2 = st.columns(2)
    m_name = c1.selectbox("Model", list(table["Model"].unique()))
    f_name = c2.selectbox("Feature set", list(table["Feature Set"].unique()))
    show_fig(mt.plot_confusion_matrix(res["cms"][(m_name, f_name)], p["class_names"], f"{m_name} - {f_name}"),
             "Rows are the actual classes and columns are the predicted classes. The diagonal shows correct predictions.")

    st.subheader("Choose the model used on the Prediction page")
    labels = [f"{r['Model']} | {r['Feature Set']}" for _, r in table.iterrows()]
    current = f"{S.bundle['model_name']} | {S.bundle['feature_set']}" if S.bundle else labels[0]
    pick = st.selectbox("Model for predictions", labels, index=labels.index(current) if current in labels else 0)
    if st.button("Use this model for predictions"):
        name, fs_name = pick.split(" | ")
        deploy_model(name, fs_name)
        st.success(f"Saved **{pick}** to models/credit_risk_model.joblib")


# ---------------------------------------------------------------- Page 8
def page_prediction():
    page_header("Credit Risk Prediction", "Enter applicant details and get an educational estimate.")
    bundle = S.bundle
    if bundle is None:
        bundle = pred.load_bundle(MODEL_PATH)
        if bundle is not None:
            st.info("Using the model saved earlier in models/credit_risk_model.joblib "
                    f"(trained on: {bundle['source']}).")
    if bundle is None:
        st.error("❌ No trained model is available. Load a dataset, run Preprocessing, then train models on the "
                 "**07 Models** page. No prediction will be shown without a real trained model.")
        return
    if bundle["is_sample"]:
        st.warning("⚠️ This model was trained on synthetic SAMPLE data, so predictions are only a demonstration.")
    st.caption(f"Model: **{bundle['model_name']}** on **{bundle['feature_set']}** · test accuracy "
               f"{bundle['metrics']['Accuracy']:.3f}, F1 {bundle['metrics']['F1-Score']:.3f} · target: {bundle['target']}")

    spec = bundle["form_spec"]
    inputs = {}
    with st.form("prediction_form"):
        columns = st.columns(3)
        for i, col in enumerate(bundle["categorical_cols"] + bundle["numeric_cols"]):
            label = col.replace("_", " ")
            holder = columns[i % 3]
            s = spec[col]
            if s["type"] == "categorical":
                inputs[col] = holder.selectbox(label, s["options"], key=f"in_{col}")
            elif s["options"]:   # numeric column with only two values, e.g. Credit_History 0/1
                inputs[col] = holder.selectbox(label, s["options"], index=len(s["options"]) - 1, key=f"in_{col}")
            else:
                step = 100.0 if s["max"] > 1000 else 1.0
                inputs[col] = holder.number_input(label, min_value=0.0, value=float(round(s["median"])),
                                                  step=step, key=f"in_{col}")
        submitted = st.form_submit_button("Predict")
    if submitted:
        errors = pred.validate_inputs(inputs, bundle)
        if errors:
            for e in errors:
                st.error(f"❌ {e}")
        else:
            try:
                r = pred.predict_one(bundle, inputs)
                detail = f'Estimated probability of "{bundle["pos_label"]}": {r["p_positive"]:.1%}'
                if r["risk"]:
                    detail += f' · Risk category: {r["risk"]}'
                result_card(f'PREDICTED {bundle["target"]}'.upper(), str(r["label"]), detail, r["is_positive"])
                st.progress(min(max(r["p_positive"], 0.0), 1.0))
            except Exception as e:
                st.error(f"❌ Prediction failed: {e}")
    st.info("ℹ️ This is an educational estimate from a student machine-learning project. It is NOT an actual bank decision.")


# ---------------------------------------------------------------- navigation (top bar, no sidebar)
PAGES = {
    "01 Home": page_home,
    "02 Dataset": page_upload,
    "03 EDA": page_eda,
    "04 Preprocess": page_preprocessing,
    "05 Features": page_feature_selection,
    "06 PCA": page_pca,
    "07 Models": page_models,
    "08 Predict": page_prediction,
}
brand_bar()
choice = st.radio("Navigation", list(PAGES), horizontal=True, key="nav", label_visibility="collapsed")
stepper([("DATA", S.df is not None), ("PREPROCESSED", S.prepared is not None), ("FEATURES", S.fs is not None),
         ("PCA", S.pca is not None), ("MODELS", S.results is not None)])
PAGES[choice]()
st.caption("Educational project. Predictions are estimates and are not real bank decisions.")
